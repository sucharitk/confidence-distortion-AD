import InstructionsPanel from "./instructionsPanel.js";
import eventsCenter from './eventsCenter.js';
import { saveSRETEndorseData, saveStartTimeData } from "./db/saveData.js";


// const COLOR_LIGHT = 0x0705e7;
// const COLOR_DARK = 0x060944;

const responseOptions = ['Yes',
                        'No'];
const sretPositionCenter = {x: 300, y: 300, orientation: 'x'};

var numTotalTrials;
var numPracticeTrials;
var numFinalTrials;
var curTrialNum;
var stimulusTimedEvent;
var timeFromStimOnset;
var preStimulusWaitDur = [800, 500]; // first element is for first trial, and second for subsequent trials
var wordPresentationDur = 1000;
var postWordDur = 250; 

var taskMode;
var taskPhase;
var trialPhase;
var gameHeight;
var gameWidth;
var titleText;
var mainTxt;
var randWordPositions;
var sretChoice = [];
var sretRespTime = [];
var fullscreenButton;

var titleText;
var mainText;
var buttonTxt;
var pageNo;
var textWord;
var textQuestion;
var wordFrame;
var radioButton;
// var submitButton;
var gameHeight;
var gameWidth;

var responseClicked; // if the response slider has been clicked once

export default class TaskSRE extends Phaser.Scene{
    constructor (){
        super({
            key: 'sreTask'
        });
    }

    preload (){
        this.load.scenePlugin({
            key: 'rexuiplugin',
            url: './src/phaser/rexuiplugin.min.js',
            sceneKey: 'rexUI'
        });  

        this.load.spritesheet('fullscreen', './assets/fullscreen.png', {frameWidth: 64, frameHeight: 64})
        this.load.text('sretWordsFinal', './assets/sretWords.txt');
        this.load.text('sretWordsPractice', './assets/sretPracticeWords.txt');
        // this.load.text('sretWordsFinal', './assets/sretShort.txt');
        // this.load.text('sretWordsPractice', './assets/sretPracticeWordsShort.txt');

        this.load.image('bg', './assets/clouds.png');
        this.load.spritesheet('tiles', './assets/fantasy-tiles.png', { frameWidth: 64, frameHeight: 64 });

    }

    create (){
        // initialisations
        saveStartTimeData(subjID, expName, (window.timeStampOrder++)+'_sreTask')

        // background image
        this.add.image(400, 0, 'bg').setOrigin(0.5, 0.02);
        // tiles at the bottom
        for (let i = 0; i < 13; i++){
            this.add.image(64 * i, 580, 'tiles', 1).setOrigin(0);
        }

        // load the words for sret from a file
        this.loadWords();

        // set total trials equal to the total number of words
        numPracticeTrials = this.sretWordsPractice.length;
        numFinalTrials = this.sretWordsFinal.length;

        // randomise the order of words
        randWordPositions = randSample(sequence(numFinalTrials), numFinalTrials);

        this.createTaskItems();
            
        gameHeight = this.sys.game.config.height;
        gameWidth = this.sys.game.config.width;
    
        taskMode = 'practice';
        taskPhase = 'instructions';
    }


    update (){
        switch (taskPhase){
            case 'instructions':
                this.showInstructions(taskMode);
                // this.doTask(taskMode);

                break;

            case 'task':
                // this.showInstructions(taskMode);
                this.doTask(taskMode);
                break;

            case 'wait':
                break;
        }

    }
    
    showInstructions(taskMode){
        
        switch (taskMode)
        {
            case 'practice':
                titleText = 'Self-descriptive Words';
            
                // let's do this a long-winded way for easiness...[should be a function]
                ///////////////////PAGE ONE////////////////////
                mainText = (    " Next, you will be presented the following question  \n"+
                                " on the screen: \n\n" + 
                                ' "Does this word generally describe you?" \n\n' +
                                " We will then show you a series of words, where your \n"+
                                " task is to simply choose for each word one of two \n"+
                                " options:\n"+
                                " 'Yes' - if you think the word describes you, OR \n"+
                                " 'No'  - if you think the word does not describe you.\n" +
                                " The words will be shown one at a time with the \n"+
                                " next word appearing soon after you have selected \n"+
                                " your choice on the shown word."
                                );
                buttonTxt = "More instructions";

                pageNo = 1;
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                pageNo, titleText, mainText, buttonTxt);
    

                eventsCenter.once('page1complete', function () {
                    mainText = (" Let us start by practicing this task with \n"+
                                " some sample words. Click 'Proceed' to start\n" +
                                " practicing. "
                                );
                    buttonTxt = "Proceed";
                    pageNo = 2;

                    this.instructionsPanel = new InstructionsPanel(this, 
                    gameWidth/2, gameHeight/2,
                    pageNo, titleText, mainText, buttonTxt);

                }, this);

                eventsCenter.once('page2complete', function () {
                    // taskPhase = 'wait'

                    taskPhase = 'task';
                    trialPhase = 'trialInit';
                    curTrialNum = 0;
                    textQuestion.setVisible(true);
                    wordFrame.setVisible(true);

                    numTotalTrials  = numPracticeTrials;
                }, this);                

                // show instructions
                taskPhase = 'wait';
                
                break;

                
            case 'final':

                mainTxt = ( " You have completed the practice! \n\n"+
                            " You can now proceed to the main task. \n\n"+
                            " Once you are ready to start the main task \n"+
                            " Click 'Begin' "
                );
                buttonTxt = "Begin";
                pageNo = 3;
                this.instructionsPanel = new InstructionsPanel(this, 
                                                            gameWidth/2, gameHeight/2,
                                                            pageNo, titleText, mainTxt, buttonTxt);


                eventsCenter.once('page3complete', function () {
                    taskPhase = 'task'
                    trialPhase = 'trialInit';
                    curTrialNum = 0;
                    textQuestion.setVisible(true);
                    wordFrame.setVisible(true);

                    numTotalTrials  = numFinalTrials;

                });          
                
                // show instructions
                taskPhase = 'wait';

                break;
            
        }

    }
    

    doTask(){
        if (curTrialNum < numTotalTrials)
        {
            switch (trialPhase)
            {
                // different phases within a trial

                case 'wait':
                    // do nothing

                    break;
                    
                case 'trialInit':
                    
                    responseClicked = false;

                    textWord.x = sretPositionCenter.x;
                    textWord.text = taskMode=="practice"? this.sretWordsPractice[curTrialNum]:
                                                        this.sretWordsFinal[randWordPositions[curTrialNum]];

                    radioButton.value = [];
                    wordFrame.setVisible(false);

                    stimulusTimedEvent = window.performance.now();

                    trialPhase = 'preStimulus';

                    break;                        
                
                case 'preStimulus':

                    timeFromStimOnset = window.performance.now() - stimulusTimedEvent;
                    if (timeFromStimOnset <= preStimulusWaitDur[+!!curTrialNum]){
                        // +!! first converts int to bool and then converts it back to int

                        wordFrame.setVisible(true);

                        // ELSE: do nothing 
                    } 
                    else{
                        trialPhase = 'dispWord';
                    }
                 
                    break;


                case 'dispWord':

                    timeFromStimOnset = window.performance.now() - (stimulusTimedEvent + preStimulusWaitDur[+!!curTrialNum]);
                    if (timeFromStimOnset <= wordPresentationDur){   
                        textWord.setVisible(true);

                    } 
                    else{
                        textWord.setVisible(false);
                        trialPhase = 'postWord';
                    }
                    
                    break;

                case 'postWord':
                    // gap after word presentation

                    timeFromStimOnset = window.performance.now() - 
                        (stimulusTimedEvent + preStimulusWaitDur[+!!curTrialNum] + wordPresentationDur);

                        if (timeFromStimOnset <= postWordDur){
                            // gap
                        } 
                        else{
                            trialPhase = 'acceptResp';
                            stimulusTimedEvent = window.performance.now();
                        }                    
                        
                        break;


                case 'acceptResp':

                radioButton.setVisible(true);
                    if (radioButton.value.length!=0){
                        // submitButton.setVisible(true);
                        sretChoice[curTrialNum] = radioButton.value;
                        sretRespTime[curTrialNum] = window.performance.now() - stimulusTimedEvent;
                        trialPhase = 'postTrial';
                    }
                    break;


                case 'postTrial':

                    textWord.setVisible(false);
                    radioButton.setVisible(false);

                    curTrialNum++;

                    trialPhase = 'trialInit';
                    
                    break;

            }

        } 
        else{
     
            if (taskMode=='practice'){
                // if we were in the practice mode, switch to final model
                taskMode='final';
                curTrialNum = 0;
                numTotalTrials  = numFinalTrials;

                taskPhase = 'instructions';

            }
            else{
                // window.sretResults = {
                // }
                saveSRETEndorseData(window.subjID, window.expName, {
                    words: this.sretWordsFinal,
                    randWordPositions: randWordPositions,
                    sretChoice: sretChoice,
                    sretRespTime: sretRespTime
                });
                taskMode = 'endblock';
                this.nextScene();    
            }
        }
    }

  
    nextScene() {
        this.scene.start('subjectInfo');
    }


    loadWords(){
        // get the words from the practice and final words files
        // split them by each line and put them in an array
        let cache = this.cache.text;
        let posnegWords = cache.get('sretWordsFinal');
        this.sretWordsFinal = posnegWords.split('\n');

        posnegWords = cache.get('sretWordsPractice');
        this.sretWordsPractice = posnegWords.split('\n');

    }

    createTaskItems(){
                // create a frame within which to present the word
        wordFrame = this.rexUI.add.roundRectangle(
            sretPositionCenter.x+90, sretPositionCenter.y, 260, 80, 20, 
            window.themeCols[1], 200);
        wordFrame.setVisible(false);

        textWord = this.add.text(sretPositionCenter.x ,
            sretPositionCenter.y-15,
            "Good",{
            align:'center', color: 'white', strokeThickness: 3, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true},
            fontSize: 32

        });
        textWord.setVisible(false);

        textQuestion = this.add.text(sretPositionCenter.x - 60 ,
            sretPositionCenter.y-70,
            "Does this word describe you?",{
            align: 'center', //color: '#00', strokeThickness: 3, 
            shadow: {offsetX: .5, offsetY: .5, stroke: true},
            fontSize: 20

        });
        textQuestion.setVisible(false);

        curTrialNum = 0;

        radioButton = createRadioButtons(this, responseOptions,
            sretPositionCenter,
            function(btnIndex) 
            {
                sretChoice[curTrialNum] = btnIndex;
            });

        fullscreenButton = addFullscreenButton(this);

    }
}