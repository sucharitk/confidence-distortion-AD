import InstructionsPanel from "./instructionsPanel.js";

import eventsCenter from './eventsCenter.js';
import { saveQuestionnaireData, saveStartTimeData } from "./db/saveData.js";

const questionnaireFileNames = ['consent', 'gadphq',  'spin'];
// const questionnaireFileNames = ['consentShort', 'gadphqShort',  'spinShort'];
const questionnaireOptions = ['consentResponses', 'gadResponses', 'spinResponses'];
const dialogTitles = ['Consent Form', 'Mental Health Questionnaire 1', 
                    'Mental Health Questionnaire 2'];

var qn;

const nQuestionnaires = questionnaireFileNames.length;
const preQuestionnaireInstructions = [ " Please complete the following consent form before \n"+
                                    " starting the study.\n\n"+
                                    " If you need any further information to help you \n"+
                                    " decide whether or not to take part, then please\n"+
                                    " get in contact with the research team via\n"+
                                    " ion.mpc.cog@ucl.ac.uk before completing the form.", 
                                
                                    " Next, we will ask you some questions about\n"+
                                    ' how you have been feeling lately. \n\n' +
                                    " We understand that filling out these kinds of\n"+
                                    " questionnaires can sometimes feel repetitive.\n"+
                                    " But, it is extremely important for the aims of our\n"+
                                    " study that you fill them out as truthfully as\n"+
                                    " possible. This will allow us to more usefully \n"+
                                    " understand the data you have provided up till now.\n\n"+
                                    " After answering each question, click the 'Next'\n"+
                                    " button to proceed. Feel free to also click \n"+
                                    " 'Previous' if you want to change an answer. \n",

                                    " Next, we will ask you some questions about\n"+
                                    ' how you have been feeling lately. \n\n' +
                                    " We understand that filling out these kinds of\n"+
                                    " questionnaires can sometimes feel repetitive.\n"+
                                    " But, it is extremely important for the aims of our\n"+
                                    " study that you fill them out as truthfully as\n"+
                                    " possible. This will allow us to more usefully \n"+
                                    " understand the data you have provided up till now.\n\n"+
                                    " After answering each question, click the 'Next'\n"+
                                    " button to proceed. Feel free to also click \n"+
                                    " 'Previous' if you want to change an answer. \n"
                                ];

const questionnaireInstructions = [ " To indicate your consent to take part in this\n"+
                                    " study, please read the following statements and\n"+
                                    " check the option to tell us whether or not you \n"+
                                    " agree with each statement. You can only take part \n"+
                                    " in the study if you agree with all the statements.",
                                     
                                    " Over the last two weeks, how often have you \n"+
                                    " been bothered by any of the following problems?",
                                    
                                    " Please read each statement and click in the \n"+
                                    " column that indicates how much the statement \n"+
                                    " applied to you over the past week."
                                ];

const titlePosition = {x: [20, 50, 50], y: [140, 145, 140]}
const questionPosition = {x: [50, 80, 80], y: [300, 225, 234]};
const radioButtonPosition = {x: [90, 160, 160], y: [410, 330, 320]};
const prevNextButtonPosition = {x: [300, 300, 300], y: [540, 520, 520]};

var numTotalTrials;
var curTrialNum;
var stimulusTimedEvent;
var timeFromStimOnset;

var taskPhase;
var trialPhase;
var gameHeight;
var gameWidth;
var titleText;
var buttonText;
var chosenQuestionnaireResponse;
var chosenQuestionnaireValue;
var numOptions;
var fullscreenButton;
var qChoice;

var pageNo;

var textInstructions;
var textQuestion;
var radioButton;
var nextButton;
var prevButton;
var submitButton;

export default class Questionnaires extends Phaser.Scene{
    constructor (){
        super({
            key: 'questionnaires'
        });
    }

    preload (){

        qn = window.curQuestionnaireNumber;
        this.load.scenePlugin({
            key: 'rexuiplugin',
            url: './src/phaser/rexuiplugin.min.js',
            sceneKey: 'rexUI'
        });  

        this.load.spritesheet('fullscreen', './assets/fullscreen.png', {frameWidth: 64, frameHeight: 64})
        this.load.text(questionnaireOptions[qn],
            './assets/' + questionnaireOptions[qn] + '.txt');
        this.load.text(questionnaireFileNames[qn],
            './assets/' + questionnaireFileNames[qn] + '.txt');

        this.load.image('bg', './assets/clouds.png');
        this.load.spritesheet('tiles', './assets/fantasy-tiles.png', { frameWidth: 64, frameHeight: 64 });

    }

    create (){

        saveStartTimeData(subjID, expName, (window.timeStampOrder++)+'_'+questionnaireFileNames[qn])

        // initialisations
        // background image
        this.add.image(400, 0, 'bg').setOrigin(0.5, 0.02);
        // tiles at the bottom
        for (let i = 0; i < 13; i++){
            this.add.image(64 * i, 580, 'tiles', 1).setOrigin(0);
        }

        this.loadQuestions();

        gameHeight = this.sys.game.config.height;
        gameWidth = this.sys.game.config.width;

        chosenQuestionnaireValue = [];
        chosenQuestionnaireResponse = [];

        this.createTaskItems();
    }


    update (){
        switch (taskPhase){
            case 'instructions':
                this.showInstructions(preQuestionnaireInstructions[qn]);
                break;

            case 'task':
                this.doTask();
                break;

            case 'endblock':
                if (qn){
                    // save questionnaire data for all except first which is the consent form.
                    // subjects can only proceed with the task if they consent to all 
                    this.saveData();
                }
                this.nextScene();
                break;
        }

    }
    
    showInstructions(mainText){

        titleText = dialogTitles[qn];
            
        buttonText = "Proceed";

        pageNo = 1;
        this.instructionsPanel = new InstructionsPanel(this, 
        gameWidth/2, gameHeight/2,
        pageNo, titleText, mainText, buttonText);

        eventsCenter.once('page1complete', function () {

            taskPhase = 'task';
            trialPhase = 'showNextQuestion';
            textInstructions.setVisible(true);
            // wordFrame.setVisible(true);
            curTrialNum = 0;

            numTotalTrials = this.qQuestions.length;
        }, this);                                                       
   
        taskPhase = 'wait';
    }

    doTask(){
        if (curTrialNum < numTotalTrials){
            switch (trialPhase){
                // different phases within a trial

                case 'showNextQuestion':

                    let curQ = this.qQuestions[curTrialNum];

                    curQ = splitStringByNumberOfCharacters(curQ, 44, '\n   ');
                    textQuestion.text = curTrialNum+1 + '/' +
                                        numTotalTrials + '.' +
                                        curQ;
                    textQuestion.setVisible(true);
              
                    radioButton.setVisible(true);

                    if (radioButton.value==undefined || radioButton.value.length==0){
                        // if no choice has been made for this question
                        if (curTrialNum>0) // subsequent trials enable previous button
                        {enableButton(prevButton, true);}
                        else // if first trial, no previous button
                        {enableButton(prevButton, false);}

                        // keep next button disabled
                        enableButton(nextButton, false);

                    }
                    else{
                        // if a choice has been made for this question
                        if (curTrialNum>0)
                        {enableButton(prevButton, true);}
                        else
                        {enableButton(prevButton, false);} // first trial: no previous button

                        if (curTrialNum<numTotalTrials-1)
                        {enableButton(nextButton, true); // not last trial: enable next button
                        submitButton.setVisible(false);}
                        else{
                            // last trial: enable the submit button
                            enableButton(nextButton, false);
                            submitButton.setVisible(true);
                        }
                    }

                    break;
            }

        } 

    }

  
    nextScene() {
        //this.registry.set('coinsTotal', nCoins);   // log total coins (to pass between scenes)

        switch (qn)
        {
            case 0: 
            // for the consent form, check if consent has been received for all questions 
                if (!any(chosenQuestionnaireResponse))
                {
                    // if none of the responses are 1s (corresponding to 'I do not agree') - consent is received and moved to the tasks
                    // window.mhq1State = 1;
                    // window.mhq2State = 1;
                    window.sretState = 1;
                    window.consentState = 2; // done but button disabled
                }
                break;

            // for all other questionnaires mark them as complete once they have been filled
            case 1:
                window.mhq1State = 2;
                break;

            case 2:
                window.mhq2State = 2;
                break;
        }

        this.scene.start('welcome');

    }

    saveData(){
        saveQuestionnaireData(window.subjID, window.expName,{
            chosenQuestionnaireResponse: chosenQuestionnaireResponse,
            chosenQuestionnaireValue: chosenQuestionnaireValue,
            questName: questionnaireFileNames[qn],
            questNum: qn,
        });
    }

    loadQuestions(){
        let cache = this.cache.text;
        let options = cache.get(questionnaireOptions[qn]);
        this.qOptions = options.split('\n');
        let questions = cache.get(questionnaireFileNames[qn]);
        this.qQuestions = questions.split('\n');
    }

    createTaskItems(){

        textInstructions = this.add.text(titlePosition.x[qn],
            titlePosition.y[qn], 
            questionnaireInstructions[qn],
            {
            align:'center', color: 'white', strokeThickness: 3, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true},
            fontSize: 24

        });
        textInstructions.setVisible(false);

        textQuestion = this.add.text(questionPosition.x[qn] ,
            questionPosition.y[qn] ,
            "Question?",{
            // align: 'center', //color: '#00', strokeThickness: 3, 
            shadow: {offsetX: .5, offsetY: .5, stroke: true},
            fontSize: 20

        });
        textQuestion.setVisible(false);

        numOptions = this.qOptions.length;
        radioButton = createRadioButtons(this, this.qOptions,
            {x: radioButtonPosition.x[qn], y: radioButtonPosition.y[qn],
            orientation: 'y'},
            function(btnIndex) 
            {
                chosenQuestionnaireResponse[curTrialNum] = btnIndex;
                chosenQuestionnaireValue[curTrialNum] = radioButton.value;

            });
        radioButton.value = [];

        nextButton = createButton(this, 'Next >>', 
        {x: 300, y: prevNextButtonPosition.y[qn], width: 50, height: 50},
        function() {
            curTrialNum++;
            // console.log('chosenQuestionnaireValue: '+chosenQuestionnaireValue[curTrialNum])
            if (chosenQuestionnaireValue[curTrialNum]!=undefined){
                radioButton.value=chosenQuestionnaireValue[curTrialNum];
            }
            else{
                radioButton.value = undefined;
            }
            
        });
        nextButton.setVisible(false);
        prevButton = createButton(this, '<< Previous', 
        {x: 150, y: prevNextButtonPosition.y[qn], width: 50, height: 50},
        function() 
        {
            curTrialNum--;
            radioButton.value=chosenQuestionnaireValue[curTrialNum];
        }
        );
        prevButton.setVisible(false);
            
        submitButton = createButton(this, 'click here to submit your answers', 
        {x: 420, y: prevNextButtonPosition.y[qn], width: 100, height: 50},
        function() 
        {
            taskPhase = 'endblock';
        }
        );
        submitButton.setVisible(false);
        taskPhase = 'instructions';

        fullscreenButton = addFullscreenButton(this);

    }
}
