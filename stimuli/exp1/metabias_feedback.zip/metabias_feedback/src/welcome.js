import InstructionsPanel from "./instructionsPanel.js";
import eventsCenter from './eventsCenter.js';
import { saveStartTimeData, saveFinalSurvey } from "./db/saveData.js";

const stimulusGrid = [10, 11]; // grid of berries
const numStimuli = stimulusGrid[0]*stimulusGrid[1]; // total number of berries
const numStimulusLevels = numStimuli/2; // number of stimullus levels

var consentButton;
var doneButton;
var content;
var participantInfoScrollPanel;
var bannerText;
var infoButton;
var mhq1Button;
var mhq2Button;
var sretButton;
var mainTaskButton;
var quitButton;
var fullscreenButton;
var smallFullScreenButton1;
var smallFullScreenButton2;
var contactUsPanel;
var finalSurveyForm;
var futureInterest;
var biasedAuditorCorrect;
var biasedAuditorIncorrect;
var changeFeelingCorrect;
var changeFeelingIncorrect;

var feedbackField;

var mainText;

var gameHeight;
var gameWidth;

var taskPhase;
const flickerInstructionsFrames = [30, 40];
var curFlickFrame;

var helpTextOpenClose;
var helpTextInfo;
var helpTextConsent;
var helpTextMHQ;
var helpTextSRET;
var helpTextMain;
var onsetTime;
var flickerText;
var cc;

var welcomTextCenter = {x: 170, y: 40}

export default class Welcome extends Phaser.Scene{
    constructor (){
        super({
            key: 'welcome',
            // autoStart: true
        });
    }

    preload (){
   
        this.load.scenePlugin({
            key: 'rexuiplugin',
            url: './src/phaser/rexuiplugin.min.js',
            sceneKey: 'rexUI'
        });  

        this.load.image('tree','./assets/tree_2.png', { frameWidth: 500, frameHeight: 500 })
        this.load.spritesheet('fullscreen', './assets/fullscreen.png', {frameWidth: 64, frameHeight: 64})
        this.load.image('bg', './assets/clouds.png');
        this.load.spritesheet('tiles', './assets/fantasy-tiles.png', { frameWidth: 64, frameHeight: 64 });            

        this.load.text('participantInfoSheet', './assets/participantInfoSheet.txt');
        this.load.text('cc', './src/utils/'+window.expName+'_cc.txt');
        this.load.html('finalSurvey', 'src/utils/finalSurvey.html');
    }

    create (){
        // background image
        this.add.image(400, 0, 'bg').setOrigin(0.5, 0.02);
      
        // tiles at the bottom
        for (var i = 0; i < 13; i++){
            this.add.image(64 * i, 580, 'tiles', 1).setOrigin(0);
        }

        gameHeight = this.sys.game.config.height;
        gameWidth = this.sys.game.config.width;

        this.createTextAndButtons();

        onsetTime = window.performance.now();
        content = undefined;

        if (window.mhq1State<=0 &&
            window.mhq2State<=0){
            // before questionnaires have begun
            if (window.mainTaskState<=0){
                // before main task has begun
                switch(window.consentState){
                    case -1:
                        // first screen is welcome
                        window.infoSheetState = 1;
                        bannerText.x = gameWidth;
                        taskPhase = 'welcome';
                        break;
                        
                    case 1:
                        // once info sheet has been seen
                        taskPhase = 'enableConsent';
                        break;

                    case 2: 
                        // once consent has been given
                        window.mhq1State = 0;
                        window.mhq2State = 0;
                        window.sretState = 1;
                        window.mainTaskState = 0;

                        taskPhase = 'enableSRET' ;
                        break;
                }
            }
            else{
                window.mhq1State = 0;
                window.mhq2State = 0;
                window.sretState = 2;
                window.mainTaskState = 1;
                if (this.scale.isFullscreen){
                    taskPhase = 'enableMainTask';
                }
                else {
                    taskPhase = 'return2Fullscreen';
                }
            }
        }
        else if(window.mhq1State==2 && window.mhq2State==2) {
            // the study is complete
            window.mhq1State = -1;
            window.mhq2State = -1;
            window.sretState = -1;
            window.mainTaskState = -11;
            taskPhase = 'finalSurvey';
        }
        else {
            taskPhase = 'enableMentalHealthSurvey';
        }

        let cache = this.cache.text;
        cc = cache.get('cc');

    }

    update (){
        switch(taskPhase){

            case 'welcome':
                if (bannerText.x > welcomTextCenter.x && 
                    (onsetTime - window.performance.now() < 50)){
                    // animate the 'welcome banner'
                    bannerText.x = bannerText.x-10;
                    onsetTime = window.performance.now();
                }
                else{

                    helpTextInfo.text = 'Please wait while we load...';
                    helpTextInfo.setVisible(true);

                    taskPhase = 'fullscreen';
                }
                break;

            case 'fullscreen':
                helpTextInfo.setVisible(false);

                smallFullScreenButton1.setVisible(true);
                smallFullScreenButton2.setVisible(true);

                helpTextOpenClose.text = "IMPORTANT: \n\n"+
                                    "   1.  Please do NOT refresh this webpage at any\n"+
                                    "       point during the study.\n\n"+
                                    "   2.  Make sure that your internet connection  \n"+
                                    "       is available throughout the study to\n"+
                                    "       ensure your data is being duly saved.\n\n"+
                                    "   3.  Make sure this browser window is in      \n"+
                                    "       FULLSCREEN mode for the study. \n"+
                                    "       Buttons to toggle fullscreen mode   /    \n"+
                                    "       will always be available on the        \n"+
                                    "       top-right corner of this window if you need.\n\n"+
                                    "  Click the top-right fullscreen button now to begin.";
                helpTextOpenClose.setVisible(true);
                helpTextOpenClose.x = 30;
                helpTextOpenClose.y = 120;
                if (this.scale.isFullscreen){
                    smallFullScreenButton1.setVisible(false);
                    smallFullScreenButton2.setVisible(false);
                    helpTextOpenClose.setVisible(false);
                    taskPhase = 'loadInfoSheet';
                }
                break;


            case 'loadInfoSheet':
                // load the participant information sheet
                // this takes sometime

                content = loadInfoSheet(this);
                participantInfoScrollPanel = scrollTextPanel(this, content,
                    { // position
                    x: gameWidth/2, y: gameHeight/2-30, width: 680, height: 500}, 
                    doneButton
                    );
                participantInfoScrollPanel.setVisible(false);

                enableButton(infoButton, window.infoSheetState);
                enableButton(consentButton, window.consentState);
                enableButton(mainTaskButton, window.mainTaskState);
                enableButton(mhq1Button, window.mhq1State);
                enableButton(mhq2Button, window.mhq2State);
                enableButton(sretButton, window.sretState);
                enableButton(quitButton, 1);
                helpTextInfo.text = "<< Start by clicking this button to\n   read information about this study";
                helpTextInfo.x = 390;
                helpTextInfo.y = 525;
                flickerText = helpTextInfo;
                
                taskPhase = 'wait'

                break;

            case 'showParticipantInfoSheet':

                infoButton.setVisible(false);
                quitButton.setVisible(false);

                if (content==undefined)
                {
                    content = loadInfoSheet(this);
                    participantInfoScrollPanel = scrollTextPanel(this, content,
                        { // position
                        x: gameWidth/2, y: gameHeight/2-30, width: 680, height: 500}, 
                        doneButton
                        );
                }
                
                participantInfoScrollPanel.setVisible(true);

                helpTextConsent.text = "Scroll and read the information\nto the end. Once done click here >>";
                helpTextConsent.x = 200;
                helpTextConsent.y = 535;
                helpTextConsent.setVisible(true);
                fullscreenButton.setVisible(false);

                enableButton(doneButton, 0);

                taskPhase = 'wait';

                break;

            case 'showContactDialog':
                // dialog to ask participants to contact us, if needed
                
                helpTextConsent.setVisible(false);
                mainTaskButton.setVisible(false);
                mainText = ( " If you have any questions about the study\n" +
                                " before beginning, email us on \n" + 
                                " ion.mpc.cog@ucl.ac.uk \n"+
                                " with the title 'Self-evaluation study'\n"+
                                " and we will get back to you as soon as\n"+
                                " possible! "
                                // "At regular points along your journey,\n"+
                                // "you will have to [color=#d0f4f7]make a choice[/color] between\n" +\n\n"
                                );
                contactUsPanel = new InstructionsPanel(this, 
                                    gameWidth/2, gameHeight/2,
                                    1, 'Questions', mainText, "Got it");

                
                eventsCenter.once('page1complete', function () {
                    taskPhase = 'enableConsent';
                    window.consentState = 1;
                }, this);
                
                taskPhase = 'wait';

                break;

            case 'enableConsent':

                enableButton(infoButton, window.infoSheetState)
                enableButton(consentButton, window.consentState);
                enableButton(mainTaskButton, window.mainTaskState);
                enableButton(mhq1Button, window.mhq1State);
                enableButton(mhq2Button, window.mhq2State);
                enableButton(sretButton, window.sretState);
                enableButton(quitButton, 1);

                helpTextConsent.text = "<< Next, please provide your consent\n   for participating in this study";
                helpTextConsent.x = 285;
                helpTextConsent.y = 230;
                helpTextConsent.setVisible(true);
                flickerText = helpTextConsent;

                // helpTextInfo.text = "You can revisit the\nStudy Information anytime";
                helpTextInfo.text = "";
                helpTextInfo.setVisible(true);
                helpTextInfo.setColor('white')
                helpTextInfo.x = 395;
                helpTextInfo.y = 525;

                taskPhase = 'wait';
                
                break;

            case 'enableMentalHealthSurvey':

                bannerText.setVisible(true);

                enableButton(infoButton, window.infoSheetState)
                enableButton(consentButton, -1);
                enableButton(mainTaskButton, window.mainTaskState);
                enableButton(mhq1Button, window.mhq1State);
                enableButton(mhq2Button, window.mhq2State);
                enableButton(sretButton, window.sretState);
                enableButton(quitButton, 1);

                // helpTextInfo.text = "You can revisit the\nStudy Information anytime";
                helpTextInfo.text = "";
                helpTextInfo.setVisible(true);
                helpTextInfo.setColor('white')
                helpTextInfo.x = 395;
                helpTextInfo.y = 525;

                helpTextMHQ.text = "Finally, please fill out   \ntwo mental health surveys >>\nin any order (10-12 mins)  "
                helpTextMHQ.x = 130;
                helpTextMHQ.y = 400;
                helpTextMHQ.setVisible(true);
                flickerText = helpTextMHQ;

                taskPhase = 'wait';

                break;

            case 'enableSRET':

                bannerText.setVisible(true);

                // infoButton.setVisible(true);
                enableButton(infoButton, window.infoSheetState)
                enableButton(consentButton, -1);
                enableButton(mhq1Button, window.mhq1State);
                enableButton(mhq2Button, window.mhq2State);
                enableButton(sretButton, window.sretState);
                enableButton(mainTaskButton, window.mainTaskState);
                enableButton(quitButton, 1);

                // helpTextInfo.text = "You can revisit the\nStudy Information anytime";
                helpTextInfo.text = "";
                helpTextInfo.setVisible(true);
                helpTextInfo.setColor('white')
                helpTextInfo.x = 400;
                helpTextInfo.y = 525;

                // helpTextSRET.text = "Next step is the \nself-description task >>";
                helpTextSRET.text = "<< Click to start your first task\n   about self-descriptive words";
                helpTextSRET.x = 290;
                helpTextSRET.y = 180;
                helpTextSRET.setVisible(true);
                flickerText = helpTextSRET;

                break;

            case 'return2Fullscreen':
                bannerText.setVisible(true);
                enableButton(infoButton, window.infoSheetState)
                enableButton(consentButton, -1);
                enableButton(mhq1Button, window.mhq1State);
                enableButton(mhq2Button, window.mhq2State);
                enableButton(sretButton, window.sretState);
                enableButton(mainTaskButton, 0);
                enableButton(quitButton, 1);
                
                smallFullScreenButton1.setVisible(true);
                smallFullScreenButton1.x = 730;
                smallFullScreenButton1.y = 205;
                helpTextInfo.text = "Now, let us return to \n"+
                                    "the FULLSCREEN mode.\n\n"+
                                    "Please click the  \n"+
                                    "fullscreen button on\n"+
                                    "the top-right corner\n"+
                                    "again to proceed.";
                helpTextInfo.setVisible(true);
                helpTextInfo.x = 526;
                helpTextInfo.y = 150;
                flickerText = helpTextInfo;
                if (this.scale.isFullscreen){
                    smallFullScreenButton1.setVisible(false);
                    // flickerText = undefined;
                    taskPhase = 'enableMainTask';
                }
                break;

            case 'enableMainTask':

                bannerText.setVisible(true);

                enableButton(infoButton, window.infoSheetState)
                enableButton(consentButton, -1);
                enableButton(mhq1Button, window.mhq1State);
                enableButton(mhq2Button, window.mhq2State);
                enableButton(sretButton, window.sretState);
                enableButton(mainTaskButton, window.mainTaskState);
                enableButton(quitButton, 1);

                // helpTextInfo.text = "You can revisit the Study Information anytime";
                helpTextInfo.text = "";
                helpTextInfo.setVisible(false);
                helpTextInfo.setColor('white')
                helpTextInfo.x = 400;
                helpTextInfo.y = 525;

                helpTextMain.text = "Click to start the main   \ntask for this study   >>";
                helpTextMain.x = 15;
                helpTextMain.y = 290;
                helpTextMain.setVisible(true);
                flickerText = helpTextMain;

                break;
                
            case 'finalSurvey':

                this.scale.stopFullscreen();

                helpTextOpenClose.x = 270;
                helpTextOpenClose.y = 150;
                helpTextOpenClose.setVisible(true);
                helpTextOpenClose.text = "Final few questions";

                this.showFinalSurvey();
                taskPhase = 'wait';

                break;

            case 'studyComplete':

                saveStartTimeData(subjID, expName, (window.timeStampOrder++)+'_studyComplete')

                bannerText.text = "Study Completed";
                bannerText.x = 200;
                bannerText.setVisible(true);
                helpTextOpenClose.text =  "Thank you for your participation!\n\n"+
                            "Your completion code for Prolific is: "+cc;
                helpTextOpenClose.x = 80;
                helpTextOpenClose.setVisible(true);
                helpTextInfo.text = "(You may now close this window now)";
                helpTextInfo.x = 220;
                helpTextInfo.y = 400;
                helpTextInfo.setVisible(true);
                taskPhase = 'wait';

                break;
        }

        if (flickerText!=undefined){
            // flicker flickerText if it is not undefined
            curFlickFrame++;
            if (curFlickFrame < flickerInstructionsFrames[0]){
                flickerText.setVisible(true);
            }
            else if (curFlickFrame < flickerInstructionsFrames[1]){
                flickerText.setVisible(false);
            }
            else {curFlickFrame=0;}            
        }
    }

    nextScene() {
        console.log((window.sceneSequence[window.curBlock]))
        this.scene.start(window.sceneSequence[window.curBlock]);
    } 

    createTextAndButtons(){
        bannerText = this.add.text(140,40, 'Welcome to the study', {
            strokeThickness: 6, stroke: '#000', color: '#0e4',
            fontSize: 40
        });
        bannerText.setVisible(true);

        infoButton = createButton(this, '? Study Information',  { // position
            x: 275, y: 545, width: 100, height: 50},
            function() { // click callback
                // when info button is clicked show participant information sheet
                taskPhase = 'showParticipantInfoSheet';
                flickerText = undefined;
                helpTextInfo.setVisible(false);
        });
        infoButton.setVisible(false);

        consentButton = createButton(this, 'Consent Form', { // position
            x: 200, y: 250, width: 100, height: 75},
            function(scene) { // click callback
                // when consent button is clicked go to consent form questionnaire
                window.curQuestionnaireNumber = window.consentFormNumber;
                scene.scene.start("questionnaires");
        });
        consentButton.setVisible(false);

        mhq1Button = createButton(this, 'Mental Health Survey 1', { // position
            x: 630, y: 400, width: 100, height: 50},
            function(scene) { // click callback
                // when consent button is clicked go to consent form questionnaire
                window.curQuestionnaireNumber = 1;
                scene.scene.start("questionnaires");
        });
        mhq1Button.setVisible(false);
        mhq2Button = createButton(this, 'Mental Health Survey 2', { // position
            x: 630, y: 460, width: 100, height: 50},
        function(scene) { // click callback
            // when consent button is clicked go to consent form questionnaire
            window.curQuestionnaireNumber = 2;
            scene.scene.start("questionnaires");
        });
        mhq2Button.setVisible(false);

        sretButton = createButton(this, 'Self-description Task\n    (12-15 mins)', { // position
            x: 160, y: 200, width: 100, height: 80},
        function(scene) { // click callback
            // when consent button is clicked go to consent form questionnaire
            // window.curQuestionnaireNumber = window;
            scene.scene.start("sreTask");
        });
        sretButton.setVisible(false);

        mainTaskButton = createButton(this, 'The Fruitville Game\n     (~30 mins)', { // position
            x: 395, y: 310, width: 140, height: 100},
        function(scene) { // click callback
            // when consent button is clicked go to consent form questionnaire
            // window.curQuestionnaireNumber = window;
            scene.scene.start("fruitville");
        });
        mainTaskButton.setVisible(false);

        quitButton = createButton(this, 'Quit Study', { // position
            x: 80, y: 545, width: 100, height: 50},
        function(scene) { // click callback
            quitStudyCallback(scene);
        });
        quitButton.setVisible(false);
        // enableButton(quitButton, 1);

        helpTextInfo = this.add.text(200,200, 
            !!window.infoSheetState ? 
            // "You can revisit the Study Information anytime":
            "":
            "<< Start by clicking this button to\n   read the Information about this study" ,{
            color: 'black', strokeThickness: 1, stroke: '#000',
            fontSize: 18
        });
        helpTextInfo.setVisible(false);

        helpTextOpenClose = this.add.text(200,200,"",{
            align:'center', color: '#fff', strokeThickness: 3, 
            stroke: 'black', fontSize: 22,
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        helpTextOpenClose.scale = 1;
        helpTextOpenClose.setVisible(false);

        // button for responding to acceptance of participant info sheet
        doneButton = createButton(this, 'Understood',  { // position
            x: 640, y: 550, width: 100, height: 50},
        function() { // click callback
            participantInfoScrollPanel.setVisible(false);
            taskPhase = 'showContactDialog';
            // infoButton.setVisible(true);
            doneButton.setVisible(false);
            fullscreenButton.setVisible(true);
            // helpTextInfo.text = "You can revisit the\n  Study Information anytime";
            helpTextInfo.text = "";
            // helpTextInfo.setVisible(true);
            helpTextInfo.setColor('white')
            helpTextInfo.x = 400;
            helpTextInfo.y = 530;
            window.infoSheetState = 2;
            if (window.consentState==-1)
            {
                window.consentState = 1;
            }
        });
        doneButton.setVisible(false);

        helpTextConsent = this.add.text(300,220, 
            window.consentState>0  ?
            "You have provided consent" :
            "<< Next, please provide your consent\n   for participating in this study",{
            color: 'black', strokeThickness: 1, stroke: '#000',
            fontSize: 17
        });
        helpTextConsent.setVisible(false);

        helpTextMHQ = this.add.text(200,200, "",{
            color: 'black', strokeThickness: 1, stroke: '#000',
            fontSize: 18
        });
        helpTextMHQ.setVisible(false);

        helpTextSRET = this.add.text(200,200, "",{
            color: 'black', strokeThickness: 1, stroke: '#000',
            fontSize: 18
        });
        helpTextSRET.setVisible(false);

        helpTextMain = this.add.text(200,200, "",{
            color: 'black', strokeThickness: 1, stroke: '#000',
            fontSize: 18
        });
        helpTextMain.setVisible(false);        

        fullscreenButton = addFullscreenButton(this);
        
        smallFullScreenButton1 = this.add.image(625,408,'fullscreen',0)
        .setOrigin(1,0).setScale(.37);
        smallFullScreenButton2 = this.add.image(670,408,'fullscreen',1)
        .setOrigin(1,0).setScale(.37);
        smallFullScreenButton1.setVisible(false);
        smallFullScreenButton2.setVisible(false);

    }

    showFinalSurvey(){
        finalSurveyForm = this.add.dom(380,380).createFromCache('finalSurvey');
            
        finalSurveyForm.addListener('click');

        finalSurveyForm.on('click', function(event){
            if (event.target.name == 'submitButton')
            {
                futureInterest = this.getChildByName('futureInterest');
                biasedAuditorCorrect = this.getChildByName('biasedAuditorCorrect');
                biasedAuditorIncorrect = this.getChildByName('biasedAuditorIncorrect');
                changeFeelingCorrect = this.getChildByName('changeFeelingCorrect');
                changeFeelingIncorrect = this.getChildByName('changeFeelingIncorrect');

                // feedbackField = this.getChildByName('feedback');
                
                saveFinalSurvey(window.subjID, window.expName,{
                    futureInterest: futureInterest.value,
                    // feedback: feedbackField.value
                    biasedAuditorCorrect: biasedAuditorCorrect.value,
                    biasedAuditorIncorrect: biasedAuditorIncorrect.value,
                    changeFeelingCorrect: changeFeelingCorrect.value,
                    changeFeelingIncorrect: changeFeelingIncorrect.value
    
                })
                taskPhase = 'studyComplete';
                finalSurveyForm.setVisible(false);
            }
        });
    }
}


var loadInfoSheet = function (scene){
    let cache = scene.cache.text;
    return cache.get('participantInfoSheet');
}

