import { db, set, ref, get, push, update} from "./initDatabase.js"

function saveConfTaskData(subjID, expName, results){
  const reference = ref(db, 
      expName + '/subjData/' + subjID + '/confTask/' + 
      (results.taskType?(results.curTaskBlock+"_mem"):(results.curTaskBlock+"_perc")));
      console.log(sum(results.correct))
    set(reference, {
        conf: results.confidence,
        resp: results.response,
        stim: results.stimulus,
        corr: results.correct,
        incdec: results.incdec,
        taskType: results.taskType, // perception or memory task
        feedbackTrial: results.feedbackYesNo,
        feedbackBlock: results.curBlockFeedback,
        mindChange: results.mindChange,
        stair: results.stair,
        curTaskBlock: results.curTaskBlock,
        reaction1Time: results.reaction1Time,
        reaction2Time: results.reaction2Time,
        sumCorrect: sum(results.correct)
      });
    console.log("updated conf data")
}

function saveSPEData(subjID, expName, results){
  // add the spe data to the conf task data
  const reference = ref(db, 
    expName + '/subjData/' + subjID + '/confTask/' + 
    (results.taskType?(results.curTaskBlock+"_mem"):(results.curTaskBlock+"_perc")));
  update(reference, {
    spe: results.speNumCorrect
    });  
}

function saveSRETEndorseData(subjID, expName, results){
  // save the SRE endorse data
  const reference = ref(db, 
    expName + '/subjData/' + subjID + '/sreTask/');
  set(reference, {
    presentedWords: results.words,
    randWordPositions: results.randWordPositions,
    sretChoice: results.sretChoice,
    sretRespTime: results.sretRespTime
  });  
}

function saveSRETRecallData(subjID, expName, results){
  const reference = ref(db, 
    expName + '/subjData/' + subjID + '/sreTask/');
  update(reference, {
    recalledWords: results.words
  });  

}

function saveQuestionnaireData(subjID, expName, results){
  const reference = ref(db, 
    expName + '/subjData/' + subjID + '/questionnares/'+results.questName);
  update(reference, {
    chosenQuestionnaireResponse: results.chosenQuestionnaireResponse,
    chosenQuestionnaireValue: results.chosenQuestionnaireValue,
    questionnareNum: results.questNum,
});  
}

function saveSubjInfo(subjID, expName, results){
  const reference = ref(db, 
    expName + '/subjData/' + subjID + '/subjInfo/');
  update(reference, {
      gender: results.gender,
      numStudiesDay: results.numStudiesDay,
      numStudiesMonth: results.numStudiesMonth
  });  
  const reference2 = ref(db, 
    expName + '/subjData/' + subjID + '/');
  update(reference2, {
      prolificID: results.prolificID
});  
}

function saveFinalSurvey(subjID, expName, results){
  const reference = ref(db, 
    expName + '/subjData/' + subjID + '/subjInfo/');
  update(reference, {
      futureInterest: results.futureInterest,
      // feedback: results.feedback
      biasedAuditorCorrect: results.biasedAuditorCorrect,
      biasedAuditorIncorrect: results.biasedAuditorIncorrect,
      changeFeelingCorrect: results.changeFeelingCorrect,
      changeFeelingIncorrect: results.changeFeelingIncorrect
  });  
}

function saveStartTimeData(subjID, expName, timeEvent){
  let currentdate = new Date(); 

  let reference = ref(db, 
    expName + '/subjData/' + subjID + '/timeInfo/'+timeEvent);

  update(reference, {
    time: currentdate.getHours() + ":"  
    + currentdate.getMinutes() + ":" 
    + currentdate.getSeconds()
  });    

  if (timeEvent[0] == '0'){
    reference = ref(db, 
      expName + '/subjData/' + subjID + '/timeInfo/');
  
    update(reference, {
      date: currentdate.getDate() + "/"
      + (currentdate.getMonth()+1)  + "/" 
      + currentdate.getFullYear()
    });  
    update(reference, {
      timeUTC: currentdate.getUTCHours() + ":"  
      + currentdate.getUTCMinutes() + ":" 
      + currentdate.getUTCSeconds()
    })
  }

}

async function checkRepeatSubjects(prolificID, expName){
  // first make sure that the prolific ID is not already in the database
  const subjIDRepeatRef = ref(db, 
    expName + '/groupAssignments/prolificID');
  const savedSubjIDRepeat = await get(subjIDRepeatRef);
  var idxSubjRepeat = -1; // subject is not repeated

  // iterate over each added ID
  var idx = 0;

  savedSubjIDRepeat.forEach(element => {
    if (element.val()==prolificID){
      // if subject is repeated what is their index
      idxSubjRepeat = idx;
      console.log(idxSubjRepeat)

    }
    idx++;
  });

  if (idxSubjRepeat==-1){
    // if subject is not repeated return -1
    return idxSubjRepeat;
  }
  else {
    // otherwise return the same group as last time
    // get the random assignments
    const groupRef = ref(db, 
      expName + '/groupAssignments/assignedGroup');
    const savedSubjGroup = await get(groupRef);
    const subjGroups = savedSubjGroup.val();
    console.log('participant ID already exists: '+idxSubjRepeat)
    
    return subjGroups[idxSubjRepeat];
    
  }

}


async function getSubjectGroupAssignment(subjID, expName){
  // if it is not a repeat subject then push the prolificID to the database to get a timestamped index
  const subjIDRef = ref(db, 
    expName + '/groupAssignments/prolificID');
  const pushRef = push(subjIDRef);
  set(pushRef, subjID)

  // get the list of the prolific IDs
  const savedSubjID = await get(subjIDRef);

  // get the random assignments
  const groupRef = ref(db, 
    expName + '/groupAssignments/randomGroup');
  const savedSubjGroup = await get(groupRef);
  const subjGroups = savedSubjGroup.val();

  // iterate over each added ID
  var idx = 0;
  var subjIdx = -1;
  savedSubjID.forEach((element) => {
    if (element.val()==subjID){
        subjIdx = idx;
    }
    idx++;
  });
  console.log('subjIdx'+subjIdx)

  if (subjIdx>=subjGroups.length){
    // subject index is more than the possible assigments
    return -1; 
  }
  else {
    return subjGroups[subjIdx];
  }

}

async function saveSubjGroup(subjID, expName, group){

  const savedGroupRef = ref(db, 
    expName + '/groupAssignments/assignedGroup');
  // get the list of the prolific IDs
  const savedGroup = await get(savedGroupRef);
  console.log(savedGroup.size)
  let savedGroupVals;
  if (savedGroup.size>0){
    savedGroupVals = savedGroup.val();
    savedGroupVals[savedGroupVals.length] = group;
  }
  else {
    savedGroupVals = [group];
  }

  const reference2 = ref(db, 
    expName + '/groupAssignments/');
  update(reference2, {
      assignedGroup: savedGroupVals
  });  

  const reference = ref(db, 
    expName + '/subjData/' + subjID + '/');
  update(reference, {
      group: group
  });  
}

export {saveConfTaskData, saveSPEData, saveSRETEndorseData,
  saveSRETRecallData, saveQuestionnaireData, saveStartTimeData,
  saveSubjInfo, getSubjectGroupAssignment, checkRepeatSubjects,
  saveSubjGroup, saveFinalSurvey}