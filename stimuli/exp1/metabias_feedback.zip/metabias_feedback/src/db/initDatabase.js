import { initializeApp } from "https://www.gstatic.com/firebasejs/9.8.3/firebase-app.js";
import { getDatabase, ref, set, get, push, update } from "https://www.gstatic.com/firebasejs/9.8.3/firebase-database.js";

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAiuLRdDbGVB6iEmGU0sYvPCM4Ng1vhLeI",
  authDomain: "shift-conf.firebaseapp.com",
  databaseURL: "https://shift-conf-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "shift-conf",
  storageBucket: "shift-conf.appspot.com",
  messagingSenderId: "990233235940",
  appId: "1:990233235940:web:bb3ab88b8fc80ee940f7f1",
  measurementId: "G-6C9Y17EZGE"
};

// Initialize Firebase
const appFirebase = initializeApp(firebaseConfig);
const db = getDatabase(appFirebase);
      
export { db, ref, set, get, push, update}