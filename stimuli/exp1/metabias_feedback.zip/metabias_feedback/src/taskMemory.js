import InstructionsPanel from "./instructionsPanel.js";
import eventsCenter from './eventsCenter.js';
import {saveConfTaskData, saveStartTimeData} from "./db/saveData.js";

// import { stimulusGrid, numStimuli , numStimulusLevels} from './eventsCenter.js';

// initialise the constants

// duration of task events in ms
const preStimInterval = [400, 500]; // random value in this interval
const stimulusDuration = 1500; // duration of stimuli for memory encoding
const postStimInterval = 1000; // interval between encoding and recall

const feedbackInterval = 2500; // total duration of feedback
const feedbackFaceAfter = 200; // onset of initial feedback message with face within the feedback interval
const feedbackMsgAfter = 500; // onset of the subsequent message after the face

var startConf = .5; // starting value of confidence to display 
const postFeedbackInterval = 600;

const scaleFruitScale = .85;
const fruitScale = [scaleFruitScale*.083, scaleFruitScale*.07, scaleFruitScale*.077,
    scaleFruitScale*.055, scaleFruitScale*.065, scaleFruitScale*.06, scaleFruitScale*.07,
    scaleFruitScale*.055, scaleFruitScale*.062, scaleFruitScale*.083, scaleFruitScale*.065,
    scaleFruitScale*.06, scaleFruitScale*.077]; // sizes of the fruit images are variable, so each needs its own scaling value
const numStimuli = fruitScale.length; // number of fruits
const numStimulusLevels = numStimuli-1; // number of stimullus levels
const chosenOptionSizeIncrease = 1.6;
// const stimLevels = Array.from({length: numStimulusLevels}, (_, i) => i + 1);

const curTaskNum = 1; // for memory task = 1

// const startLevel = Math.round(.7 * stimLevels.length); // start the task at the mid point of levels (.5)
var startLevel; // start the task at the mid point of levels (.5)

var numTotalTrials;

const offsetShadow = {x: .75, y: 1};

var curBlockFeedback;

var fruitStimuli;

var fruits = {};
var randFruits;
var cursors;
var fbPosImage;
var fbPosImageShadow;
var fbNegImage;
var fbNegImageShadow;

var timeFromStimOnset;
var timeFromStimOffset;
var timeFromConfOnset = 0;
var confRespTime = 0;
var nowTime;

var mindChange = {
    n: [],
    trialNum: [],
    response: [],
    reaction1Time: []
};

// starting trial number
var curTrialNum ;
var preStimulusWaitDur;

var taskPhase;
// var basket;
var trialPhase;

var stimulus=[];
var correct=[];
var confidence=[];
var response=[];
var incdec = []; // whether to increment or decrement on the curent trial and by how much
var feedbackYesNo = [];
var reaction1Time = [];
var reaction2Time = [];

var whichFeedbackMessage;
var text_resp;
var text_conf;
var textFeedback;
var textFeedbackMessage;
var textConfMarkers = {};
var fullscreenButton;

var confSlider = {};

var clickConfidence;
var currentConfidence;
var discreteConfidence;
var currentInput;
var fruitChoices;
var fruitOptions = {};

var gameHeight;
var gameWidth;
var auditDialogTitle;

var stair;

var stimulusTimedEvent;


export default class TaskMemory extends Phaser.Scene
{
    constructor ()
    {
        super({
            key: 'memoryTask'
        });
    }

    preload ()
    {
        this.load.scenePlugin({
            key: 'rexuiplugin',
            url: './src/phaser/rexuiplugin.min.js',
            sceneKey: 'rexUI'
        });  

        this.load.spritesheet('fullscreen', './assets/fullscreen.png', {frameWidth: 64, frameHeight: 64})
        this.load.image('tree','./assets/tree_2.png', { frameWidth: 500, frameHeight: 500 })
        this.load.image('bush1','./assets/bush_4.png', { frameWidth: 500, frameHeight: 500 })
        this.load.image('bush2','./assets/bush_9.png', { frameWidth: 500, frameHeight: 500 })
        this.load.image('bg', './assets/clouds.png');
        this.load.spritesheet('tiles', './assets/fantasy-tiles.png', { frameWidth: 64, frameHeight: 64 });

        this.load.image('fruit0', './assets/raspberry.png');
        this.load.image('fruit1', './assets/strawberry.png');
        this.load.image('fruit2', './assets/red-cherry.png');
        this.load.image('fruit3', './assets/red-apple.png');
        this.load.image('fruit4', './assets/red-grape.png');
        this.load.image('fruit5', './assets/banana.png');
        this.load.image('fruit6', './assets/star-fruit.png');
        this.load.image('fruit7', './assets/orange.png');
        this.load.image('fruit8', './assets/peach.png');
        this.load.image('fruit9', './assets/black-berry-light.png');
        this.load.image('fruit10', './assets/plum.png');
        this.load.image('fruit11', './assets/lemon.png');
        this.load.image('fruit12', './assets/black-cherry.png');

        this.load.image('fbPos', './assets/1f600.png');
        this.load.image('fbNeg', './assets/1f615.png');

        // plugin for randomising the position of the stimuli on every trial
        this.load.plugin(
            'rexrandomplaceplugin', 
            './src/phaser/rexrandomplaceplugin.min.js', 
            true);

    }

    create ()
    {
        // initialisations
        mindChange = {
            n: [],
            trialNum: [],
            response: [],
            reaction1Time: []
        };
        stimulus=[];
        correct=[];
        confidence=[];
        response=[];
        incdec = []; // whether to increment or decrement on the curent trial and by how much
        feedbackYesNo = [];
        reaction1Time = [];
        reaction2Time = [];

        saveStartTimeData(subjID, expName, (window.timeStampOrder++)+'_memoryTask')

        // background image
        this.add.image(400, 0, 'bg').setOrigin(0.5, 0.02);
        // tree
        this.add.image(40, 310, 'tree').setOrigin(0.4, 0.5).setScale(1.2);
        // bushes
        this.add.image(430, 360, 'bush2').setOrigin(0.1, 0.5).setScale(1.2);
        this.add.image(300, 235, 'bush1').setOrigin(0.4, 0.5).setScale(1.6);

        // tiles at the bottom
        for (let i = 0; i < 13; i++){
            this.add.image(64 * i, 580, 'tiles', 1).setOrigin(0);
        }
        
        gameHeight = this.sys.game.config.height;
        gameWidth = this.sys.game.config.width;
        auditDialogTitle = 'You have been chosen for an audit';

        this.createTaskItems();

        // define cursor keys
        cursors = this.input.keyboard.createCursorKeys();

        // create a blank group for the collective berry stimuli
        fruitStimuli = this.add.group();
        // set stimui to invisible initially
        Phaser.Actions.SetVisible(fruitStimuli.getChildren(),0);

        // create a psychophysics staircase
        startLevel = window.thresholdedInitLevels[curTaskNum]; // start the task at the mid point of levels (.5)
        numTotalTrials = window.numTaskTrials[window.practiceOrFinal[curTaskNum]];
        stair = initStair([1], numStimulusLevels, numTotalTrials, [1]);
        stair.levels[0] = startLevel;
        stair.nextLevel = startLevel; 
        
        if (practiceOrFinal[curTaskNum]){
            curBlockFeedback = window.feedbackType[window.curBlock];
            window.curBlock++;
        } else { // in case of practice
            curBlockFeedback = 1;
        }

        curTrialNum = 0;

        taskPhase = 'instructions';

    }

    update (){
        switch (taskPhase){
            case 'instructions':
                this.showInstructions();
                break;

            case 'task':
                this.doTask();
                break;

            case 'endblock':
                this.nextScene()
                break;
        }

    }
    
    showInstructions(){

        // show instructions

        if (Phaser.Input.Keyboard.JustDown(cursors.up) ||
            Phaser.Input.Keyboard.JustDown(cursors.down) ||
            Phaser.Input.Keyboard.JustDown(cursors.left) ||
            Phaser.Input.Keyboard.JustDown(cursors.right)){
            text_resp.setVisible(false);

            taskPhase = 'task';
            trialPhase = 'trialInit';
        }

    }

    doTask(){
        if (curTrialNum < numTotalTrials){
            switch (trialPhase){
                // different phases within a trial

                case 'trialInit':
                    // at the beginning of a new trial 

                    // decide whether the next stimulus has stim 0 or 1 in greater number
                    stimulus[curTrialNum] = Math.floor(2 * Math.random()); // 0 or 1
                    startConf = Math.random()/5 + 0.4; // start confidence randomly between 0.4-.6
                    confidence[curTrialNum] = startConf;
                    clickConfidence = false;

                    // increment or decrement stimulus level
                    incdec[curTrialNum] = numStimulusLevels - stair.levels[curTrialNum] + 1;

                    fruitStimuli.clear();

                    // get a random array of fruits and add 1 more for the other option of 2AFC with set-size incdec
                    randFruits = randSample(sequence(numStimuli), incdec[curTrialNum] + 1);

                    fruitChoices = randFruits.slice(-2); // get the last 2 fruits as the 2 options
                    randFruits.splice(-1) // remove the last option from the stimuli to be presented

                    if (stimulus[curTrialNum]){
                        // if true put the new fruit on the right otherwise on the left
                        temp = fruitChoices[1];
                        fruitChoices[1] = fruitChoices[0];
                        fruitChoices[0] = temp;
                    }

                    fruitOptions[0] = fruits[fruitChoices[0]];
                    fruitOptions[1] = fruits[fruitChoices[1]];
                    fruitOptions[0].setPosition(300,410)
                    fruitOptions[1].setPosition(460,410)

                    for ( i = 0; i < incdec[curTrialNum]; i++){
                        fruitStimuli.createMultiple({
                                key: 'fruit'+randFruits[i],
                                setScale: {x: fruitScale[randFruits[i]], y: fruitScale[randFruits[i]]},
                                frameQuantity: 1 // more red for stim=0
                            });
                    }
    
                    // start clock for the trial
                    stimulusTimedEvent = window.performance.now();
                    // numFlickersThisTrial = 0;

                    this.plugins.get('rexrandomplaceplugin').randomPlace(fruitStimuli.getChildren(),
                        {
                            radius: 30,
                            area: new Phaser.Geom.Rectangle(250, 310, 250, 220),
                        });
                    Phaser.Actions.SetVisible(fruitStimuli.getChildren(),0);

                    preStimulusWaitDur = preStimInterval[0] + 
                        Math.random() * (preStimInterval[1] - preStimInterval[0]);

                    confRespTime = 0;

                    textFeedbackMessage.setVisible(false);

                    trialPhase = 'preStimulus';

                    break;                        
                
                case 'preStimulus':

                    timeFromStimOnset = window.performance.now() - stimulusTimedEvent;
                    if (timeFromStimOnset > preStimulusWaitDur){
                        trialPhase = 'dispStimulus';
                    } 
                    // ELSE: do nothing 
                 
                    break;


                case 'dispStimulus':

                    timeFromStimOnset = window.performance.now() - (stimulusTimedEvent + preStimulusWaitDur);

                    if (timeFromStimOnset < stimulusDuration){
                        // display visual stimulus here
                        // from now until stimulusTimedEvent display the stimulus
                        Phaser.Actions.SetVisible(fruitStimuli.getChildren(),1);

                    }   else {
                        // stop showing the stimuli
                        Phaser.Actions.SetVisible(fruitStimuli.getChildren(),0);
                        trialPhase = 'postStimulus';
                    }

                    break;


                case 'postStimulus':

                    timeFromStimOnset = window.performance.now() - 
                        (stimulusTimedEvent + preStimulusWaitDur + stimulusDuration);

                    if (timeFromStimOnset > postStimInterval){

                        fruitOptions[0].setVisible(true);
                        fruitOptions[1].setVisible(true);
                        fruitOptions[0].setScale(fruitScale[fruitChoices[0]]);
                        fruitOptions[1].setScale(fruitScale[fruitChoices[1]]);
                        
                        // start reaction-1 time timer now
                        timeFromStimOffset = window.performance.now();

                        text_resp.x = 255;
                        text_resp.y = 200;
                        text_resp.text = "Use the left (<-) or\nright (->) arrow key\nto choose response";
                        text_resp.setVisible(true);
                                                
                        trialPhase = 'acceptResp';
                    }

                    break;                    

                case 'acceptResp':

                    // when accepting response
                    clickConfidence = false;

                    if (Phaser.Input.Keyboard.JustDown(cursors.left)){
                        currentInput = 0;
                        this.respAccepted(currentInput);
                    }
                    else if (Phaser.Input.Keyboard.JustDown(cursors.right)){
                        currentInput = 1;
                        this.respAccepted(currentInput);
                    } 
                    
                    break; 


                case 'acceptConf':

                    if (clickConfidence){
                        // accept the confidence slider value only when the confidence 
                        // slider has been clicked on once

                        let roundedConfidence = Math.round(currentConfidence*100)
                        text_conf.x = 405;
                        text_conf.y = 495 + (1-roundedConfidence)*2.2;

                        discreteConfidence = discretiseConfidence(
                                [roundedConfidence/100],
                                numConfLevels);
                        this.children.bringToTop(text_conf);
                        text_conf.text = (roundedConfidence) + "% confidence";
                        text_conf.setVisible(true);
                        for (let i=0; i<window.numConfLevels; i++){
                            textConfMarkers[i].setVisible(true);
                        }       

                        text_resp.x = 215;
                        text_resp.y = 190;
                        text_resp.text = "Press an arrow key to record\nconfidence when done";        

                        if (Phaser.Input.Keyboard.JustDown(cursors.up) ||
                        Phaser.Input.Keyboard.JustDown(cursors.down) ||
                        Phaser.Input.Keyboard.JustDown(cursors.left) ||
                        Phaser.Input.Keyboard.JustDown(cursors.right)){

                            // record confidence and move to the next phase of the trial
                            confidence[curTrialNum] = currentConfidence;
                            reaction2Time[curTrialNum] = window.performance.now() - timeFromStimOffset;

                            text_resp.setVisible(false);
                            fruitOptions[0].setVisible(false);
                            fruitOptions[1].setVisible(false);
                            confSlider[fruitChoices[0]].setVisible(false);
                            confSlider[fruitChoices[1]].setVisible(false);
                            this.children.bringToTop(text_conf);
                            text_conf.setVisible(false);
                            for (let i=0; i<window.numConfLevels; i++){
                                textConfMarkers[i].setVisible(false);
                                this.children.bringToTop(textConfMarkers[i]);
                            }
        
                            if (feedbackYesNo[curTrialNum] && curBlockFeedback){
                                trialPhase = 'feedbackDialog';

                                whichFeedbackMessage = Math.floor(numFeedbackMessages * Math.random());
                                feedbackYesNo[curTrialNum] = whichFeedbackMessage+1;
                            }
                            else{
                                trialPhase = 'postTrial';
                            }
                        }
                
                    }
                    else{
                        // if confidence slider has not yet been clicked and if participant 
                        // wants to still change their mind about the response
                        // let them
                        if (currentInput && Phaser.Input.Keyboard.JustDown(cursors.left)){
                            currentInput = 0;

                            // record change in mind
                            mindChange.n++;
                            mindChange.trialNum[mindChange.n] = curTrialNum;
                            mindChange.response[mindChange.n] = currentInput;

                            this.respAccepted(currentInput);
                            mindChange.reaction1Time[mindChange.n] = nowTime - timeFromStimOffset;
                            timeFromStimOffset = nowTime;


                        }
                        else if (!currentInput && Phaser.Input.Keyboard.JustDown(cursors.right)){
                            currentInput = 1;

                            mindChange.n++;
                            mindChange.trialNum[mindChange.n] = curTrialNum;
                            mindChange.response[mindChange.n] = currentInput;

                            this.respAccepted(currentInput);
                            mindChange.reaction1Time[mindChange.n] = nowTime - timeFromStimOffset;
                            timeFromStimOffset = nowTime;


                        } 
                    }

                    break;

                case 'feedbackDialog' :
                        
                    this.showFeedbackDialog();

                    trialPhase = 'wait';

                //     break;

                // case 'waitForDialogResponse':

                    eventsCenter.once('page10complete', function () {
                        // record the time at which confidence response is given
                        confRespTime = window.performance.now();
                        trialPhase = 'feedback';
                        }, this);

                    break;


                case 'feedback' :
                    
                    timeFromConfOnset = window.performance.now() - 
                    confRespTime;

                    if (timeFromConfOnset < feedbackInterval){
                   
                        if (correct[curTrialNum] ){
                            // feedback for correct

                            if (timeFromConfOnset > feedbackFaceAfter){
                                textFeedback.x = 315;
                                textFeedback.setColor('#0b0');
                                textFeedback.text = "Correct";
                                fbPosImageShadow.setVisible(true);
                                fbPosImage.setVisible(true);
                                
                                textFeedback.setVisible(true);

                            }
                            if (timeFromConfOnset > feedbackFaceAfter + feedbackMsgAfter){

                                textFeedbackMessage.x = 220;
                                textFeedbackMessage.text = positiveMessages[whichFeedbackMessage];
                                textFeedbackMessage.setVisible(true);

                            }
                        }
                        else{
                            // feedback for incorrect

                            if (timeFromConfOnset > feedbackFaceAfter){
                                textFeedback.x = 298;
                                textFeedback.setColor('#f00');
                                textFeedback.text = "Incorrect";
                                fbNegImageShadow.setVisible(true);
                                fbNegImage.setVisible(true);
                                
                                textFeedback.setVisible(true);
        
                            }
                            if (timeFromConfOnset > feedbackFaceAfter + feedbackMsgAfter){

                                textFeedbackMessage.x = 200;
                                textFeedbackMessage.text = negativeMessages[whichFeedbackMessage];
                                textFeedbackMessage.setVisible(true);
                            }
                        }

                    }
                    else{
                        timeFromConfOnset = window.performance.now();
                                     
                        textFeedback.setVisible(false);
                        textFeedbackMessage.setVisible(false);
                        fbPosImage.setVisible(false);
                        fbPosImageShadow.setVisible(false);
                        fbNegImage.setVisible(false);
                        fbNegImageShadow.setVisible(false);
                        
                        text_resp.x = 250;
                        text_resp.y = 360;
                        text_resp.setScale = 1.25;
                        text_resp.text = " Press an arrow key\n to continue";

                        trialPhase = 'postFeedbackInterval';
                    }
                    break;
                    

                case 'postFeedbackInterval':

                    text_resp.setVisible(true);

                    if (Phaser.Input.Keyboard.JustDown(cursors.up) ||
                    Phaser.Input.Keyboard.JustDown(cursors.down) ||
                    Phaser.Input.Keyboard.JustDown(cursors.left) ||
                    Phaser.Input.Keyboard.JustDown(cursors.right)){
                        text_resp.setVisible(false);

                        trialPhase = 'postTrial';
                    }

                    break;

                case 'postTrial':

                        stair = updateStair(stair, correct[curTrialNum], 2); // 3rd argument is 2 for 2-down-1-up
    
                        curTrialNum++;
    
                        trialPhase = 'trialInit';

                    break;
            }
        } 
        else{
            this.saveData();

            taskPhase = 'endblock';
        }

    }

    respAccepted(respNum){
        response[curTrialNum] = respNum;
        correct[curTrialNum] = !(stimulus[curTrialNum] ^ response[curTrialNum]);

        // record time from stimulus offset as response-1 time
        nowTime = window.performance.now();
        reaction1Time[curTrialNum] = nowTime - timeFromStimOffset;
        // reset timeFromStimOffset to get confidence (response-2) time
        timeFromStimOffset = nowTime;
        
        // decide whether to give feedback or not
        if (curBlockFeedback){
            if (correct[curTrialNum]){
                feedbackYesNo[curTrialNum] = Math.random() < probFeedback.corr[curBlockFeedback-1];
            }
            else {
                feedbackYesNo[curTrialNum] = Math.random() < probFeedback.incorr[curBlockFeedback-1];
            }
        }

        trialPhase = 'acceptConf';

        text_resp.x = 250;
        text_resp.y = 190;
        text_resp.text = "Click/Drag the slider\nto select confidence\nin your choice";

        fruitOptions[respNum].setScale(fruitScale[fruitChoices[respNum]] * chosenOptionSizeIncrease);
        fruitOptions[1-respNum].setScale(fruitScale[fruitChoices[1-respNum]]);
        confSlider[fruitChoices[1-respNum]].setVisible(false);

        confSlider[fruitChoices[respNum]].setValue(startConf);
        clickConfidence = false;
        confSlider[fruitChoices[respNum]].setVisible(true);

    }

    saveData(){
        var memResults = {
            taskType: curTaskNum, // memory task
            curBlockFeedback: curBlockFeedback,
            curTaskBlock: window.practiceOrFinal[curTaskNum]? window.curTaskBlock+1 : 0,
            stimulus: stimulus,
            response: response,
            confidence: confidence,
            correct: correct,
            incdec: incdec,
            feedbackYesNo: feedbackYesNo,
            mindChange: mindChange,
            stair: stair,
            reaction1Time: reaction1Time,
            reaction2Time: reaction2Time
        };

        saveConfTaskData(window.subjID, window.expName, memResults)
    }

    showFeedbackDialog(){
   
        var mainTxt = ( " The auditor of Fruitville is here\n"+
                        " to evaluate your response. \n\n"+
                        " Check how you performed..."
                        );
        var buttonTxt = "Check response";
        var pageNo = 10;
        this.instructionsPanel = new InstructionsPanel(this, 
        gameWidth/2, gameHeight/2,
        pageNo, auditDialogTitle, mainTxt, buttonTxt);
    }

    createTaskItems(){

        for (let i = 0; i < numStimuli; i++){
            fruits[i] = this.add.image(i*15,400,'fruit'+i).setScale(fruitScale[i]);
            fruits[i].setVisible(false);
            // fruits[1].setVisible(true);    

            // make a confidence slider for each of the fruits
            confSlider[i] = this.rexUI.add.slider({
                x: 380,
                y: 400,
                width: 20,
                height: 250,
                orientation: 'v',
                track: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[0]),
                indicator: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[1]),
                thumb: this.add.image(300,170,'fruit'+i).setScale(fruitScale[i]*.85),
                input: 'click', // 'drag'|'click'
                valuechangeCallback: function (value) {
                    if (curTrialNum!=undefined){
                        // confidence[curTrialNum] = 1-value; // subtract from 1 because sliders are inverted
                        currentConfidence = 1-value;
                    }
                    clickConfidence = true;
                }}).layout();
            confSlider[i].setVisible(false);
        }

        fbPosImageShadow = this.add.image(380 + offsetShadow.x, 390 + offsetShadow.y,'fbPos');
        fbPosImage = this.add.image(380,390,'fbPos');
        fbPosImageShadow.tint = 0x000000;
        fbNegImageShadow = this.add.image(380 + offsetShadow.x,390 + offsetShadow.y,'fbNeg');
        fbNegImage = this.add.image(380,390,'fbNeg');
        fbNegImageShadow.tint = 0x000000;
        fbPosImage.setScale(1.4);
        fbNegImage.setScale(1.4);
        fbPosImageShadow.setScale(1.4);
        fbNegImageShadow.setScale(1.4);
        fbPosImage.setVisible(false);
        fbNegImage.setVisible(false);
        fbPosImageShadow.setVisible(false);
        fbNegImageShadow.setVisible(false);

        text_resp = this.add.text(250,300,"Press an arrow key\n(up/down/left/right)\nto begin...",{
            align:'center', color: '#fff', strokeThickness: 3, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        text_resp.scale = 1.35;

        text_conf = this.add.text(300,200,"",{
            align:'center', color: '#fff', strokeThickness: 4, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        text_conf.scale = 1.3;
        text_conf.setVisible(false);

        textFeedbackMessage = this.add.text(220,450,"Additional feedback message",{
            align:'center', color: '#fff', strokeThickness: 3, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        textFeedbackMessage.setVisible(false);
        textFeedbackMessage.setScale(1.4);

        textFeedback = this.add.text(320,300,"Correct/Incorrect",{
            align:'center', color: '#090', strokeThickness: 3, 
            stroke: '#000', fontSize: 20,
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        textFeedback.setVisible(false);
        textFeedback.setScale(1.5);

        fullscreenButton = addFullscreenButton(this);

        for (let i=0; i<window.numConfLevels; i++){
            textConfMarkers[i] = this.add.text(285, 280+i*54.5,
                window.confidenceMarkers[window.numConfLevels-i-1],{
                align:'right', color: '#fff', strokeThickness: 3, 
                stroke: '#000', fontSize: 20,
                shadow: {offsetX: .5, offsetY: .5, stroke: true}
            });
            textConfMarkers[i].setVisible(false);
            this.children.bringToTop(textConfMarkers[i]);
        }
    }

    nextScene() {
        let lastReversals = stair.reversals.slice(-window.meanLastReversals);

        if (lastReversals.length>0){
            window.thresholdedInitLevels[curTaskNum] = 
            Math.ceil(sum(lastReversals)/lastReversals.length);    
        }

        if (window.practiceOrFinal[curTaskNum]){
            // if final
            window.fruitvilleStage = 8;
            window.finalTaskState[window.curTaskBlock] = 2;
            ++window.curTaskBlock;
        }
        else{
            // if practice
            window.fruitvilleStage = 6;
            window.practiceOrFinal[curTaskNum] = 1; // practice is done, put it on final task mode
        }
        this.scene.start('fruitville');    
    }


}


