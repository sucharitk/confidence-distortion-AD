
import eventsCenter from './eventsCenter.js';
import { saveStartTimeData } from './db/saveData.js';
// import { stimulusGrid, numStimuli , numStimulusLevels} from './eventsCenter.js';
import InstructionsPanel from "./instructionsPanel.js";

// initialise the constants
const stimulusDuration = 1000; // in milliseconds
const flickerEvery = 225; // re-allocate random position of stimuli
const timesFlicker = linspace(flickerEvery,stimulusDuration,stimulusDuration/flickerEvery);

const stimulusGrid = [11, 11]; // grid of berries
const numStimuli = stimulusGrid[0]*stimulusGrid[1]; // total number of berries
const numStimulusLevels = numStimuli/2; // number of stimullus levels

const stimLevels = Array.from({length: numStimulusLevels}, (_, i) => i + 1);
// const startLevel = Math.round(.2 * stimLevels.length); // start the task at the mid point of levels (.5)
var numTotalTrials;

const scaleFruitStimuli = .033;
const scaleBerryOptions = 0.08;
const numConfLevels = 5; // number of levels of confidence
var startConf = .5; // starting value of confidence to display 
const preStimInterval = [600, 750]; // random value in this interval
const postStimInterval = 200; // random value in this interval
const feedbackInterval = 1900;
const feedbackFaceAfter = 400;
const feedbackMsgAfter = 300;
const chosenOptionSizeIncrease = 1.6;

const stim12 = [0, 1]; // there are different colours of diamonds, which ones to use as stim1 and stim2

const offsetShadow = {x: .75, y: 1};

var berries;
var berry0;
var berry1;
var cursors;
var fbPosImage;
var fbPosImageShadow;
var fbNegImage;
var fbNegImageShadow;

var timeFromStimOnset;
var timeFromConfOnset = 0;
var confRespTime = 0;

var curTrialNum;
var preStimulusWaitDur;
var numFlickersThisTrial;
var taskPhase;

var trialPhase;
var prevTrialPhase;
var correct;
var confidence=[];
var incdec; // whether to increment or decrement on the curent trial and by how much

var text_resp;
var text_conf;
var textFeedback;
var textFeedbackMessage;
var textConfMarkers = {};
var ynDialog;
var titleText;
var mainText;
var fullscreenButton;

var confSlider0;
var confSlider1;
var clickResponse;
var clickConfidence;
var currentConfidence;
var discreteConfidence;
var currentInput;

var gameHeight;
var gameWidth;
var auditDialogTitle;

var stimulusTimedEvent;

var speSlider; // slider for self-performance estimate

export default class TaskPerceptionHelp extends Phaser.Scene
{
    constructor ()
    {
        super({
            key: 'perceptionTaskHelp'
        });
    }

    preload ()
    {
        
        this.load.scenePlugin({
            key: 'rexuiplugin',
            url: './src/phaser/rexuiplugin.min.js',
            sceneKey: 'rexUI'
        });  

        this.load.spritesheet('fullscreen', './assets/fullscreen.png', {frameWidth: 64, frameHeight: 64})
        this.load.image('tree','./assets/tree_2.png', { frameWidth: 500, frameHeight: 500 })
        this.load.image('bush1','./assets/bush_4.png', { frameWidth: 500, frameHeight: 500 })
        this.load.image('bush2','./assets/bush_9.png', { frameWidth: 500, frameHeight: 500 })
        this.load.image('bg', './assets/clouds.png');
        this.load.spritesheet('tiles', './assets/fantasy-tiles.png', { frameWidth: 64, frameHeight: 64 });
        this.load.image('berry0', './assets/raspberry.png');
        this.load.image('berry1', './assets/black-berry-dark.png');

        this.load.image('fbPos', './assets/1f600.png');
        this.load.image('fbNeg', './assets/1f615.png');
        this.load.image('tickMark', './assets/2611.png');

        // plugin for randomising the position of the stimuli on every trial
        this.load.plugin(
            'rexrandomplaceplugin', 
            './src/phaser/rexrandomplaceplugin.min.js', 
            true);

    }

    create ()
    {
        // initialisations
        saveStartTimeData(subjID, expName, (window.timeStampOrder++)+'_perceptionTaskHelp');

        // background image
        this.add.image(400, 0, 'bg').setOrigin(0.5, 0.02);
        // tree
        this.add.image(40, 310, 'tree').setOrigin(0.4, 0.5).setScale(1.2);
        // bushes
        this.add.image(430, 360, 'bush2').setOrigin(0.1, 0.5).setScale(1.2);
        this.add.image(300, 235, 'bush1').setOrigin(0.4, 0.5).setScale(1.6);
        
        // tiles at the bottom
        for (let i = 0; i < 13; i++){
            this.add.image(64 * i, 580, 'tiles', 1).setOrigin(0);
        }

        gameHeight = this.sys.game.config.height;
        gameWidth = this.sys.game.config.width;

        auditDialogTitle = 'You have been chosen for an audit';

        this.createTaskItems();

        fbPosImageShadow = this.add.image(380 + offsetShadow.x, 390 + offsetShadow.y,'fbPos');
        fbPosImage = this.add.image(380,390,'fbPos');
        fbPosImageShadow.tint = 0x000000;
        fbNegImageShadow = this.add.image(380 + offsetShadow.x,390 + offsetShadow.y,'fbNeg');
        fbNegImage = this.add.image(380,390,'fbNeg');
        fbNegImageShadow.tint = 0x000000;
        fbPosImage.setScale(1.4);
        fbNegImage.setScale(1.4);
        fbPosImageShadow.setScale(1.4);
        fbNegImageShadow.setScale(1.4);
        fbPosImage.setVisible(false);
        fbNegImage.setVisible(false);
        fbPosImageShadow.setVisible(false);
        fbNegImageShadow.setVisible(false);

        // define cursor keys
        cursors = this.input.keyboard.createCursorKeys();

        // create a blank group for the collective berry stimuli
        berries = this.add.group();
        // set stimui to invisible initially
        Phaser.Actions.SetVisible(berries.getChildren(),0);

        curTrialNum = 0;

        taskPhase = 'instructions';

        trialPhase = 'opening';
        // trialPhase = 'spe';
        prevTrialPhase = '';
    }

    update (){
        switch (taskPhase){
            case 'instructions':
                this.showInstructions();
                break;

            case 'task':
                this.doTask();
                break;

            case 'endblock':
                this.nextScene();
                break;
        }
    }
    
    showInstructions(){

        // show instructions

        switch (trialPhase){

            case 'opening':
                trialPhase = 'wait';
                this.openingInstructions();
                break;

            case 'anotherTrial':
                trialPhase = 'wait';

                mainText = (" You probably noticed that there were more  \n" +
                            " Raspberries (red) than Blackberries (dark\n blue) on that trial.\n\n" + 
                            " Let us see another example. This time there \n"+
                            " will be more Blackberries. \n\n"+
                            " Go ahead and click 'Proceed' again...\n"
                            );
           
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                1,  titleText, mainText, "Proceed");

                eventsCenter.once('page1complete', function () {

                    taskPhase = 'task';
                    prevTrialPhase = 'anotherTrial';
                    trialPhase = 'trialInit';
        
                    incdec = 30;
        
                }, this);

                break;

            case 'harderTrial':
                trialPhase = 'wait';

                mainText = (" Of course, your task will not always be this easy.\n" +
                            " There will be times where one type of berry is\n" + 
                            " only slightly larger in number than the other.\n\n"+
                            " Next, you will see a slightly more difficult \n"+
                            " trial with more Blackberries...\n"
                            );
           
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                1,  titleText, mainText, "Proceed");

                eventsCenter.once('page1complete', function () {

                    taskPhase = 'task';
                    prevTrialPhase = 'harderTrial';
                    trialPhase = 'trialInit';
        
                    incdec = 15;
        
                }, this);

                break;

            case 'showResponse':
                trialPhase = 'wait';

                titleText = 'Response Buttons';
                mainText = (" After viewing the berries, you will be asked\n" +
                            " to report which of the two you thought were\n"+
                            " greater in number.\n\n"+
                            ' You can select your response by pressing the \n'+
                            ' left (<-) or the right (->) arrow key on  \n'+
                            ' your keyboard.\n\n'+
                            " At this stage, if you accidentally press the \n"+
                            " wrong key, you can change your response by \n"+
                            " pressing the other key.\n\n"+
                            " As earlier, if your performance on this task\n"+
                            " is among the top 20% of the participants,\n"+
                            " you will receive a £1 bonus.\n"
                );
           
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                1,  titleText, mainText, "Proceed");

                eventsCenter.once('page1complete', function () {

                    taskPhase = 'task';
                    prevTrialPhase = 'showResponse';
                    trialPhase = 'trialInit';
        
                    incdec = 15;
        
                }, this);

                break;

                
            case 'confidence':
                trialPhase = 'wait';

                titleText = 'Confidence';
                mainText = (" In addition to your choice of which berry was more\n"+
                            " in number, you will also be asked to report how\n"+
                            " confident you were in your chosen response. \n\n"+
                            " The amount of confidence you have in your response\n"+
                            " will allow Fruitvillians to assess how much to\n"+ 
                            " rely on your chosen option when deciding to \n"+
                            " harvest one berry or the other.\n\n"+
                            " You will report your confidence on a range of \n"+
                            " 0% to 100% using a slider where 0% = 'no confidence'\n"+
                            " and 100% = 'maximum confidence.\n\n"+
                            " Click 'Proceed' to try.\n"          
                );
            
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                1,  titleText, mainText, "Proceed");

                eventsCenter.once('page1complete', function () {

                    taskPhase = 'task';
                    prevTrialPhase = 'confidence';
                    trialPhase = 'trialInit';
        
                    incdec = 15;
        
                }, this);

            break;                

            case 'feedback':
                trialPhase = 'wait';
                titleText = "Audit";
                mainText = (" Finally, in order to test how trustworthy\n"+
                            " your berry choices are, Fruitville will \n"+
                            " occasionally hire an auditor to evaluate \n"+
                            " whether your response on a trial was correct\n"+
                            " or incorrect. \n\n"+ 
                            " On these few trials, after you record your\n"+
                            " response, the auditor will let you know \n"+
                            " whether you were correct or incorrect on that \n"+
                            " trial.\n\n"+
                            " 'Proceed' to try a few trials with all the\n"+
                            " steps including the audit."          
                );
            
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                1,  titleText, mainText, "Proceed");

                eventsCenter.once('page1complete', function () {

                    taskPhase = 'task';
                    prevTrialPhase = 'feedback';
                    trialPhase = 'trialInit';
        
                    incdec = (Math.ceil(2*Math.random())-1) * 25;
        
                }, this);

            break;
    
            case 'spe':
                trialPhase = 'wait';

                titleText = "How well did you think you do?";

                mainText = (" Once a sequence of trials is completed, \n"+
                            " you will also be asked to estimate the \n"+
                            " number of trials from that sequence that\n"+
                            " you think you chose correctly.\n\n"+
                            " For example, we just showed you 5 sample \n"+
                            " trials. How many of these 5 trials did you \n"+
                            " answer correctly?\n\n"+
                            " 'Proceed' to report..."          
                );
            
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                1,  titleText, mainText, "Proceed");

                eventsCenter.once('page1complete', function () {

                    taskPhase = 'task';
                    prevTrialPhase = 'spe';
                    trialPhase = 'spe';
        
                }, this);

                clickConfidence = false;

                break;

        }

    }

    openingInstructions()
    {
        titleText = "The 'Berry Yield' task ";
        mainText = (" The berry growers of Fruitville have a number \n" +
                    " of shrubberies that contain two types of berries: \n\n" + 
                    "       Raspberries    and Blackberries   \n\n"+
                    " As they can only harvest one type of berry at \n"+
                    " a time, and as the current market price for both\n"+
                    " is similar, they would like your help to decide \n"+
                    " which of the two is more abundant. \n"
                    );
   
        this.instructionsPanel = new InstructionsPanel(this, 
        gameWidth/2, gameHeight/2,
        1,  titleText, mainText, "More instructions");

        // berries for the two response options
        berry0 = this.add.image(320,270,'berry0').setScale(.07);
        berry1 = this.add.image(610, 270,'berry1').setScale(.07);
        berry0.setVisible(true);
        berry1.setVisible(true);
        
        eventsCenter.once('page1complete', function () {
        mainText = (' In what follows, you will be shown a series of\n'+
                    " images from each shrubbery for a brief duration \n"+
                    " containing the two berries over many 'trials'. \n\n"+
                    " Your task is to decide if a trial contained more\n"+
                    " raspberries   or more blackberries   .\n\n"+
                    " Click 'Proceed' to see an example of such a trial."
            );

            this.instructionsPanel = new InstructionsPanel(this, 
            gameWidth/2, gameHeight/2,
            2, titleText, mainText, 'Proceed');

            berry0.setScale(.05);
            berry1.setScale(.05);
            berry0.x = 225;
            berry0.y = 340;
            berry1.x = 555;
            berry1.y = 340;
            
            this.children.bringToTop(berry0);
            this.children.bringToTop(berry1);
        }, this);

        eventsCenter.once('page2complete', function () {
            berry0.setVisible(false);
            berry1.setVisible(false);

            taskPhase = 'task';
            prevTrialPhase = 'opening';
            trialPhase = 'trialInit';

            incdec = -30;
         
        }, this);        
    }
        
    doTask(){
        // if (curTrialNum < numTotalTrials)
        // {
            switch (trialPhase)
            {
                // different phases within a trial

                case 'trialInit':
                    // at the beginning of a new trial 

                    text_resp.setVisible(false);
                    berry0.setVisible(false);
                    berry1.setVisible(false);

                    berries.clear();
                    // add reds
                    berries.createMultiple({
                        key: 'berry'+stim12[0],
                        setScale: {x: scaleFruitStimuli, y: scaleFruitStimuli},
                        frameQuantity: numStimulusLevels-incdec // more red for stim=0
                    });
                    // add blues
                    berries.createMultiple({
                        key: 'berry'+stim12[1],
                        setScale: {x: scaleFruitStimuli, y: scaleFruitStimuli},
                        frameQuantity: numStimulusLevels+incdec
                    });
        
                    // start clock for the trial
                    stimulusTimedEvent = window.performance.now();
                    numFlickersThisTrial = 0;

                    this.plugins.get('rexrandomplaceplugin').randomPlace(berries.getChildren(),
                        {
                            radius: 10,
                            area: new Phaser.Geom.Rectangle(230, 300, 300, 260),
                        });
                    Phaser.Actions.SetVisible(berries.getChildren(),0);

                    preStimulusWaitDur = preStimInterval[0] + 
                        Math.random() * (preStimInterval[1] - preStimInterval[0]);

                    startConf = Math.random()/5 + 0.4;

                    trialPhase = 'preStimulus';

                    break;                        
                
                case 'preStimulus':

                    timeFromStimOnset = window.performance.now() - stimulusTimedEvent;
                    if (timeFromStimOnset > preStimulusWaitDur){
                        
                        trialPhase = 'dispStimulus';

                    } 
                    // ELSE: do nothing 
                 
                    break;


                case 'dispStimulus':

                    timeFromStimOnset = window.performance.now() - (stimulusTimedEvent + preStimulusWaitDur);

                    if (timeFromStimOnset < stimulusDuration){
                        // display visual stimulus here

                        if (timeFromStimOnset > timesFlicker[numFlickersThisTrial]){
                            numFlickersThisTrial++;
                            this.plugins.get('rexrandomplaceplugin').randomPlace(berries.getChildren(),
                            {
                                radius: 8,
                                area: new Phaser.Geom.Rectangle(230, 300, 300, 260),
                            });
                        }

                        // from now until stimulusTimedEvent display the stimulus
                        Phaser.Actions.SetVisible(berries.getChildren(),1);

                    }   else {
                        // stop showing the stimuli
                        Phaser.Actions.SetVisible(berries.getChildren(),0);

                        trialPhase = 'postStimulus';
                    }

                    break;


                case 'postStimulus':

                    timeFromStimOnset = window.performance.now() - 
                        (stimulusTimedEvent + preStimulusWaitDur + stimulusDuration);

                    if (timeFromStimOnset > postStimInterval){
                        
                        switch (prevTrialPhase){
                            case 'opening':
                                taskPhase = 'instructions';
                                trialPhase = 'anotherTrial';
                                break;

                            case 'anotherTrial':
                                taskPhase = 'instructions';
                                trialPhase = 'harderTrial';
                                break;
                            
                            case 'harderTrial':
                                taskPhase = 'instructions';
                                trialPhase = 'showResponse';
                                break;

                            case 'showResponse':
                            case 'confidence':
                            case 'feedback':
                                trialPhase = 'acceptResp';
                                berry0.x = 299; berry0.y = 400;
                                berry1.x = 477; berry1.y = 400;
                                berry0.setScale(scaleBerryOptions);
                                berry1.setScale(scaleBerryOptions);                
                                berry0.setVisible(true);
                                berry1.setVisible(true);
                                clickResponse = 0;
                        }
                    }

                    break;                    

                case 'acceptResp':

                    switch (prevTrialPhase){
                        case 'showResponse':
                            // when showing instructions about choosing the response response
                            if (!clickResponse){
                                // first time in this trialPhase
                                text_resp.text = 
                                "Press the left (<-) or\nright (->) arrow key to\nchoose a response";
                            }
                            else if (clickResponse==1) {
                                // second time in this trialPhase
                                text_resp.text = 
                                "Now try choosing the\nother option with\nthe opposite arrow";
                            }
                            else if (clickResponse==2){
                                // third time here, go back to the instructions
                                text_resp.text = "Press the left or right\narrow key again to continue";
                            }
                            else {
                                taskPhase = 'instructions';
                                trialPhase = 'confidence';
                            }
                            text_resp.x = 230;
                            text_resp.y = 200;
                            break;

                        case 'confidence':
                        case 'feedback':
                            // when accepting response
                            if (!clickResponse){
                                text_resp.x = 230;
                                text_resp.y = 200;    
                                text_resp.text = 
                                "Press the left (<-) or\nright (->) arrow key to\nchoose a response";
                            }
                            else if (clickResponse==1) {
                                text_resp.x = 160;
                                text_resp.y = 150;
                                text_resp.text = "Now drag/click the middle berry icon\nupor down to select your confidence\n(or change your response and \nthen select confidence)";

                                switch (currentInput)
                                {
                                    case 0:
                                        confSlider0.setValue(startConf);
                                        confSlider0.setVisible(true);
                                        break;
                                    case 1:
                                        confSlider1.setValue(startConf);
                                        confSlider1.setVisible(true);
                                        break;

                                }
                                clickConfidence = false;
                                trialPhase = 'acceptConf';
                            }
                            break;
                    }

                    text_resp.setVisible(true);
            
                    if (Phaser.Input.Keyboard.JustDown(cursors.left)){
                        currentInput = 0;
                        clickResponse++;
                        berry0.setScale(scaleBerryOptions*chosenOptionSizeIncrease);
                        berry1.setScale(scaleBerryOptions);
                    
                    }
                    else if (Phaser.Input.Keyboard.JustDown(cursors.right)){
                        currentInput = 1;
                        clickResponse++;
                        berry0.setScale(scaleBerryOptions);
                        berry1.setScale(scaleBerryOptions*chosenOptionSizeIncrease);
                    } 

                    break; 


                case 'acceptConf':

                    if (clickConfidence){
                        // accept the confidence slider value only when the confidence 
                        // slider has been clicked on once

                        currentConfidence = currentInput ? Math.round((1-confSlider1.value)*100) : 
                        Math.round((1-confSlider0.value)*100)

                        text_conf.x = 400;
                        text_conf.y = 495 + (1-currentConfidence)*2.2;

                        discreteConfidence = discretiseConfidence(
                                [currentConfidence/100],
                                numConfLevels);

                        this.children.bringToTop(text_conf);
                        text_conf.text = (currentConfidence) + "% confidence";
                        text_conf.setVisible(true);
                        for (let i=0; i<window.numConfLevels; i++){
                            textConfMarkers[i].setVisible(true);
                            this.children.bringToTop(textConfMarkers[i]);
                        }

                        text_resp.x = 215;
                        text_resp.y = 190;
                        text_resp.text = "Press an arrow key to record\nconfidence when done";        

                        if (Phaser.Input.Keyboard.JustDown(cursors.up) ||
                        Phaser.Input.Keyboard.JustDown(cursors.down) ||
                        Phaser.Input.Keyboard.JustDown(cursors.left) ||
                        Phaser.Input.Keyboard.JustDown(cursors.right)){
                            // record confidence and move to the next phase of the trial
                            text_resp.setVisible(false);

                            berry0.setVisible(false);
                            berry1.setVisible(false);

                            confSlider0.setVisible(false);
                            confSlider1.setVisible(false);
    
                            text_conf.setVisible(false);
                            for (let i=0; i<window.numConfLevels; i++){
                                textConfMarkers[i].setVisible(false);
                            }
    
                            switch(prevTrialPhase){
                                case 'confidence':
                                    taskPhase = 'instructions';
                                    trialPhase = 'feedback';
                                    break;

                                case 'feedback':
                                    trialPhase = 'feedbackDialog';
                            }
                        }
                    }
                    else{
                        // if confidence slider has not yet been clicked and if participant 
                        // wants to still change their mind about the response
                        // let them
                        if (currentInput && Phaser.Input.Keyboard.JustDown(cursors.left)){
                            currentInput = 0;

                            berry0.setScale(scaleBerryOptions * chosenOptionSizeIncrease);
                            berry1.setScale(scaleBerryOptions);

                            confSlider0.setValue(startConf);
                            clickConfidence = false;
                            confSlider0.setVisible(true);
                            confSlider1.setVisible(false);
                        }
                        else if (!currentInput && Phaser.Input.Keyboard.JustDown(cursors.right)){
                            currentInput = 1;

                            berry1.setScale(scaleBerryOptions * chosenOptionSizeIncrease);
                            berry0.setScale(scaleBerryOptions);
 
                            confSlider1.setValue(startConf);
                            clickConfidence = false;
                            confSlider1.setVisible(true);
                            confSlider0.setVisible(false);
                        } 
                    }
                    break;

                case 'feedbackDialog' :
                    
                    this.showFeedbackDialog();
                    trialPhase = 'waitForDialogResponse';

                    break;
    
                case 'waitForDialogResponse':

                    eventsCenter.once('page10complete', function () {
                        // record the time at which confidence response is given
                        confRespTime = window.performance.now();
                        trialPhase = 'feedback';
                        }, this);

                    break;


                case 'feedback' :
                    
                    timeFromConfOnset = window.performance.now() - 
                    confRespTime;

                    if (timeFromConfOnset < feedbackInterval){
                        correct = !(incdec > 0 ^ currentInput);
                        if (correct){
                            // feedback for correct
                            if (timeFromConfOnset > feedbackFaceAfter){
                                textFeedback.x = 315;
                                textFeedback.setColor('#0b0');
                                textFeedback.text = "Correct";
                                fbPosImageShadow.setVisible(true);
                                fbPosImage.setVisible(true);

                                textFeedback.setVisible(true);
                            }
                        }
                        else{
                            // feedback for incorrect
                            if (timeFromConfOnset > feedbackFaceAfter){
                                textFeedback.x = 298;
                                textFeedback.setColor('#f00');
                                textFeedback.text = "Incorrect";
                                fbNegImageShadow.setVisible(true);
                                fbNegImage.setVisible(true);

                                textFeedback.setVisible(true);
                            }
                        }
                    }
                    else{
                        timeFromConfOnset = window.performance.now();
                                     
                        textFeedback.setVisible(false);
                        textFeedbackMessage.setVisible(false);
                        fbPosImage.setVisible(false);
                        fbPosImageShadow.setVisible(false);
                        fbNegImage.setVisible(false);
                        fbNegImageShadow.setVisible(false);

                        text_resp.x = 250;
                        text_resp.y = 360;
                        text_resp.setScale = 1.25;
                        text_resp.text = " Press an arrow key\n to continue";

                        trialPhase = 'postFeedbackInterval';
                    }
                    break;
                    

                case 'postFeedbackInterval':

                    text_resp.setVisible(true);

                    if (Phaser.Input.Keyboard.JustDown(cursors.up) ||
                    Phaser.Input.Keyboard.JustDown(cursors.down) ||
                    Phaser.Input.Keyboard.JustDown(cursors.left) ||
                    Phaser.Input.Keyboard.JustDown(cursors.right)){
                        text_resp.setVisible(false);

                        trialPhase = 'postTrial';
                    }
                    break;

                case 'postTrial':

                    curTrialNum++;

                    if (curTrialNum == window.numLearningTrials){
                        taskPhase = 'instructions';
                        trialPhase = 'spe';
                    }
                    else {
                        trialPhase = 'trialInit';
                        incdec = (Math.ceil(2*Math.random())-1) * 25;
                    }
                    break;

                case 'spe':
                    text_resp.text = "Drag the slider to choose\nthe number of correct trials.\nThen press an arrow key when done";
                    text_resp.x = 180;
                    text_resp.y = 280;

                    currentConfidence = (speSlider.value);

                    discreteConfidence = discretiseConfidence(
                            [currentConfidence],
                            window.numLearningTrials+1);

                    // this.children.bringToTop(text_conf);
                    text_conf.text = (discreteConfidence-1) + '/' + window.numLearningTrials + ' correct';
                    text_conf.x = 320;
                    text_conf.y = 390;
                    text_conf.setVisible(true);

                    speSlider.setVisible(true);
                    text_resp.setVisible(true);
                    if (clickConfidence && 
                        (Phaser.Input.Keyboard.JustDown(cursors.up) ||
                    Phaser.Input.Keyboard.JustDown(cursors.down) ||
                    Phaser.Input.Keyboard.JustDown(cursors.left) ||
                    Phaser.Input.Keyboard.JustDown(cursors.right)))
                    {
                        text_resp.setVisible(false);
                        text_conf.setVisible(false);
                        speSlider.setVisible(false);
                        trialPhase = 'understood';
                    }
                    break;

                case 'understood':

                    ynDialog = yesnoDialog(this, 'Repeat instructions?', 
                    " Those are all the instructions for this game.\n\n"+
                    " Would you like to see the instructions again?\n\n"+
                    " Click 'Yes' to repeat the instructions. \n\n"+
                    " Else, if you have understood the instructions\n"+
                    " completely, click 'No' to proceed.",
                    {x:400, y: 300}, 
                    function(index)
                    {

                        if (index){
                            window.fruitvilleStage = 2;
                        }
                        ynDialog.scaleDownDestroy(50);
                        taskPhase = 'endblock';
                        
                    },
                    ["Yes: show instructions again", "No: proceed"]);
            
                    taskPhase = 'wait';

                    break;

            }

    }

    showFeedbackDialog()
    {
        var mainTxt = ( " The auditor of Fruitville is here\n"+
                        " to evaluate your response. \n\n"+
                        " Check how you performed..."
                        );
        var buttonTxt = "Check response";
        var pageNo = 10;
        this.instructionsPanel = new InstructionsPanel(this, 
        gameWidth/2, gameHeight/2,
        pageNo, auditDialogTitle, mainTxt, buttonTxt);

    }

    nextScene() {
        if (window.fruitvilleStage == 2){
            // if participants have understood the instructions
            this.scene.start('fruitville');

        }
        else{
            // otherwise restart this help page
            this.scene.restart();
        }
    }

    createTaskItems(){
        // slider 0 to receive confidence for berry 0
        confSlider0 = this.rexUI.add.slider({
            x: 380,
            y: 400,
            width: 20,
            height: 250,
            orientation: 'v',
            track: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[0]),
            indicator: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[1]),
            thumb: this.add.image(300,170,'berry0').setScale(scaleBerryOptions),
            input: 'click', // 'drag'|'click'
            valuechangeCallback: function (value) {
                confidence[curTrialNum] = 1-value; // subtract from 1 because sliders are inverted
                clickConfidence = true;
            }}).layout();
        confSlider0.setVisible(false);
        // slider 1 to receive confidence for berry 1
        confSlider1 = this.rexUI.add.slider({
            x: 380,
            y: 400,
            width: 20,
            height: 250,
            orientation: 'v',
            track: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[0]),
            indicator: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[1]),
            thumb: this.add.image(320,170,'berry1').setScale(scaleBerryOptions),
            input: 'click', // 'drag'|'click'
            valuechangeCallback: function (value) {
                confidence[curTrialNum] = 1-value;
                clickConfidence = true;
            }}).layout();
        confSlider1.setVisible(false);

        speSlider = this.rexUI.add.slider({
            x: 380,
            y: 440,
            width: 250,
            height: 20,
            orientation: 'x',
            track: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[1]),
            indicator: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[2]),
            thumb: this.add.image(300,170,'tickMark').setScale(.4),
            input: 'click', // 'drag'|'click'
            valuechangeCallback: function (value) {
                // confidence[curTrialNum] = 1-value; // subtract from 1 because sliders are inverted
                clickConfidence = true;
            }}).layout();
        speSlider.setVisible(false);        

        text_resp = this.add.text(250,300,"Press an arrow key\n(up/down/left/right)\nto begin...",{
            align:'center', color: '#fff', strokeThickness: 3, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        text_resp.scale = 1.35;
        text_resp.setVisible(false);

        text_conf = this.add.text(300,200,"",{
            align:'center', color: '#fff', strokeThickness: 3, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        text_conf.scale = 1.3;
        text_conf.setVisible(false);

        textFeedbackMessage = this.add.text(400,250,"Additional feedback message",{
            align:'center', color: '#fff', strokeThickness: 3, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        textFeedbackMessage.setVisible(false);
        textFeedbackMessage.setScale(1.4);

        textFeedback = this.add.text(320,300,"Correct/Incorrect",{
            align:'center', color: '#090', strokeThickness: 3, 
            stroke: '#000', fontSize: 20,
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        textFeedback.setVisible(false);
        textFeedback.setScale(1.5);

        fullscreenButton = addFullscreenButton(this);

        for (let i=0; i<window.numConfLevels; i++){
            textConfMarkers[i] = this.add.text(285, 280+i*54.5,
                window.confidenceMarkers[window.numConfLevels-i-1],{
                align:'right', color: '#fff', strokeThickness: 3, 
                stroke: '#000', fontSize: 20,
                shadow: {offsetX: .5, offsetY: .5, stroke: true}
            });
            textConfMarkers[i].setVisible(false);
        }


    }

}


