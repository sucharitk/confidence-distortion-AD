import InstructionsPanel from "./instructionsPanel.js";

import eventsCenter from './eventsCenter.js';
import { saveSRETRecallData, saveStartTimeData } from "./db/saveData.js";


// const COLOR_LIGHT = 0x0705e7;
const frameColor = 0x060944;
var inputText;
var wordsSoFar;
var wordLists = {};
var wordsEntered = [];
var nWordsEntered = 0;
var submitAnswers;
var taskPhase;

var gameHeight;
var gameWidth;
var titleText;
var mainText;
var buttonText;
var pageNo;
var submitInstructions;
var stimulusTimedEvent;

export default class SRERecall extends Phaser.Scene{
    constructor (){
        super({
            key: 'sreRecall'
        });
    }

    preload (){
        this.load.scenePlugin({
            key: 'rexuiplugin',
            url: './src/phaser/rexuiplugin.min.js',
            sceneKey: 'rexUI'
        });  

        // this.load.spritesheet('fullscreen', './assets/fullscreen.png', {frameWidth: 64, frameHeight: 64})
        this.load.image('bg', './assets/clouds.png');
        this.load.spritesheet('tiles', './assets/fantasy-tiles.png', { frameWidth: 64, frameHeight: 64 });
        this.load.html('nameform', 'src/utils/textfield.html');
    }

    create (){
        // initialisations
        saveStartTimeData(subjID, expName, (window.timeStampOrder++)+'_sreRecall')

        // background image
        this.add.image(400, 0, 'bg').setOrigin(0.5, 0.02);
        // tiles at the bottom
        for (let i = 0; i < 13; i++){
            this.add.image(64 * i, 580, 'tiles', 1).setOrigin(0);
        }

        gameHeight = this.sys.game.config.height;
        gameWidth = this.sys.game.config.width;

        taskPhase = 'instructions';
    }


    update (){
        switch (taskPhase){
            case 'instructions':
                this.showInstructions();
                break;

            case 'task':
                this.doTask();
                break;

            case 'endblock':
                this.saveData();
                this.nextScene();
                break;
        }

    }

    showInstructions(){

        titleText = 'Word Memory Task';
        ///////////////////PAGE ONE////////////////////
        mainText = (    " This next task is connected to the self-description\n"+
                        " task that you just performed. \n\n" +
                        " Here, we ask you to try to recall as many of the \n" +
                        " words we just showed you (where you had indicated \n" +
                        " 'Yes' or 'No' for being self-descriptive)\n\n"+
                        " For example, while practicing the task, we showed\n"+
                        " you words like: healthy, tall, strange. Here, you\n"+
                        " will try to recall the ones for the final version.\n"
                        );
        buttonText = "More instructions";
        pageNo = 1;
        this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                pageNo, titleText, mainText, buttonText);


        eventsCenter.once('page1complete', function () {

            mainText = (
                " For this Word Memory Task, it does not matter  \n"+
                " whether you indicated Yes or No to those words \n"+
                " earlier. Here, we are only interested in HOW MANY \n"+
                " of those words you are able to recall correctly. \n\n"+
                " And, don't worry if you get the spelling of a word\n"+
                " wrong - that will not impact your score :). \n\n"+
                " Your performance on this task along with later \n"+
                " tasks (that we will indicate) will contribute to a \n"+
                " monetory bonus where the top 20% of participants \n"+
                " who have the highest number of correctly \n"+
                " remembered words will receive a £1 bonus!\n"

            );
            buttonText = "More instructions";
            pageNo = 2;

            this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                pageNo, titleText, mainText, buttonText);

            }, this);
                            
        ///////////////////PAGE TWO////////////////////
        eventsCenter.once('page2complete', function () {

            mainText = (
            " Once you click 'Proceed to task' below, you will \n"+
            " see an input box where you can type a word.\n\n"+
            " After entering each remembered word from the \n"+
            " earlier task, submit it by clicking \n 'Add word to list >>' \n\n"+
            " You will be able to see the submitted words as\n"+
            " a list on the right side.\n\n"+
            " Once you have entered all the words you can\n"+
            " remember, please click the button at the \n"+
            " bottom to finally submit your word list.\n"
            );
            buttonText = "Proceed to task";
            pageNo = 3;

            this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                pageNo, titleText, mainText, buttonText);

            }, this);
            

        eventsCenter.once('page3complete', function () {

            taskPhase = 'task';

            }, this);
    
            
            taskPhase = 'wait';
    }

    doTask(){

        stimulusTimedEvent = window.performance.now();

        // frame within which to show the entered words
        this.rexUI.add.roundRectangle(
            600, 300, 370, 600, 20, frameColor, 50);

        wordsSoFar = this.add.text(500,10, 'Words entered so far:', {
            strokeThickness: 3, stroke: '#000', color: '#0e4',
            fontSize: 17
        });
        wordLists[0] = this.add.text(420,20, '', {
            strokeThickness: 3, stroke: '#000', color: '#0e4',
            fontSize: 17
        });
        wordLists[1] = this.add.text(600,20, '', {
            strokeThickness: 3, stroke: '#000', color: '#0e4',
            fontSize: 17
        });

        var text = this.add.text(20, 150, 
            'Please enter words you remember\n'+
            'from the self-description task\n'+
            'irrespective of whether you chose\n'+
            'them as self-descriptive or not.\n'+
            'Enter the words one at a time in\n'+
            'the box below and after each word\n'+
            'click "Add word to list >>"',
            { color: 'white', fontSize: '18px ', align: 'center',
        strokeThickness: 3, stroke: 'black'});

        inputText = this.add.dom(200,360).createFromCache('nameform');

        inputText.addListener('click');

        inputText.on('click', function(event){
            if (event.target.name == 'submitButton'){

                var textField = this.getChildByName('nameField');
                
                if (textField.value !== ''){
                    wordsEntered[nWordsEntered] = textField.value;

                    nWordsEntered++;
                    submitAnswers.setVisible(true);
                    submitInstructions.setVisible(true);

                    wordLists[+(nWordsEntered>26)].text = wordLists[+(nWordsEntered>26)].text + '\n' + nWordsEntered + '. ' +
                    textField.value;    

                    textField.value = '';
                                        
                }
                else{
                    this.scene.tweens.add({
                        targets: text,
                        alpha: 0.2,
                        duration: 250,
                        ease: 'Power3',
                        yoyo: true
                    });
                }
            }
        });

        submitInstructions = this.add.text(50, 460,
            '? Once you have finished entering\n'+
            '  ALL the words you remember, \n'+
            '  click below to proceed',
            {color: 'black', fontsize: '22px', align: 'center'}
            );
        submitInstructions.setVisible(false);

        submitAnswers = createButton(this, 'Submit word list', 
        {x: 220, y: 540, width: 100, height: 50},
        function(scene) {
            var ynDialog = yesnoDialog(scene, 'Submit word list', 
            " Do you remember any more words? Click\n"+
            " 'Yes' if you do and return to the task.\n"+
            " Otherwise, click 'No' to end word recall\n"+
            " and proceed to the next task.",
            {x:350, y: 200}, 
            function(index){
                switch(index){
                    case 0: 
                        ynDialog.scaleDownDestroy(50); 
                        break;
                        
                    case 1:
                        taskPhase = 'endblock';
                        break;
                }
            },
            ['Yes: return to task',
            'No: end word recall']);
        });
        submitAnswers.setVisible(false);

        taskPhase = 'wait';
    }

    saveData(){
        saveSRETRecallData(window.subjID, window.expName, {
            words: wordsEntered,
            totalRecallTime: window.performance.now() - stimulusTimedEvent
        });
    }

    nextScene() {
        // window.currentScene++;
        window.sretState = 2;
        window.mainTaskState = 1;
        this.scene.start('welcome');
    }


}
