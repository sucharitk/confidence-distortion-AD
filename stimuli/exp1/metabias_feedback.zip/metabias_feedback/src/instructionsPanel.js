
// import our custom events centre for passsing info between scenes
import eventsCenter from './eventsCenter.js'

// initialize diplay vars

export default class InstructionsPanel {
    constructor(scene, x, y, pageNo, titleTxt, mainTxt, buttonTxt) {
    this.scene = scene;
    
    var instrPanel = createInstrPanel(scene, pageNo, titleTxt, mainTxt, buttonTxt)
        .setPosition(x, y)
        .layout()
        .popUp(500); 
    }  
}

////////////////////functions for making in-scene graphics//////////////////////////
///////////main panel////////////
var createInstrPanel = function (scene, pageNo, titleTxt, mainTxt, buttonTxt) {
    // create panel components
    var dialog = createDialog(scene, pageNo, titleTxt, mainTxt, buttonTxt);
    var mainPanel = scene.rexUI.add.fixWidthSizer({
        orientation: 'x', //vertical stacking
        width: 10
        }).add(
            dialog, // child
            0, // proportion
            'center', // align
            0, // paddingConfig
            false, // expand
        )
    .layout();
    
    dialog
        .once('button.click', function (button, groupName, index) {
            dialog.scaleDownDestroy(100);                  // destroy panel components
            eventsCenter.emit('page'+pageNo+'complete');   // emit completion event
        }, this)
        .on('button.over', function (button, groupName, index) {
            button.getElement('background').setStrokeStyle(2, 0xffffff); // when hover
        })
        .on('button.out', function (button, groupName, index) {
            button.getElement('background').setStrokeStyle();
        });
    
    return mainPanel;
};

///////////popup dialog box//////
var createDialog = function (scene, pageNo, titleTxt, mainTxt, buttonTxt) {
    var textbox = scene.rexUI.add.dialog({
        // x: 0,
        // y: 0,
        // width: 10,
    background: scene.rexUI.add.roundRectangle(0, 0, 10, 10, 20, window.backgrCol),
    
    title: scene.rexUI.add.label({
        background: scene.rexUI.add.roundRectangle(0, 0, 10, 40, 20, window.titleCol),
        text: scene.add.text(0, 0, titleTxt, {
                    fontSize: '24px'
                    }),
        align: 'center',
        space: {
            left: 15,
            right: 15,
            top: 10,
            bottom: 10
        }
    }),

    // content: scene.rexUI.add.BBCodeText(0, 0, mainTxt, {
    //     //fontSize: "20px",
    //     font: '20px monospace',
    //     align: 'center',
    //     color: '#000',
    //     underline: {color: '#000',
    //                 offset: 6,
    //                 thickness: 3}
    // }),
    content: scene.add.text(0, 0, mainTxt, {
        fontSize: '24px'
    }),
        
    actions: [
        createLabel(scene, buttonTxt)
    ],
        
    space: {
        title: 25,
        content: 10,
        action: 10,
        left: 10,
        right: 10,
        top: 10,
        bottom: 10,
    },
    align: {
        actions: 'center',
    },
    expand: {
        content: false, 
    }
    })
    .layout();
    
    return textbox;
};

/////////button labels////////////////////////////
var createLabel = function (scene, text) {
    return scene.rexUI.add.label({
        background: scene.rexUI.add.roundRectangle(0, 0, 0, 40, 20, window.buttonCol[1]),
        text: scene.add.text(0, 0, text, {
            fontSize: '20px'
        }),
        align: 'center',
        width: 40,
        space: {
            left: 10,
            right: 10,
            top: 10,
            bottom: 10
        }
    });
};