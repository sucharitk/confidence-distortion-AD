function initStair(upordown, nlevels, len, jumps, whstair)
{

	var stair = {
		nstairs: upordown.length,
		len: len,
		nlevels: nlevels,
		jumps: jumps,
		reversals: [],
		levels: [],
		cors: [],
		nextt: [],
		nextLevel: [],
		corinarow: [],
		nrevs: [],
		prevchange: [],
		whichstair: []
	};
	
	for (i = 0; i<stair.nstairs; i++)
	{
		// total number of staircases 

		for (j=0; j<len; j++)
		{
			// level and correct at for each trial
			stair.levels[i,j] = 0;
			stair.cors[i,j] = 0;
		}

		stair.nextt[i]= 0;
		if (upordown[i])
		{
			stair.levels[i,0] = nlevels;

		}
		else
		{
			stair.levels[i,0] = 1;

		}
		
		stair.corinarow[i] = 0; 
		stair.nrevs[i] = 0;
		stair.prevchange[i] = 0;		
	}
	
	if (arguments.length < 5)
	{
		// %Which staircase to do next
		for (j=0; j<len; j++)
		{
			stair.whichstair[j] = Math.floor(Math.random() * (stair.nstairs));
		}
	}
	else
	{
		stair.whichstair[0] = whstair;
	}
	
	// %Trial number
	stair.t = 0;
	stair.nextLevel = stair.levels[stair.whichstair[0],0];

	return stair;
}

function updateStair(stair, cor, ncorinarow, nrevstosmall)
{

	if (stair.t <= stair.whichstair.length-1)
	{
		// %Staircase that just ran
		thestair = stair.whichstair[stair.t];		
	
	}
	else
	{
		stair.nextLevel = -1;
		return;
	}
	
	// %Update staircase
	thetrial = stair.nextt[thestair];
	stair.cors[thestair,thetrial] = cor;

	// %Process correct; keep track of num in a row and level change; do nothing
	// %if -1
	if (cor == 1)
	{
		stair.corinarow[thestair] = stair.corinarow[thestair]+1;
		if (stair.corinarow[thestair] == ncorinarow)
		{
			change = -1;
			stair.corinarow[thestair] = 0;

		}
		else
		{
			change = 0;
		}
		

	}
	else if (cor == 0)
	{
		change = 1;
		stair.corinarow[thestair] = 0;

	}
	else if (cor == -1)
	{
		change = 0;

	}

	// stair.reversals[thestair,thetrial] = 0;
	// %Look for reversal
	if (!stair.prevchange[thestair])
	{
		stair.prevchange[thestair] = change;

	}
	else if ((change != 0) && (change != stair.prevchange[thestair]))
	{
		// stair.reversals[thestair,thetrial] = 1;
		stair.reversals[stair.reversals.length] = stair.levels[thetrial]
		stair.nrevs[thestair] = stair.nrevs[thestair]+1;
		stair.prevchange[thestair] = change;
	}

	// %Make change bigger according to jumpsize
	if (stair.nrevs[thestair] < [stair.jumps].length)
	{
		change = change*stair.jumps[stair.nrevs[thestair]];

	}

	// %Update level
	if (thetrial < stair.len)
	{
		stair.levels[thestair,thetrial+1] = stair.levels[thestair,thetrial]+change;
		if(stair.levels[thestair,thetrial+1] < 1)
		{
			// warning('UpdateStair: Reached bottom of staircase!')
			stair.levels[thestair,thetrial+1] = 1;

		}
		else if(stair.levels[thestair,thetrial+1] > stair.nlevels)
		{
			// warning('UpdateStair: Reached top of staircase!')
			stair.levels[thestair,thetrial+1] = stair.nlevels;

		}

	}
	
	// %Get ready for next trial
	stair.nextt[thestair] = stair.nextt[thestair]+1;
	stair.t = stair.t+1;
	if (stair.t < stair.whichstair.length)
	{
		thestair = stair.whichstair[stair.t];			//	%Staircase to run next
		thetrial = stair.nextt[thestair];
		stair.nextLevel = stair.levels[thestair,thetrial];

	}
	else
	{
		stair.nextLevel = -1;
	}
	
	return stair;
}
