// var mcmc = require('./mcmc.js')
// var ld = require('./distributions.js')
// var jstat = require('jstat')
// var linspace = require('linspace')

// var jstat = this.jStat();
var discretiseConfidence = function(confidence, numConfidenceLevels)
{

    let ratingThresholds = linspace(0, 1, numConfidenceLevels+1);
    let numTrials = confidence.length;
    let discreteConfidence = [];

    for (let n=0; n<numTrials; n++)
    {
        for (let nc=0; nc<numConfidenceLevels; nc++)
        {
            if (confidence>=ratingThresholds[nc] & confidence<=ratingThresholds[nc+1])
            {
                discreteConfidence[n] = nc+1;
            }
        }

    }
    return discreteConfidence;
}


var conf2counts = function(stimulus, response, confidence, maxConfidence)
{
    // takes an array of stimulus, response and confidence values on different trials and bins them into counts
    let counts = {
        nR_S1: [],
        nR_S2: []
    };

    for (nc=0; nc<2*maxConfidence; nc++)
    {
        counts.nR_S1[nc] = 0;
        counts.nR_S2[nc] = 0;
    }

    numTrials = stimulus.length;

    for (nt = 0; nt < numTrials; nt++)
    {
        if (!stimulus[nt]){
            // stimulus 1
            if (!response[nt]){ counts.nR_S1[maxConfidence - confidence[nt]]++; } 
            else { counts.nR_S1[maxConfidence-1 + confidence[nt]]++; }
        }
        else{
            // stimulus 2
            if (!response[nt]){ counts.nR_S2[maxConfidence - confidence[nt]]++; } 
            else { counts.nR_S2[maxConfidence-1 + confidence[nt]]++; }
        }
    }
    
    return counts;

}

var dprime_criteria = function(var1,var2,type){
// function to calculate the dprime and criteria

    switch(type){
        
        case 'perf':
            // using task performance
            const stims = [0,1]; // two possible stimulus values
            const correct = [0,1]; // two possible response values
            vs = array_binoper(var1, stims[1], 'equals');
            vr = array_binoper(var2, correct[1],'equals');
            hr = sum(array_binoper(vs, vr, 'and'))  / sum(vs);

            vs = array_binoper(var1, stims[0], 'equals');
            vr = array_binoper(var2, correct[0], 'equals')
            far = sum(array_binoper(vs, vr, 'and'))  / sum(vs);
            // far = sum(var1==stims[0] & var2==0)/sum(var1==stims[0]);

            // hr = arrayoper(var1==stims[1] & var2==1)/sum(var1==stims[1]);
            // far = sum(var1==stims[0] & var2==0)/sum(var1==stims[0]);
            if (hr==1){hr=.99;}
            if (far==0){far=.01;}
                
            dp = jStat.normal.inv( hr,0,1 ) - jStat.normal.inv( far,0,1);
            c1 = (-.5) * ( jStat.normal.inv( hr,0,1 ) + jStat.normal.inv( far,0,1 ) );

            break;

        case 'rate':
            // using rating counts
            nratings = var1.length/2;
            ratingHR  = new Array(nratings*2-1);
            ratingFAR = new Array(nratings*2-1);
            for (c = 1; c<nratings*2; c++){
                ratingHR[c-1] = (var2.slice(c)).reduce((a,b)=>a+b,0) / var2.reduce((a,b)=>a+b,0);
                ratingFAR[c-1] = (var1.slice(c)).reduce((a,b)=>a+b,0) / var1.reduce((a,b)=>a+b,0);
    
            }
            t1_index = nratings-1;
            dp = jStat.normal.inv( ratingHR[t1_index] ,0,1) - jStat.normal.inv( ratingFAR[t1_index] ,0,1);
            c1 = (-.5) * ( jStat.normal.inv( ratingHR[t1_index] ,0,1) + jStat.normal.inv( ratingFAR[t1_index] ,0,1) );

            break;
    }

    var dprime = {};
    dprime.dp = dp;
    dprime.c1 = c1;
  
    return dprime;
  
}


var fit_metad_bias_mcmc = function(nR_S1,nR_S2,stimulus,response){

    let dpr;
    if (arguments.length==4)
    {
        // if stimulus and response are specified calculate the dprime from performance
        dpr = dprime_criteria(stimulus, response, 'perf')
    }
    else{
        // otherwise calculate dprime from counts
        dpr = dprime_criteria(nR_S1, nR_S2, 'rate')
    }

    nratings = nR_S1.length/2;

    let data = {
        nC_rS1: new Array(nratings),
        nI_rS1: new Array(nratings),
        nC_rS2: new Array(nratings),
        nI_rS2: new Array(nratings),
        cuts: new Array(nratings+1)
    }
    
    const very_small_value = 1e-8;
        
    let cutpoints = linspace(0.5,1,nratings+1);
    cutpoints[cutpoints.length - 1] = 1-very_small_value;
    
    for (let nr = 0; nr < nratings; nr++) {
      // S1 responses
      data.nC_rS1[nr] = nR_S1[nratings-1-nr];
      data.nI_rS1[nr] = nR_S2[nratings-1-nr];
      
      // S2 responses
      data.nC_rS2[nr] = nR_S2[nratings+nr];
      data.nI_rS2[nr] = nR_S1[nratings+nr];
    
      data.cuts[nr] = (cutpoints[nr]-.5)*2
    }
    
    data.cuts[nratings] = (cutpoints[nratings]-.5)*2;
    data.c1 = dpr.c1;
    data.dp = dpr.dp;

    // Parameter definitions
    let params = {
        mdp: {type: "real", lower: 0},
        bias_a: {type: "real", lower: 0},
        bias_b: {type: "real", lower: 0},
        bias_a_delta: {type: "real"},
        bias_b_delta: {type: "real"}
    };
    

    // Model definition
    var metad_bias_mcmc = function(params, data) {
        // transform the equally spaced criteria via the betacdf link function
    
        let cuts_R1 = new Array(nratings+1);
        let cuts_R2 = new Array(nratings+1);
    
        cuts_R1[0] = .5 + data.cuts[0]/2;
        cuts_R2[0] = .5 + data.cuts[0]/2;
        for(nr = 1; nr < nratings; nr++){
        cuts_R1[nr] = .5 + jStat.beta.cdf(data.cuts[nr], params.bias_a - params.bias_a_delta/2, 
            params.bias_b - params.bias_b_delta/2)/2;
        cuts_R2[nr] = .5 + jStat.beta.cdf(data.cuts[nr], params.bias_a + params.bias_a_delta/2, 
            params.bias_b + params.bias_b_delta/2)/2;
    
        }
        cuts_R1[nratings] = .5 + data.cuts[nratings]/2;
        cuts_R2[nratings] = .5 + data.cuts[nratings]/2;
        
        if (cuts_R1[nratings-1]>cuts_R1[nratings]){
        cuts_R1[nratings-1] = cuts_R1[nratings];
        }
        if (cuts_R1[nratings-1]>cuts_R1[nratings]){
        cuts_R2[nratings-1] = cuts_R2[nratings];
        }
    
        let prC_rS1 = new Array(nratings);
        let prI_rS1 = new Array(nratings);
        let prC_rS2 = new Array(nratings);
        let prI_rS2 = new Array(nratings);
    
        for(nr=0; nr<nratings; nr++){
        lg1val1_R1 = (1-cuts_R1[nr+1])/cuts_R1[nr+1];
        lg1val2_R1 = (1-cuts_R1[nr])/cuts_R1[nr];
        lg2val1_R1 = 1/lg1val2_R1;
        lg2val2_R1 = 1/lg1val1_R1;
        
        lg1val1_R2 = (1-cuts_R2[nr+1])/cuts_R2[nr+1];
        lg1val2_R2 = (1-cuts_R2[nr])/cuts_R2[nr];
        lg2val1_R2 = 1/lg1val2_R2;
        lg2val2_R2 = 1/lg1val1_R2;
    
        prC_rS1[nr] = (jStat.normal.cdf(((1/params.mdp) * Math.log(lg1val2_R1) + data.c1 ),
            -params.mdp/2,1) - 
            jStat.normal.cdf((1/params.mdp) * Math.log(lg1val1_R1) + data.c1,
            -params.mdp/2,1)) ;
    
        prI_rS1[nr] = jStat.normal.cdf((1/params.mdp) * Math.log(lg1val2_R2) + data.c1,
            params.mdp/2,1) - 
            jStat.normal.cdf(((1/params.mdp) * Math.log(lg1val1_R2) + data.c1 ),
            params.mdp/2,1) ;
        
        prC_rS2[nr] = jStat.normal.cdf((1/params.mdp) * Math.log(lg2val2_R2) + data.c1,
            params.mdp/2,1) - 
            jStat.normal.cdf(((1/params.mdp) * Math.log(lg2val1_R2) + data.c1),
            params.mdp/2,1) ;
        
        prI_rS2[nr] = (jStat.normal.cdf(((1/params.mdp) * Math.log(lg2val2_R1) + data.c1),
            -params.mdp/2,1) - 
            jStat.normal.cdf((1/params.mdp) * Math.log(lg2val1_R1) + data.c1 ,
            -params.mdp/2,1)) ;
    
    
        }
    
        sumC_rS1 = prC_rS1.reduce((a,b)=>a+b,0);
        sumI_rS1 = prI_rS1.reduce((a,b)=>a+b,0);
        sumC_rS2 = prC_rS2.reduce((a,b)=>a+b,0);
        sumI_rS2 = prI_rS2.reduce((a,b)=>a+b,0);
    
        for(nr=0; nr<nratings; nr++){
        prC_rS1[nr] = prC_rS1[nr] / sumC_rS1;
        prI_rS1[nr] = prI_rS1[nr] / sumI_rS1;
        prC_rS2[nr] = prC_rS2[nr] / sumC_rS2;
        prI_rS2[nr] = prI_rS2[nr] / sumI_rS2;
    
        }
    
        let log_post = 0;
        
        // priors
        log_post += ld.norm(params.mdp, data.dp, 5)
        log_post += ld.norm(params.bias_a, 1, 20)
        log_post += ld.norm(params.bias_b, 1, 20)
        log_post += ld.norm(params.bias_a_delta, 0, 10)
        log_post += ld.norm(params.bias_b_delta, 0, 10)
    
        // likelihood
        log_post += ld.multinom(data.nC_rS1,prC_rS1)
        log_post += ld.multinom(data.nI_rS1,prI_rS1)
        log_post += ld.multinom(data.nC_rS2,prC_rS2)
        log_post += ld.multinom(data.nI_rS2,prI_rS2)
    
        return log_post;
    
    
    };

    
    let sampler =  new mcmc.AmwgSampler(params, metad_bias_mcmc, data);
    sampler.burn(1000);

    const nsamples = 30000;
    let samples = sampler.sample(nsamples);

    fit = {};
    fit.mdp = samples.mdp.reduce((a, b) => a + b, 0) / nsamples;
    a = samples.bias_a.reduce((a, b) => a + b, 0) / nsamples;
    b = samples.bias_b.reduce((a, b) => a + b, 0) / nsamples;
    fit.beta_a = a;
    fit.beta_b = b;
    fit.beta_a_delta = samples.bias_a_delta.reduce((a, b) => a + b, 0) / nsamples;
    fit.beta_b_delta = samples.bias_b_delta.reduce((a, b) => a + b, 0) / nsamples;
    fit.beta_m = a/(a + b);
    fit.beta_v = (a*b)/((a+b)*(a+b)*(a+b+1));
    fit.dp = dp;
    fit.c1 = c1;
    fit.mratio = fit.mdp/fit.dp;

    return fit;

}

// module.exports = {dprime_criteria, fit_metad_bias_mcmc};