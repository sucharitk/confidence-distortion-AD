var yesnoDialog = function (scene, title, text, position, 
    clickCallback, yesnoText){
    var dialog = scene.rexUI.add.dialog({
        x: position.x,
        y: position.y,
        background: scene.rexUI.add.roundRectangle(0, 0, 50, 10, 20, 0x05cc07),

        title: scene.rexUI.add.label({
            background: scene.rexUI.add.roundRectangle(0, 0, 50, 10, 20, 0x000000),
            text: scene.add.text(0, 0, title, {
                fontSize: '20px'
            }),
            space: {
                left: 15,
                right: 15,
                top: 10,
                bottom: 10
            }
        }),

        content: scene.add.text(0, 0, text, {
            fontSize: '22px'
        }),

        actions: [
            createLabel(scene, yesnoText[0]),
            createLabel(scene, yesnoText[[1]]),
        ],

        space: {
            title: 25,
            content: 25,
            action: 15,

            left: 20,
            right: 20,
            top: 20,
            bottom: 20,
        },

        align: {
            actions: 'left', // 'center'|'left'|'right'
        },

        expand: {
            content: false,  // Content is a pure text object                      
        }
    })
        .layout()
        .popUp(1000);
    
    dialog
        .on('button.click', function (button, groupName, index, pointer, event) {
            clickCallback(index);
        }, scene)
        .on('button.over', function (button, groupName, index, pointer, event) {
            button.getElement('background').setStrokeStyle(1, 0xffffff);
        })
        .on('button.out', function (button, groupName, index, pointer, event) {
            button.getElement('background').setStrokeStyle();
        });

    return dialog;
}

var createLabel = function (scene, text) {
    return scene.rexUI.add.label({

        background: scene.rexUI.add.roundRectangle(0, 0, 0, 0, 20, window.buttonCol[1]),

        text: scene.add.text(0, 0, text, {
            fontSize: '20px'
        }),
        align: 'center',
        width: 40,
        space: {
            left: 10,
            right: 10,
            top: 10,
            bottom: 10
        }
    });
}


var createButton = function (scene, text, position, clickCallback)
{
    let newButton = scene.rexUI.add.buttons({
        x: position.x , y: position.y ,
        orientation: 'y',
        buttons: [
            designButton(scene, text, position)
        ],
        space: { item: 8 },
        click: {
            mode: 'pointerup',
            clickInterval: 100
        }        
    }).layout()
    // newButton.setVisible(false);
    newButton
    .on('button.click', function (button, index, pointer, event) {
        clickCallback(scene);
    })
    .on('button.over', function (button) {
        if (newButton.getButtonEnable())
        {
            // create hovering effect only if button is enabled
            button.getElement('background').setStrokeStyle(2, 0xffffff); // when hover
        }
    })
    .on('button.out', function (button) {
        button.getElement('background').setStrokeStyle();
    })

    return newButton;
}


var designButton = function (scene, text, position) {
    return scene.rexUI.add.label({
        width: position.width,
        height: position.height,
        background: scene.rexUI.add.roundRectangle(0, 0, 0, 0, 20, window.buttonCol[1]),
        text: scene.add.text(0, 0, text, {
            fontSize: 18
        }),
        align: 'center',
        space: {
            left: 10,
            right: 10,
        }
    });
}

var enableButton = function (button, buttonState)
{
    // buttonState can be 0: disabled, 1: enabled (not done), 2: disabled (done), 3: enabled (done)
    if (buttonState<0){
        button.setVisible(false);
    }
    else{
        button.setVisible(true);
        button.setButtonEnable(!!(+buttonState % 2));
    
        button
        .getButton(0)
        .getElement('background')
        .setFillStyle(window.buttonCol[+buttonState]); // when hover    
    }

}


var scrollTextPanel = function (scene, content, position, doneButton) {

    var scrollablePanel = scene.rexUI.add.scrollablePanel({
        x: position.x,
        y: position.y,
        width: position.width,
        height: position.height,

        scrollMode: 0,

        background: scene.rexUI.add.roundRectangle(0, 0, 2, 2, 10, window.backgrCol),

        panel: {
      
            child: createScrollableContent(scene),

            mask: {
                mask: true,
                padding: 1
            },
        },

        mouseWheelScroller: {
            focus: true,
            speed: 0.1
        },        

        slider: {
            track: scene.rexUI.add.roundRectangle(0, 0, 20, 10, 10, window.titleCol),
            thumb: scene.rexUI.add.roundRectangle(0, 0, 0, 0, 13, window.buttonCol[0]),
            input: 'drag',
            valuechangeCallback: function(newValue) {
                if (newValue > .98)
                {
                    // to enable the done button
                    enableButton(doneButton, 1)
                }
            },
        },

        header: scene.rexUI.add.label({
            height: 30,

            orientation: 0,
            background: scene.rexUI.add.roundRectangle(0, 0, 20, 20, 0, window.titleCol),
            text: scene.add.text(0, 0, '\t\t\tParticipant Information Sheet'),
        }),

        space: {
            left: 10,
            right: 10,
            top: 10,
            bottom: 10,

            panel: 10,
            header: 10
        },

        expand: {
            header: true
        },

        align: {
            header: 'center'
        }
    })
        .layout()
    //.drawBounds(this.add.graphics(), 0xff0000);

    return updatePanel(scene, scrollablePanel, content);

}

var createScrollableContent = function(scene)
{
     // Create table body
     var sizer = scene.rexUI.add.fixWidthSizer({
        space: {
            left: 3,
            right: 3,
            top: 3,
            bottom: 3,
            item: 8,
            line: 8,
        },
    })
        .addBackground(scene.rexUI.add.roundRectangle(0, 0, 10, 10, 0, window.buttonCol[0]))

    return sizer;
    
}

var updatePanel = function (scene, panel, content) {
    var sizer = panel.getElement('panel');
    var scene = panel.scene;

    sizer.clear(true);

    sizer.add(
        scene.add.text(0,0, 
            splitEssay(content, 50, '\n\n'),
            { fontSize: 19, color: 'black'})
    )

    // var lines = content.split('\n');
    
    // for (let li = 0, lcnt = lines.length; li < lcnt; li++) {
    //     var words = lines[li].split(' ');
    //     for (let wi = 0, wcnt = words.length; wi < wcnt; wi++) {
    //         sizer.add(
    //             scene.add.text(0, 0, words[wi], {
    //                 fontSize: 18
    //             })
    //         );
    //     }
    //     if (li < (lcnt - 1)) {
    //         sizer.addNewLine();
    //     }
    // }

    panel.layout();
    return panel;
}

var createRadioButtons = function (scene, responseOptions, position, clickCallback) 
{

    let nResponseOptions = responseOptions.length;

    let btns = [];
    for (let i=0; i<nResponseOptions; i++){
        btns[i] = designRadioButton(scene, responseOptions[i], position.textOrientation);
    } 

    let button = scene.rexUI.add.buttons({
        x: position.x+100, y: position.y + 60,

        orientation: position.orientation,

        buttons: btns,
        index: [0,1,2,3],

        type: 'radio',
        setValueCallback: function (button, value) {
            button.getElement('icon')
                .setFillStyle((value)? window.themeCols[1] : undefined);
            }
    }).layout()

    button.on('button.click', function(button, index){
        clickCallback(index);
        })

    // .drawBounds(this.add.graphics(), 0xff0000)
    button.setVisible(false);

    return button;
}

var designRadioButton = function (scene, text, orientation, name) {
    if (name === undefined) {
        name = text;
    }

    var button = scene.rexUI.add.label({
        width: 120,
        height: 40,
        text: scene.add.text(0, 0, text, {
            fontSize: 18
        }),
        icon: scene.add.circle(0, 0, 10).setStrokeStyle(1, window.themeCols[1]),
        space: {
            left: 10,
            right: 10,
            icon: 10
        },
        orientation: orientation,
        name: name
    });

    return button;
}

var quitStudyCallback = function(scene){

    ynDialog = yesnoDialog(scene, 'Are you sure?', 
    " Are you sure you want to quit the  \n"+
    " study? \n\n"+
    " If you quit now, you will be compensated \n"+
    " on a pro-rated basis.",
    {x:400, y: 300}, 
    function(index){
        if (!index){
            scene.scene.stop();
        }
    },
    ["Yes: quit study", "No: return to study"]);

}

var addFullscreenButton = function(scene){
    fullscreenScale = 0.8; // how big to make the fullscreen buttons

    fullscreenButton = scene.add.image(800-20, 20, 'fullscreen', +scene.scale.isFullscreen)
    .setOrigin(1, 0).setInteractive().setScale(fullscreenScale);

    fullscreenButton.on('pointerup', function () {
        if (scene.scale.isFullscreen){
            fullscreenButton.setFrame(0);

            scene.scale.stopFullscreen();
        }
        else{
            fullscreenButton.setFrame(1);

            scene.scale.startFullscreen();
        }
    }, scene);

    return fullscreenButton;
}

var showFeedbackDialog = function(){
   
    var mainTxt = ( " The auditor of Fruitville is here\n"+
                    " to evaluate your response. \n\n"+
                    " Check how you performed..."
                    );
    var buttonTxt = "Check response";
    var pageNo = 10;
    this.instructionsPanel = new InstructionsPanel(this, 
    gameWidth/2, gameHeight/2,
    pageNo, auditDialogTitle, mainTxt, buttonTxt);
}