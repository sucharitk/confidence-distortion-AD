import InstructionsPanel from "./instructionsPanel.js";
import eventsCenter from './eventsCenter.js';
import { saveSRETEndorseData, saveStartTimeData } from "./db/saveData.js";


// const COLOR_LIGHT = 0x0705e7;
// const COLOR_DARK = 0x060944;

// const responseOptions = ['Not at all',
//                         'A little',
//                 'A lot',
//             'Very much'];
const responseOptions = ['  |  \n  0  \nNot at\n all ',
                        ' | \n 1  \n A  \nlittle',
                ' |  \n 2\nSomewhat',
                ' | \n 3\nA good\namount',
            '  |  \n  4\nVery\nmuch'];
const nRespOptions = responseOptions.length;
                        

const sretPositionCenter = {x: 300, y: 350, orientation: 'x', textOrientation: 'y'};

var numTotalTrials;
var numPracticeTrials;
var numFinalTrials;
var curTrialNum;
var stimulusTimedEvent;
var timeFromStimOnset;
var preStimulusWaitDur = [800, 500]; // first element is for first trial, and second for subsequent trials
var wordPresentationDur = 1500;
var postWordDur = 250; 
const showSelectedResponseDuration = 50;
var trialGapOnset;
var sretWordsFinal;

var taskMode;
var taskPhase;
var trialPhase;
var gameHeight;
var gameWidth;
var titleText;
var mainTxt;
var randWordPositions;
var sretChoice = [];
var sretRespTime = [];
var fullscreenButton;
var cursors;
var text_startPrompt;
var clickSlider;
var textMarkers = {};
const flickerInstructionsFrames = [30, 40];
var curFlickFrame;
var flickerText;

var titleText;
var mainText;
var buttonTxt;
var pageNo;
var textWord;
var textQuestion;
var wordFrame;
var radioButton;
var radioButton2;
// var submitButton;
var gameHeight;
var gameWidth;
var textClickSlider;

var responseClicked; // if the response slider has been clicked once

export default class TaskSRE extends Phaser.Scene{
    constructor (){
        super({
            key: 'sreTask'
        });
    }

    preload (){
        this.load.scenePlugin({
            key: 'rexuiplugin',
            url: './src/phaser/rexuiplugin.min.js',
            sceneKey: 'rexUI'
        });  

        this.load.spritesheet('fullscreen', './assets/fullscreen.png', {frameWidth: 64, frameHeight: 64})
        // this.load.text('sretWordsSet1', './assets/sretWordsSet1Short.txt');
        // this.load.text('sretWordsSet2', './assets/sretWordsSet2Short.txt');
        // this.load.text('sretWordsPractice', './assets/sretPracticeWordsShort.txt');
        this.load.text('sretWordsSet1', './assets/sretWordsSet1.txt');
        this.load.text('sretWordsSet2', './assets/sretWordsSet2.txt');
        this.load.text('sretWordsPractice', './assets/sretPracticeWords.txt');
        this.load.image('bg', './assets/clouds.png');
        this.load.spritesheet('tiles', './assets/fantasy-tiles.png', { frameWidth: 64, frameHeight: 64 });

    }

    create (){
        // initialisations
        saveStartTimeData(subjID, expName, (window.timeStampOrder++)+'_sreTask')

        // background image
        this.add.image(400, 0, 'bg').setOrigin(0.5, 0.02);
        // tiles at the bottom
        for (let i = 0; i < 13; i++){
            this.add.image(64 * i, 580, 'tiles', 1).setOrigin(0);
        }

        specifyGroupSpecificParameters(window.subjGroup);
        console.log('window.subjGroup '+window.subjGroup)
        console.log('window.sretOrder '+window.sretOrder)
        this.loadWords();

        sretWordsFinal = window.sretOrder[window.nextSRET]==1 ? this.sretWordsSet1 : this.sretWordsSet2;

        // console.log(sretWordsFinal)
        // load the words for sret from a file
        // define cursor keys
        cursors = this.input.keyboard.createCursorKeys();
        
        
        // set total trials equal to the total number of words
        numPracticeTrials = this.sretWordsPractice.length;
        numFinalTrials = sretWordsFinal.length;

        // randomise the order of words
        randWordPositions = randSample(sequence(numFinalTrials), numFinalTrials);

        this.createTaskItems();
            
        gameHeight = this.sys.game.config.height;
        gameWidth = this.sys.game.config.width;
    
        if (window.nextSRET==0){
            console.log('window.nextSRET'+window.nextSRET)
            taskMode = 'practice';
            taskPhase = 'instructions';
        } else{
            // for sret 2
            taskPhase = 'instructions';    
            taskMode = 'sret2';
            // trialPhase = 'trialInit';

            curTrialNum = 0;
            numTotalTrials  = numFinalTrials;

            text_startPrompt = this.add.text(250,290,"Press an arrow key\n(up/down/left/right)\nto begin...",{
                align:'center', color: '#fff', strokeThickness: 3, 
                stroke: 'black',
                shadow: {offsetX: .5, offsetY: .5, stroke: true},
                fontSize: 25
            });

        }
    }


    update (){
        switch (taskPhase){
            case 'instructions':
                this.showInstructions();

                break;

            case 'task':
                this.doTask();
                break;

            case 'wait':
                break;
        }

    }
    
    showInstructions(){
        
        switch (taskMode)
        {
            case 'practice':
                titleText = 'Self-descriptive Words';
            
                // let's do this a long-winded way for easiness...[should be a function]
                ///////////////////PAGE ONE////////////////////
                mainText = (    " Next, you will be presented the following question:  \n\n"+
                                ' "How much does this word generally describe you?" \n\n' +
                                " We will then show you a series of words, where your \n"+
                                " task is to click on a slider bar with the following\n"+
                                " options: 0-Not at all, 1-A little, 2-Somewhat, \n"+
                                " 3-A good amount, and 4-Very much \n\n"+
                                " You can of course choose any value in between those.\n\n" +
                                " Please choose as honestly as possible.\n\n" +
                                " The words will be shown one at a time with the \n"+
                                " next word appearing soon after you have selected \n"+
                                " your choice on the shown word."
                                );
                buttonTxt = "More instructions";

                pageNo = 1;
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                pageNo, titleText, mainText, buttonTxt);
    

                eventsCenter.once('page1complete', function () {
                    mainText = (" Let us start by practicing this task with \n"+
                                " some sample words. Click 'Proceed' to start\n" +
                                " practicing. "
                                );
                    buttonTxt = "Proceed";
                    pageNo = 2;

                    this.instructionsPanel = new InstructionsPanel(this, 
                    gameWidth/2, gameHeight/2,
                    pageNo, titleText, mainText, buttonTxt);

                }, this);

                eventsCenter.once('page2complete', function () {
                    // taskPhase = 'wait'

                    taskPhase = 'task';
                    trialPhase = 'trialInit';
                    curTrialNum = 0;
                    textQuestion.setVisible(true);
                    wordFrame.setVisible(true);

                    numTotalTrials  = numPracticeTrials;
                }, this);                

                // show instructions
                // taskMode = 'wait';
                taskPhase = 'wait';
                
                break;

                
            case 'final':

                mainTxt = ( " You have completed the practice! \n\n"+
                            " You can now proceed to the main task. \n\n"+
                            " Once you are ready to start the main task \n"+
                            " Click 'Begin' "
                );
                buttonTxt = "Begin";
                pageNo = 3;
                this.instructionsPanel = new InstructionsPanel(this, 
                                                            gameWidth/2, gameHeight/2,
                                                            pageNo, titleText, mainTxt, buttonTxt);


                eventsCenter.once('page3complete', function () {
                    taskPhase = 'task'
                    trialPhase = 'trialInit';
                    curTrialNum = 0;
                    textQuestion.setVisible(true);
                    wordFrame.setVisible(true);

                    numTotalTrials  = numFinalTrials;

                });          
                
                // show instructions
                taskPhase = 'wait';
                // taskMode = 'wait';
                break;

            case 'sret2':
                titleText = 'Self-descriptive Words';
            
                // let's do this a long-winded way for easiness...[should be a function]
                ///////////////////PAGE ONE////////////////////
                mainText = (    " Next, you will be presented the following question:  \n\n"+
                                ' "How much does this word generally describe you?" \n\n' +
                                " We will then show you a series of words, where your \n"+
                                " task is to click on a slider bar with the following\n"+
                                " options: 0-Not at all, 1-A little, 2-Somewhat, \n"+
                                " 3-A good amount, and 4-Very much \n\n"+
                                " You can of course choose any value in between those.\n\n" +
                                " Please choose as honestly as possible.\n\n" +
                                " The words will be shown one at a time with the \n"+
                                " next word appearing soon after you have selected \n"+
                                " your choice on the shown word."
                                );
                buttonTxt = "Proceed";

                pageNo = 1;
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                pageNo, titleText, mainText, buttonTxt);

                taskMode = 'wait';
                
                eventsCenter.once('page1complete', function () {
                    taskMode = 'sret2Wait';
                }, this);

                break;


            case 'sret2Wait':
                if (Phaser.Input.Keyboard.JustDown(cursors.up) ||
                Phaser.Input.Keyboard.JustDown(cursors.down) ||
                Phaser.Input.Keyboard.JustDown(cursors.left) ||
                Phaser.Input.Keyboard.JustDown(cursors.right)){

                text_startPrompt.setVisible(false);
    
                textQuestion.setVisible(true);
                wordFrame.setVisible(true);
            
                taskPhase = 'task';
                taskMode = 'final';
                trialPhase = 'trialInit';
                }

                break;
            
        }

    }
    

    doTask(){
        if (curTrialNum < numTotalTrials)
        {
            switch (trialPhase)
            {
                // different phases within a trial

                case 'wait':
                    // do nothing

                    break;
                    
                case 'trialInit':
                    
                    responseClicked = false;

                    textWord.x = sretPositionCenter.x;
                    textWord.text = taskMode=="practice"? this.sretWordsPractice[curTrialNum]:
                                                        sretWordsFinal[randWordPositions[curTrialNum]];

                    // radioButton.value = [];
                    wordFrame.setVisible(false);

                    stimulusTimedEvent = window.performance.now();

                    clickSlider = false;

                    trialPhase = 'preStimulus';

                    break;                        
                
                case 'preStimulus':

                    timeFromStimOnset = window.performance.now() - stimulusTimedEvent;
                    if (timeFromStimOnset <= preStimulusWaitDur[+!!curTrialNum]){
                        // +!! first converts int to bool and then converts it back to int

                        wordFrame.setVisible(true);

                        // ELSE: do nothing 
                    } 
                    else{
                        trialPhase = 'dispWord';
                    }
                 
                    break;


                case 'dispWord':

                    timeFromStimOnset = window.performance.now() - (stimulusTimedEvent + preStimulusWaitDur[+!!curTrialNum]);
                    if (timeFromStimOnset <= wordPresentationDur){   
                        textWord.setVisible(true);

                    } 
                    else{
                        textWord.setVisible(false);
                        trialPhase = 'postWord';
                    }
                    
                    break;

                case 'postWord':
                    // gap after word presentation

                    timeFromStimOnset = window.performance.now() - 
                        (stimulusTimedEvent + preStimulusWaitDur[+!!curTrialNum] + wordPresentationDur);

                        if (timeFromStimOnset <= postWordDur){
                            // gap
                        } 
                        else{
                            trialPhase = 'acceptResp';
                            stimulusTimedEvent = window.performance.now();
                        }                    
                        
                        break;


                case 'acceptResp':

                    radioButton.setVisible(true);
                    for (let i=0; i<nRespOptions; i++){
                        textMarkers[i].setVisible(true);
                        // this.children.bringToTop(textConfMarkers[i]);
                    }

                    // if (radioButton.value.length!=0){
                    if (clickSlider){
                        // submitButton.setVisible(true);
                        sretChoice[curTrialNum] = radioButton.value;
                        sretRespTime[curTrialNum] = window.performance.now() - stimulusTimedEvent;
                        radioButton2.setValue(radioButton.value);
                        radioButton.setVisible(false);
                        radioButton2.setVisible(true);

                        trialGapOnset = window.performance.now();
                        trialPhase = 'postTrialGap';
                    }

                    if (taskMode=="practice" & curTrialNum<3){
                        flickerText = textClickSlider;
                    }

                    break;

                case 'postTrialGap':
                    if (window.performance.now() - trialGapOnset > showSelectedResponseDuration){
                        trialPhase = 'postTrial';
                    }
                    break;

                case 'postTrial':

                    textWord.setVisible(false);
                    radioButton.setVisible(false);
                    radioButton2.setVisible(false);
                    for (let i=0; i<nRespOptions; i++){
                        textMarkers[i].setVisible(false);
                        // this.children.bringToTop(textConfMarkers[i]);
                    }
                    // radioButton.setValue(Math.random());

                    flickerText = undefined;
                    textClickSlider.setVisible(false);

                    curTrialNum++;

                    trialPhase = 'trialInit';
                    
                    break;

            }

        } 
        else{
            
            if (taskMode=='practice'){
                // if we were in the practice mode, switch to final model
                taskMode='final';
                curTrialNum = 0;
                numTotalTrials  = numFinalTrials;

                taskPhase = 'instructions';

            }
            else{
                saveSRETEndorseData(window.subjID, window.expName, {
                    words: sretWordsFinal,
                    randWordPositions: randWordPositions,
                    sretChoice: sretChoice,
                    sretRespTime: sretRespTime,
                    sretSet: window.sretOrder[window.nextSRET],
                    sretTimepoint: window.nextSRET
                });
                taskMode = 'endblock';
                this.nextScene();    
            }
        }

        if (flickerText!=undefined){
            // flicker flickerText if it is not undefined
            curFlickFrame++;
            if (curFlickFrame < flickerInstructionsFrames[0]){
                flickerText.setVisible(true);
            }
            else if (curFlickFrame < flickerInstructionsFrames[1]){
                flickerText.setVisible(false);
            }
            else {curFlickFrame=0;}            
        }        
    }

  
    nextScene() {
        window.sretState[window.nextSRET] = 2;
        switch (window.nextSRET){
            case 0:
                window.mainTaskState = 1;
                this.scene.start('welcome');
                break;
                
            case 1:
                // window.finalTaskState[4] = 1; // activate the fourth task button
                window.fruitvilleStage = 10;
                this.scene.start('fruitville');
                break;
        }
    }


    loadWords(){
        // get the words from the practice and final words files
        // split them by each line and put them in an array
        let cache = this.cache.text;
        let posnegWords = cache.get('sretWordsSet1');
        this.sretWordsSet1 = posnegWords.split('\n');
        posnegWords = cache.get('sretWordsSet2');
        this.sretWordsSet2 = posnegWords.split('\n');

        posnegWords = cache.get('sretWordsPractice');
        this.sretWordsPractice = posnegWords.split('\n');

    }

    createTaskItems(){
                // create a frame within which to present the word
        wordFrame = this.rexUI.add.roundRectangle(
            sretPositionCenter.x+100, sretPositionCenter.y-50, 270, 80, 20, 
            window.themeCols[1], 200);
        wordFrame.setVisible(false);

        textWord = this.add.text(sretPositionCenter.x ,
            sretPositionCenter.y-60,
            "Good",{
            align:'center', color: 'white', strokeThickness: 3, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true},
            fontSize: 35

        });
        textWord.setVisible(false);

        textQuestion = this.add.text(sretPositionCenter.x - 230 ,
            sretPositionCenter.y-140,
            "How much does this word generally describe you?",{
            align: 'center', //color: '#00', strokeThickness: 3, 
            shadow: {offsetX: .5, offsetY: .5, stroke: true},
            fontSize: 25

        });
        textQuestion.setVisible(false);

        curTrialNum = 0;

        textClickSlider = this.add.text(sretPositionCenter.x - 290 ,
            sretPositionCenter.y+40,
            "Respond by >>\nclicking \nat a point \non the \nslider",{
            align: 'left', //color: '#00', strokeThickness: 3, 
            shadow: {offsetX: .5, offsetY: .5, stroke: true},
            fontSize: 16, color: 'black'

        });
        textClickSlider.setVisible(false);

        // radioButton = createRadioButtons(this, responseOptions,
        //     sretPositionCenter,
        //     function(btnIndex) 
        //     {
        //         sretChoice[curTrialNum] = btnIndex;
        //     });

        radioButton = this.rexUI.add.slider({
            x: 400,
            y: 390,
            width: 500,
            height: 20,
            orientation: 'x',
            track: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[5]),
            indicator: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[5]),
            input: 'click', // 'drag'|'click'
            value: 0.75,
            valuechangeCallback: function (value) {
                if (curTrialNum!=undefined){
                    // confidence[curTrialNum] = 1-value; // subtract from 1 because sliders are inverted
                    sretChoice[curTrialNum] = value;
                    clickSlider = true;
                }
                // clickConfidence = true;
            }}).layout();
        radioButton.setVisible(false);

        radioButton2 = this.rexUI.add.slider({
            x: 400,
            y: 390,
            width: 500,
            height: 20,
            orientation: 'x',
            track: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[5]),
            indicator: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[4]),
            input: 'click', // 'drag'|'click'
            value: Math.random()/5 + 0.4,
            valuechangeCallback: function (value) {
                if (curTrialNum!=undefined){
                    // confidence[curTrialNum] = 1-value; // subtract from 1 because sliders are inverted
                    sretChoice[curTrialNum] = value;
                    clickSlider = true;
                }
                // clickConfidence = true;
            }}).layout();
        radioButton2.setVisible(false);


        for (let i=0; i<nRespOptions; i++){
            textMarkers[i] = this.add.text( 126+i*124,390,
                responseOptions[i],{
                align:'left', color: '#fff', strokeThickness: 3, 
                stroke: '#000', fontSize: 16,
                shadow: {offsetX: .5, offsetY: .5, stroke: true}
            });
            textMarkers[i].setVisible(false);
        }

        fullscreenButton = addFullscreenButton(this);

    }
}


function specifyGroupSpecificParameters(subjGroup){
    // Using this is a function as it needs to wait for database access

    // first two blocks of tasks are baselines and are randomised in order
    let ftp = window.firstTwoBlocks;
    switch (subjGroup){
        case 1:
            window.blockSequence = [ftp, 1-ftp, 0, 1, 0, 1];
            window.feedbackType = [0, 0, 1, 0, 2, 0];
            window.sretOrder = [1, 2];
            break;
    
        case 2:
            window.blockSequence = [ftp, 1-ftp, 0, 1, 0, 1];
            window.feedbackType = [0, 0, 2, 0, 1, 0];
            window.sretOrder = [1, 2];
            break;
    
        case 3:
            window.blockSequence = [ftp, 1-ftp, 0, 1, 0, 1];
            window.feedbackType = [0, 0, 1, 0, 2, 0];
            window.sretOrder = [2, 1];
            break;
    
        case 4:
            window.blockSequence = [ftp, 1-ftp, 0, 1, 0, 1];
            window.feedbackType = [0, 0, 2, 0, 1, 0];
            window.sretOrder = [2, 1];
            break;
    
        case 5:
            window.blockSequence = [ftp, 1-ftp, 1, 0, 1, 0];
            window.feedbackType = [0, 0, 1, 0, 2, 0];
            window.sretOrder = [1, 2];
            break;
    
        case 6:
            window.blockSequence = [ftp, 1-ftp, 1, 0, 1, 0];
            window.feedbackType = [0, 0, 2, 0, 1, 0];
            window.sretOrder = [1, 2];
            break;
    
        case 7:
            window.blockSequence = [ftp, 1-ftp, 1, 0, 1, 0];
            window.feedbackType = [0, 0, 1, 0, 2, 0];
            window.sretOrder = [2, 1];
            break;
    
        case 8:
            window.blockSequence = [ftp, 1-ftp, 1, 0, 1, 0];
            window.feedbackType = [0, 0, 2, 0, 1, 0];
            window.sretOrder = [2, 1];
            break;
    
    }
}