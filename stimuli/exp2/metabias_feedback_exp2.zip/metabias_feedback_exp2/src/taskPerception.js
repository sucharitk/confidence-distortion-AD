import eventsCenter from './eventsCenter.js';
import InstructionsPanel from "./instructionsPanel.js";
import {saveConfTaskData, saveStartTimeData} from "./db/saveData.js";

// initialise the constants
const stimulusDuration = 1000; // in milliseconds
const flickerEvery = 250; // re-allocate random position of stimuli
const timesFlicker = linspace(flickerEvery,stimulusDuration,stimulusDuration/flickerEvery);

const stimulusGrid = [11, 11]; // grid of berries
const numStimuli = stimulusGrid[0]*stimulusGrid[1]; // total number of berries
const numStimulusLevels = numStimuli/2; // number of stimullus levels

var numTotalTrials;

const scaleFruitStimuli = .033;
const scaleBerryOptions = 0.08;
const numConfLevels = 5; // number of levels of confidence
var startConf = .5; // starting value of confidence to display 
const preStimInterval = [600, 750]; // random value in this interval
const postStimInterval = 200; // random value in this interval
const feedbackInterval = 1900;
const feedbackFaceAfter = 400;
const feedbackMsgAfter = 300;
const chosenOptionSizeIncrease = 1.6;

const curTaskNum = 0;

const stim12 = [0, 1]; // there are different colours of diamonds, which ones to use as stim1 and stim2

const offsetShadow = {x: .75, y: 1};
var curBlockFeedback;
var startLevel;
// initialise the variables

var berries = {};
var berryStimuli;
var cursors;
var fbPosImage;
var fbPosImageShadow;
var fbNegImage;
var fbNegImageShadow;
var fullscreenButton;
var results;

var timeFromStimOnset;
var timeFromConfOnset = 0;
var timeFromStimOffset;
var timeFromChoice;
var confRespTime = 0;
var nowTime;

var mindChange = {
    n: 0,
    trialNum: [],
    response: [],
    reaction1Time: []
};

// starting trial number
var curTrialNum;
var preStimulusWaitDur;
var numFlickersThisTrial;
var taskPhase;

var trialPhase;

var stimulus=[];
var correct=[];
var confidence=[];
var response=[];
var incdec= []; // whether to increment or decrement on the curent trial and by how much
var feedbackYesNo = [];
var reaction1Time = [];
var reaction2Time = [];

var whichFeedbackMessage;

var text_instr;
var text_resp;
var text_conf;
var textFeedback;
var textFeedbackMessage;
var textConfMarkers = {};

var confSlider = {};
var clickConfidence;
var currentConfidence;
var discreteConfidence;
var currentInput;

var gameHeight;
var gameWidth;
var auditDialogTitle;

var stair;
var stairJumps;

var stimulusTimedEvent;


export default class TaskPerception extends Phaser.Scene
{
    constructor ()
    {
        super({
            key: 'perceptionTask'
        });
    }

    preload ()
    {
        this.load.scenePlugin({
            key: 'rexuiplugin',
            url: './src/phaser/rexuiplugin.min.js',
            sceneKey: 'rexUI'
        });  

        this.load.spritesheet('fullscreen', './assets/fullscreen.png', {frameWidth: 64, frameHeight: 64})
        this.load.image('tree','./assets/tree_2.png', { frameWidth: 500, frameHeight: 500 })
        this.load.image('bush1','./assets/bush_4.png', { frameWidth: 500, frameHeight: 500 })
        this.load.image('bush2','./assets/bush_9.png', { frameWidth: 500, frameHeight: 500 })
        this.load.image('bg', './assets/clouds.png');
        this.load.spritesheet('tiles', './assets/fantasy-tiles.png', { frameWidth: 64, frameHeight: 64 });
        this.load.image('berry0', './assets/raspberry.png');
        this.load.image('berry1', './assets/black-berry-dark.png');

        this.load.image('fbPos', './assets/1f600.png');
        this.load.image('fbNeg', './assets/1f615.png');

        // plugin for randomising the position of the stimuli on every trial
        this.load.plugin(
            'rexrandomplaceplugin', 
            './src/phaser/rexrandomplaceplugin.min.js', 
            true);

    }

    create ()
    {
        // initialisations
        mindChange = {
            n: 0,
            trialNum: [],
            response: [],
            reaction1Time: []
        };
        stimulus=[];
        correct=[];
        confidence=[];
        response=[];
        incdec = []; // whether to increment or decrement on the curent trial and by how much
        feedbackYesNo = [];
        reaction1Time = [];
        reaction2Time = [];

        saveStartTimeData(subjID, expName, (window.timeStampOrder++)+'_perceptionTask');

        // background image
        this.add.image(400, 0, 'bg').setOrigin(0.5, 0.02);
        // tree
        this.add.image(40, 310, 'tree').setOrigin(0.4, 0.5).setScale(1.2);
        // bushes
        this.add.image(430, 360, 'bush2').setOrigin(0.1, 0.5).setScale(1.2);
        this.add.image(300, 235, 'bush1').setOrigin(0.4, 0.5).setScale(1.6);

        // tiles at the bottom
        for (var i = 0; i < 13; i++){
            this.add.image(64 * i, 580, 'tiles', 1).setOrigin(0);
        }

        gameHeight = this.sys.game.config.height;
        gameWidth = this.sys.game.config.width;
        auditDialogTitle = 'You have been chosen for an audit';

        this.createTaskItems();

        // define cursor keys
        cursors = this.input.keyboard.createCursorKeys();

        // create a blank group for the collective berry stimuli
        berryStimuli = this.add.group();
        // set stimui to invisible initially
        Phaser.Actions.SetVisible(berryStimuli.getChildren(),0);

        // create a psychophysics staircase
        startLevel = window.thresholdedInitLevels[curTaskNum]; // start the task at the mid point of levels (.5)
        // console.log('startLevel = '+startLevel);
        
        // numTotalTrials = window.numTaskTrials[window.practiceOrFinal[curTaskNum]];

        numTotalTrials = window.practiceOrFinal[curTaskNum] ? 
                window.numTaskTrials[window.taskPurpose[window.curTaskBlock]]:
                window.numTaskTrials[0]; // number of trials for one of the task blocks or for practice

        if (window.practiceOrFinal[curTaskNum]){
            curBlockFeedback = window.feedbackType[window.curBlock];
            // console.log("curBlockFeedback=%d, window.curBlock=%d", curBlockFeedback, window.curBlock)
            stairJumps = [1];

            window.curBlock++;
        } else { // in case of practice
            
            curBlockFeedback = 0;
            stairJumps = [2, 2];
        }

        stair = initStair([1], numStimulusLevels, numTotalTrials, stairJumps);
        stair.levels[0] = startLevel;
        stair.nextLevel = startLevel; 

        curTrialNum = 0;

        taskPhase = 'instructions';

    }

    update ()
    {
        switch (taskPhase)
        {
            case 'instructions':
                this.showInstructions();
                break;

            case 'task':
                this.doTask();
                break;

            case 'endblock':
                this.nextScene()
                break;
        }
    }
    
    showInstructions(){

        // show instructions

        if (Phaser.Input.Keyboard.JustDown(cursors.up) ||
            Phaser.Input.Keyboard.JustDown(cursors.down) ||
            Phaser.Input.Keyboard.JustDown(cursors.left) ||
            Phaser.Input.Keyboard.JustDown(cursors.right)){
            text_resp.setVisible(false);
            taskPhase = 'task';
            trialPhase = 'trialInit';
        }

    }

    doTask(){
        if (curTrialNum < numTotalTrials){
            switch (trialPhase){
                // different phases within a trial

                case 'trialInit':
                    // at the beginning of a new trial 

                    // decide whether the next stimulus has stim 0 or 1 in greater number
                    stimulus[curTrialNum] = Math.floor(2 * Math.random()); // 0 or 1
                    startConf = Math.random()/5 + 0.4; // start confidence randomly between 0.4-.6
                    confidence[curTrialNum] = startConf;
                    clickConfidence = false;

                    // increment or decrement stimulus level
                    incdec[curTrialNum] = stair.levels[curTrialNum]*(stimulus[curTrialNum] * 2 - 1);

                    berryStimuli.clear();
                    // add reds
                    berryStimuli.createMultiple({
                        key: 'berry'+stim12[0],
                        setScale: {x: scaleFruitStimuli, y: scaleFruitStimuli},
                        frameQuantity: numStimulusLevels-incdec[curTrialNum] // more red for stim=0
                    });
                    // add blues
                    berryStimuli.createMultiple({
                        key: 'berry'+stim12[1],
                        setScale: {x: scaleFruitStimuli, y: scaleFruitStimuli},
                        frameQuantity: numStimulusLevels+incdec[curTrialNum]
                    });

                    // start clock for the trial
                    stimulusTimedEvent = window.performance.now();
                    numFlickersThisTrial = 0;

                    this.plugins.get('rexrandomplaceplugin').randomPlace(berryStimuli.getChildren(),
                        {
                            radius: 10,
                            area: new Phaser.Geom.Rectangle(230, 300, 300, 260),
                        });
                    Phaser.Actions.SetVisible(berryStimuli.getChildren(),0);

                    preStimulusWaitDur = preStimInterval[0] + 
                        Math.random() * (preStimInterval[1] - preStimInterval[0]);

                    confRespTime = 0;

                    textFeedback.setVisible(false);

                    trialPhase = 'preStimulus';

                    break;                        
                
                case 'preStimulus':

                    timeFromStimOnset = window.performance.now() - stimulusTimedEvent;
                    if (timeFromStimOnset > preStimulusWaitDur){
                        trialPhase = 'dispStimulus';
                    } 
                    // ELSE: do nothing 
                 
                    break;


                case 'dispStimulus':

                    nowTime = window.performance.now();
                    timeFromStimOnset = nowTime - (stimulusTimedEvent + preStimulusWaitDur);

                    if (timeFromStimOnset < stimulusDuration){
                        // display visual stimulus here

                        // if (!(Math.round(timeFromStimOnset/10) % Math.round(flickerEvery/10)))
                        if (timeFromStimOnset > timesFlicker[numFlickersThisTrial]){
                            numFlickersThisTrial++;
                            this.plugins.get('rexrandomplaceplugin').randomPlace(berryStimuli.getChildren(),
                            {
                                radius: 8,
                                area: new Phaser.Geom.Rectangle(230, 300, 300, 260),
                            });
                        }

                        // from now until stimulusTimedEvent display the stimulus
                        Phaser.Actions.SetVisible(berryStimuli.getChildren(),1);

                    }   else {
                        // stop showing the stimuli
                        Phaser.Actions.SetVisible(berryStimuli.getChildren(),0);
                        trialPhase = 'postStimulus';
                    }

                    break;


                case 'postStimulus':

                    timeFromStimOnset = window.performance.now() - 
                        (stimulusTimedEvent + preStimulusWaitDur + stimulusDuration);

                    if (timeFromStimOnset > postStimInterval){
                        berries[0].setScale(scaleBerryOptions);
                        berries[1].setScale(scaleBerryOptions);                
                        berries[0].setVisible(true);
                        berries[1].setVisible(true);
                        
                        // start reaction-1 time timer now
                        timeFromStimOffset = window.performance.now();

                        text_resp.x = 255;
                        text_resp.y = 200;
                        text_resp.text = "Use the left (<-) or\nright (->) arrow key\nto choose response";
                        text_resp.setVisible(true);

                        trialPhase = 'acceptResp';
                    }

                    break;                    

                case 'acceptResp':

                    // when accepting response
                    clickConfidence = false;

                    if (Phaser.Input.Keyboard.JustDown(cursors.left)){
                        currentInput = 0;
                        this.respAccepted(currentInput);
                    }
                    else if (Phaser.Input.Keyboard.JustDown(cursors.right)){
                        currentInput = 1;
                        this.respAccepted(currentInput);
                    } 
                    
                    break; 


                case 'acceptConf':

                    if (clickConfidence){
                        // accept the confidence slider value only when the confidence 
                        // slider has been clicked on once

                        let roundedConfidence = Math.round(currentConfidence*100);
                        text_conf.x = 400;
                        text_conf.y = 495 + (1-roundedConfidence)*2.2;

                        discreteConfidence = discretiseConfidence(
                                [roundedConfidence/100],
                                numConfLevels);
                        this.children.bringToTop(text_conf);
                        text_conf.text = (roundedConfidence) + "% confidence";
                        text_conf.setVisible(true);
                        for (let i=0; i<window.numConfLevels; i++){
                            textConfMarkers[i].setVisible(true);
                            this.children.bringToTop(textConfMarkers[i]);
                        }
                        
                        text_resp.x = 215;
                        text_resp.y = 190;
                        text_resp.text = "Press an arrow key to record\nconfidence when done";        

                        if (Phaser.Input.Keyboard.JustDown(cursors.up) ||
                        Phaser.Input.Keyboard.JustDown(cursors.down) ||
                        Phaser.Input.Keyboard.JustDown(cursors.left) ||
                        Phaser.Input.Keyboard.JustDown(cursors.right)){

                            // record confidence and move to the next phase of the trial
                            confidence[curTrialNum] = currentConfidence;
                            reaction2Time[curTrialNum] = window.performance.now() - timeFromChoice;

                            text_resp.setVisible(false);
                            for (let i=0; i<2; i++){
                                berries[i].setVisible(false);
                                confSlider[i].setVisible(false);
                            }
                            text_conf.setVisible(false);
                            for (let i=0; i<window.numConfLevels; i++){
                                textConfMarkers[i].setVisible(false);
                            }    

                            if (feedbackYesNo[curTrialNum] && curBlockFeedback){
                                trialPhase = 'feedbackDialog';

                                whichFeedbackMessage = Math.floor(numFeedbackMessages * Math.random());
                                feedbackYesNo[curTrialNum] = whichFeedbackMessage+1;
                            }
                            else{
                                trialPhase = 'postTrial';
                            }
                        }
                
                    }
                    else{
                        // if confidence slider has not yet been clicked and if participant 
                        // wants to still change their mind about the response
                        // let them
                        if (currentInput && Phaser.Input.Keyboard.JustDown(cursors.left)){
                            currentInput = 0;

                            // record change in mind by saving previous responses on this trial
                            mindChange.trialNum[mindChange.n] = curTrialNum;
                            mindChange.response[mindChange.n] = response[curTrialNum];
                            mindChange.reaction1Time[mindChange.n] = reaction1Time[curTrialNum];
                            mindChange.n++;

                            this.respAccepted(currentInput);
                        }
                        else if (!currentInput && Phaser.Input.Keyboard.JustDown(cursors.right)){
                            currentInput = 1;

                            // record change in mind by saving previous responses on this trial
                            mindChange.trialNum[mindChange.n] = curTrialNum;
                            mindChange.response[mindChange.n] = response[curTrialNum];
                            mindChange.reaction1Time[mindChange.n] = reaction1Time[curTrialNum];
                            mindChange.n++;

                            this.respAccepted(currentInput);
                        } 
                    }

                    break;


                case 'feedbackDialog' :
                    
                    this.showFeedbackDialog();

                    eventsCenter.once('page10complete', function () {
                        // record the time at which confidence response is given
                        confRespTime = window.performance.now();
                        trialPhase = 'feedback';
                        }, this);

                    trialPhase = 'wait';

                    break;


                case 'feedback' :
                    
                    timeFromConfOnset = window.performance.now() - 
                    confRespTime;


                    if (timeFromConfOnset < feedbackInterval){
                   
                        if (correct[curTrialNum] ){
                            // feedback for correct

                            if (timeFromConfOnset > feedbackFaceAfter){
                                textFeedback.x = 315;
                                textFeedback.setColor('#0b0');
                                textFeedback.text = "Correct";
                                fbPosImageShadow.setVisible(true);
                                fbPosImage.setVisible(true);

                                textFeedback.setVisible(true);
                            }
                            if (timeFromConfOnset > feedbackFaceAfter + feedbackMsgAfter){

                                textFeedbackMessage.x = 220;
                                textFeedbackMessage.text = positiveMessages[whichFeedbackMessage];
                                textFeedbackMessage.setVisible(true);

                            }

                        }
                        else{
                            // feedback for incorrect

                            if (timeFromConfOnset > feedbackFaceAfter){
                                textFeedback.x = 298;
                                textFeedback.setColor('#f00');
                                textFeedback.text = "Incorrect";
                                fbNegImageShadow.setVisible(true);
                                fbNegImage.setVisible(true);

                                textFeedback.setVisible(true);
        
                            }
                            if (timeFromConfOnset > feedbackFaceAfter + feedbackMsgAfter){

                                textFeedbackMessage.x = 200;
                                textFeedbackMessage.text = negativeMessages[whichFeedbackMessage];
                                textFeedbackMessage.setVisible(true);
                            }
                        }

                    }
                    else{
                        timeFromConfOnset = window.performance.now();
                                     
                        textFeedback.setVisible(false);
                        textFeedbackMessage.setVisible(false);
                        fbPosImage.setVisible(false);
                        fbPosImageShadow.setVisible(false);
                        fbNegImage.setVisible(false);
                        fbNegImageShadow.setVisible(false);
                        
                        text_resp.x = 250;
                        text_resp.y = 360;
                        text_resp.setScale = 1.25;
                        text_resp.text = " Press an arrow key\n to continue";

                        trialPhase = 'postFeedbackInterval';
                    }
                    break;
                    

                case 'postFeedbackInterval':

                    text_resp.setVisible(true);

                    if (Phaser.Input.Keyboard.JustDown(cursors.up) ||
                    Phaser.Input.Keyboard.JustDown(cursors.down) ||
                    Phaser.Input.Keyboard.JustDown(cursors.left) ||
                    Phaser.Input.Keyboard.JustDown(cursors.right)){
                        text_resp.setVisible(false);

                        trialPhase = 'postTrial';
                    }

                    break;

                case 'postTrial':

                    stair = updateStair(stair, correct[curTrialNum], 2); // 3rd argument is 2 for 2-down-1-up
                    curTrialNum++;
                    trialPhase = 'trialInit';

                    break;
            }
        } 
        else{

            this.saveData();
            taskPhase = 'endblock';
        }
    }

    
    respAccepted(respNum){
        response[curTrialNum] = respNum;
        correct[curTrialNum] = !(stimulus[curTrialNum] ^ response[curTrialNum]);

        // record time from stimulus offset as response-1 time
        nowTime = window.performance.now();
        reaction1Time[curTrialNum] = nowTime - timeFromStimOffset;
        // reset timeFromStimOffset to get confidence (response-2) time
        timeFromChoice = nowTime;
      
        // decide whether to give feedback or not
        if (curBlockFeedback){
            if (correct[curTrialNum]){
                feedbackYesNo[curTrialNum] = Math.random() < probFeedback.corr[curBlockFeedback-1];
            }
            else {
                feedbackYesNo[curTrialNum] = Math.random() < probFeedback.incorr[curBlockFeedback-1];
            }
        }

        trialPhase = 'acceptConf';

        text_resp.x = 250;
        text_resp.y = 190;
        text_resp.text = "Click/Drag the slider\nto select confidence\nin your choice";

        berries[respNum].setScale(scaleBerryOptions*chosenOptionSizeIncrease);
        confSlider[respNum].setValue(startConf);
        confSlider[respNum].setVisible(true);

        berries[1-respNum].setScale(scaleBerryOptions);
        confSlider[1-respNum].setVisible(false);

        clickConfidence = false;

    }

    saveData(){
        var percResults = {
            taskType: curTaskNum, // perception task
            curBlockFeedback: curBlockFeedback,
            curTaskBlock: window.practiceOrFinal[curTaskNum]? window.curTaskBlock+1 : 0,
            stimulus: stimulus,
            response: response,
            confidence: confidence,
            correct: correct,
            incdec: incdec,
            feedbackYesNo: feedbackYesNo,
            mindChange: mindChange,
            stair: stair,
            reaction1Time: reaction1Time,
            reaction2Time: reaction2Time,
            spe0: window.spe0[curTaskNum]
        };

        saveConfTaskData(window.subjID, window.expName, percResults)
    }

    showFeedbackDialog(){
   
        var mainTxt = ( " The auditor of Fruitville is here\n"+
                        " to evaluate your response. \n\n"+
                        " Check how you performed..."
                        );
        var buttonTxt = "Check response";
        var pageNo = 10;
        this.instructionsPanel = new InstructionsPanel(this, 
        gameWidth/2, gameHeight/2,
        pageNo, auditDialogTitle, mainTxt, buttonTxt);

    }

    nextScene() {

        // get the last n reversals to take the mean over
        let lastReversals = stair.reversals.slice(-window.meanLastReversals);

        if (lastReversals.length>0){
            // if there are any reversals at all take the average of the last n reversals and set the init value
            window.thresholdedInitLevels[curTaskNum] = 
            Math.ceil(sum(lastReversals)/lastReversals.length);    
        }

        if (window.practiceOrFinal[curTaskNum]){
            // if this is the final (not practice) version of the confidence task
            window.fruitvilleStage = 8; // if final set the stage from where to start the fruitville scene
            window.finalTaskState[window.curTaskBlock] = 2; // disable the just completed button

            ++window.curTaskBlock; 

        }
        else{
            // if practice block

            // check if the current subject group involves one or both tasks (i.e., if it is transfer to opposite task)
            let transferSameOrOpposite = window.blockSequence[0]==window.blockSequence[1] ?
            window.blockSequence[0] : 2;  

            if (transferSameOrOpposite==2){
                // if both perc and mem tasks move onto the memory practice
                window.fruitvilleStage = 3;
            }
            else {
                // if only perception task go to practice complete message
                window.fruitvilleStage = 7;
            }
            window.practiceOrFinal[curTaskNum] = 1; // practice is done, put it on final task mode
        }
        this.scene.start('fruitville');

    }

    createTaskItems(){

        for (let i = 0; i < 2; i++){
            // berries for the two response options
            berries[i] = this.add.image(295 + i*(477-295),400,'berry'+i).setScale(scaleBerryOptions);
            berries[i].setVisible(false);

            // slider 0 to receive confidence for berry 0
            confSlider[i] = this.rexUI.add.slider({
                x: 380,
                y: 400,
                width: 20,
                height: 250,
                orientation: 'v',
                track: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[0]),
                indicator: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[1]),
                thumb: this.add.image(300,170,'berry'+i).setScale(scaleBerryOptions),
                input: 'click', // 'drag'|'click'
                valuechangeCallback: function (value) {
                    if (curTrialNum!=undefined){
                        // confidence[curTrialNum] = 1-value; // subtract from 1 because sliders are inverted
                        currentConfidence = 1-value;
                    }
                    clickConfidence = true;
                }}).layout();
            confSlider[i].setVisible(false);

        }
        
        fullscreenButton = addFullscreenButton(this);

        fbPosImageShadow = this.add.image(380 + offsetShadow.x, 390 + offsetShadow.y,'fbPos');
        fbPosImage = this.add.image(380,390,'fbPos');
        fbPosImageShadow.tint = 0x000000;
        fbNegImageShadow = this.add.image(380 + offsetShadow.x,390 + offsetShadow.y,'fbNeg');
        fbNegImage = this.add.image(380,390,'fbNeg');
        fbNegImageShadow.tint = 0x000000;
        fbPosImage.setScale(1.4);
        fbNegImage.setScale(1.4);
        fbPosImageShadow.setScale(1.4);
        fbNegImageShadow.setScale(1.4);
        fbPosImage.setVisible(false);
        fbNegImage.setVisible(false);
        fbPosImageShadow.setVisible(false);
        fbNegImageShadow.setVisible(false);

        text_resp = this.add.text(250,300,"Press an arrow key\n(up/down/left/right)\nto begin...",{
            align:'center', color: '#fff', strokeThickness: 3, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        text_resp.scale = 1.35;

        text_conf = this.add.text(300,200,"",{
            align:'center', color: '#fff', strokeThickness: 4, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        text_conf.scale = 1.3;
        text_conf.setVisible(false);

        textFeedbackMessage = this.add.text(220,450,"Additional feedback message",{
            align:'center', color: '#fff', strokeThickness: 3, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        textFeedbackMessage.setVisible(false);
        textFeedbackMessage.setScale(1.4);

        textFeedback = this.add.text(320,300,"Correct/Incorrect",{
            align:'center', color: '#090', strokeThickness: 3, 
            stroke: '#000', fontSize: 20,
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        textFeedback.setVisible(false);
        textFeedback.setScale(1.5);

        for (let i=0; i<window.numConfLevels; i++){
            textConfMarkers[i] = this.add.text(285, 280+i*54.5,
                window.confidenceMarkers[window.numConfLevels-i-1],{
                align:'right', color: '#fff', strokeThickness: 3, 
                stroke: '#000', fontSize: 20,
                shadow: {offsetX: .5, offsetY: .5, stroke: true}
            });
            textConfMarkers[i].setVisible(false);
            this.children.bringToTop(textConfMarkers[i]);
        }

    }

}


