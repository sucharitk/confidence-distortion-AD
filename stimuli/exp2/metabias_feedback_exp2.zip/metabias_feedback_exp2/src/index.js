/* games assets
 fruits from: https://gamedeveloperstudio.itch.io/fruits-icon-pack
*/

import TaskPerception from "./taskPerception.js";
import TaskMemory from "./taskMemory.js";
import TaskSRE from "./taskSRE.js";
import Questionnaires from "./questionnaires.js";
import Welcome from "./welcome.js"
import Fruitville from "./fruitville.js";
import TaskMemoryHelp from "./taskMemoryHelp.js";
import TaskPerceptionHelp from "./taskPerceptionHelp.js";
import SubjInfo from "./getSubjectInfo.js";
import { saveStartTimeData } from "./db/saveData.js";

// generate a random ID for the participant
let guid = Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1) +
            Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
window.subjID = 'subj_'+guid;

/* There are 8 groups that a subject can belong to
group 1: perc to mem transfer with pos first, sret set 1 first
group 2: perc to mem transfer with neg first, sret set 1 first
group 3: perc to mem transfer with pos first, sret set 2 first
group 4: perc to mem transfer with neg first, sret set 2 first
group 5: mem to perc transfer with pos first, sret set 1 first
group 6: mem to perc transfer with neg first, sret set 1 first
group 7: mem to perc transfer with pos first, sret set 2 first
group 8: mem to perc transfer with neg first, sret set 2 first
*/

/* Experimental stage:
1. Development, 2. Pre-pilot, 3. Pilot, 4. Exp1
*/

let expStage = (location.hostname === "localhost" || location.hostname === "127.0.0.1"?
1:3); // if running locally, put it in dev mode; otherwise, from another mode
console.log('expStage '+expStage)

switch (expStage){
    case 1:
        window.expName = 'exp2_shiftConfDev';
        window.possibleSubjectGroups = [1,2,3,4,5,6,7,8];
        break;
    case 2:
        window.expName = 'exp2_shiftConfPilot';
        window.possibleSubjectGroups = [1,2,3,4,5,6,7,8];
        break;
    case 3:
        window.expName = 'exp2_shiftConf';
        window.possibleSubjectGroups = [1,2,3,4,5,6,7,8];
        break;
    }

// Add a timestamp on database for when study begins
window.timeStampOrder = 0;
saveStartTimeData(subjID, expName, (window.timeStampOrder++)+'_studyBegin')

// scene names for the perception and memory tasks
const blockType = ["perceptionTask", "memoryTask"];

// confidence markers to add to the current slider position
window.confidenceMarkers = [
    "  none", 
    "   low", 
    "medium", 
    "  high", 
    "  full"];
window.numConfLevels = confidenceMarkers.length;

// list of positive messages to be displayed along with feedback
window.positiveMessages = ["      Great going!",
"The residents of Fruitville \nthank you for your help!",
"You are getting good at this!"
];
// list of negative messages to be displayed along with feedback
window.negativeMessages = [" You chose the wrong option!",
"    Should have chosen the \n other one!",
"The residents of Fruitville \nchose the wrong fruit\nbased on your suggestion!"
];
window.numFeedbackMessages = positiveMessages.length;

// define global colours for the theme
window.backgrCol = 0x05cc47;
window.titleCol = 0x333333;
window.buttonCol = [0x888888, 0x1e21c2, 0x20bb05, 0x20ec05]; // button colour can be 0: disabled (grey), 1: enabled-notdone (blue), 2: disabled-done (green), 3: enabled-done  
window.themeCols = [0x0705e7, 0x060944];
window.sliderCols = [0x7b5e97, 0x160904, 0x030199, 0x03fe12, 0x3335ff, 0x030350];
window.flickCols = ['blue', 'cyan'];;

// initial states of buttons (-1: invisible, 0: visible but disabled, 1: enabled, 2: completed disabled, 3: completed enabled)
window.infoSheetState = 0;
window.consentState = -1;
window.mhq1State = -1;
window.mhq2State = -1;
window.sretState = [-1, -1];
window.mainTaskState = -1;
window.fruitvilleInstrPercState = 0;
window.fruitvillePractPercState = 0;
window.fruitvilleInstrMemState = 0;
window.fruitvillePractMemState = 0;

window.curTaskBlock = 0; // which confidence task we are currently on

window.numTaskTrials = [50,40,40,20]; // 0 index: practice trials, 1: final task baseline, 2: final task intervention, 3: final task test
// window.numTaskTrials = [1,1,1,1]; // 0 index: practice trials, 1: final task baseline, 2: final task intervention, 3: final task test
window.practiceOrFinal = [0, 0]; // next perception and memory task is 0: practice, 1: intervention, 2: test
window.thresholdedInitLevels = [10, 9]; // these will be set for the two tasks after practice based on the average of the last twelve staircase reversals
window.meanLastReversals = 5; // number of last reversals to mean when setting the starting threshold after practice
window.numLearningTrials = 5;

window.blockSequence = []; // sequence of conf task blocks based on the subject group
window.feedbackType = []; // 0: no feedback, 1: pos feedback, 2: neg feedback
window.sretOrder = [];
window.taskPurpose = [1, 1, 2, 3, 2, 3]; // first two are baseline (0), then two sets of intervention (1) followed by test (2)
window.checkForRepeatSubject = false; // initialise variable to check the subject id is already in the database 
window.firstTwoBlocks = Math.round(Math.random()); // randomise which task to start with during baseline 
window.nextSRET = 0; // sret is performed twice


// specify probability of giving feedback on a given correct and incorrect trial respectively
// because 1-up-2-down staircase converges at ~71% correct. out of 40 trials,
// we would like to give feedback on 
// 9 corr and 1 incorr trials for pos(itive) blocks vice-a-versa for neg blocks
const stairConvergence = .71; 
window.probFeedback = {
    corr: [9/(stairConvergence*window.numTaskTrials[1]), 1/(stairConvergence*window.numTaskTrials[1])],
    incorr: [1/((1-stairConvergence)*window.numTaskTrials[1]), 9/((1-stairConvergence)*window.numTaskTrials[1])]
}; // here first element of array is for pos and second for neg feedback blocks

window.fruitvilleStage = 0; // when starting with practicing the perception task

// number of blocks of perception/memory tasks
var numTaskBlocks = 6;

window.finalTaskState = Array(numTaskBlocks).fill(-1);
window.sret2State = -1;

window.curQuestionnaireNumber = 1;
window.consentFormNumber = 0; // questionnaire number for the consent form

window.mainTaskSceneSequence = [];
window.mainTaskCurrentScene = 0;
window.spe0 = [-1, -1];

let nb = window.mainTaskSceneSequence.length;
for (let i=nb; i<numTaskBlocks+nb; i++){
    window.mainTaskSceneSequence[i] = window.blockSequence[i] ?
     "memoryTask" : "perceptionTask";
}
window.curBlock = 0;

var scenes = [TaskMemory,Welcome,TaskSRE,  Fruitville, 
    TaskPerceptionHelp, SubjInfo, TaskMemoryHelp, 
    TaskPerception, 
    Questionnaires
];

var config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    backgroundColor: '#2d2d2d',
    parent: 'phaser-example',
    scene: scenes,                    
  
    dom: {
        createContainer: true
    },
    scale: {
        // mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_HORIZONTALLY,
    }
};

var game = new Phaser.Game(config);
