
// linspace 
function linspace(startValue, stopValue, cardinality) {
  let arr = [];
  let step = (stopValue - startValue) / (cardinality - 1);
  for (let i = 0; i < cardinality; i++) {
    arr.push(startValue + (step * i));
  }
  return arr;
}

// a sequence of numbers from 1 to numLevels
function sequence(numLevels) 
{
  return Array.from({length: numLevels}, (v, i) => i );
}

// sum
function sum(arr)
{
    return arr.reduce((a,b)=>a+b);
}

// any
function any(arr)
{
  nel = arr.length;
  let anyResult = false;
  for (i = 0; i<nel; i++)
  {
    if (arr[i])
    {
      anyResult = true;
      break;
    }
  }
  return anyResult;
}

// not
function not(arr)
{
  nel = arr.length;
  let outarr = [];
  for (let i = 0; i < nel; i++)
  {
    outarr[i] = !arr[i];
  }
  return outarr;
}

// binary operations on two arrays: equals, and, or, xor, notxor
function array_binoper(array1,array2,oper_type)
{
  if (typeof(array1)=='number'){array1 = [array1];}
  if (typeof(array2)=='number'){array2 = [array2];}

  nel1 = array1.length;
  nel2 = array2.length;

  let outarr = [];

  if (nel1!=nel2 && nel1!=1 && nel2!=1)
  {
    // if unequal sizes with both arrays > length of 1
    outarr = -1;
  }
  else
  {
    if (nel1==1)
    {
      // if first array has only one element swap it and make array2
      temp = array2;
      array2 = array1;
      array1 = temp;
      nel1 = nel2;
      nel2 = 1;
    }
  
    if (nel2==1)
    {
      // if second array has one element repeat that element
      // temp = array2;
      // for (let i=0; i<nel2; i++)
      // {
      //   array2[i] = temp;
      // }
      array2 = Array(nel1).fill(array2[0]);
    }
  
    for (i = 0; i < nel1; i++)
    {
      switch (oper_type)
      {
        case 'equals':
          outarr[i] = array1[i]==array2[i];
          break; 
        case 'and':
          outarr[i] = array1[i] && array2[i];
          break; 
        case 'or':
          outarr[i] = array1[i] || array2[i];
          break; 
        case 'xor':
          outarr[i] = array1[i] ^ array2[i];
          break; 
        case 'notxor': 
          outarr[i ]= !(array1[i] ^ array2[i]);
          break;
      }
    
    }

  }

  return outarr;
}

  // randomly sample numSamples from array1 without replacement
  function randSample(array1, numSamples)
{
  let nSamplesSoFar = 0;
  let lengthArray = array1.length;
  let randArray = [];

  randArray[0] = array1[Math.floor(lengthArray * Math.random())];
  nSamplesSoFar++;

  while (nSamplesSoFar < numSamples)
  {
    let newSample = array1[Math.floor(lengthArray * Math.random())];
    // console.log(newSample)
    let equalSamples = any(array_binoper(newSample, randArray, 'equals'));
    // console.log(equalSamples)
    if  (!equalSamples)
    {
      randArray[nSamplesSoFar] = newSample;
      // console.log(randArray)
      nSamplesSoFar++;
    }
  }
  return randArray;
}

// generate an sequence of random numbers with replacement
function randN(numSamples){
  return Array.from({length: numSamples}, () => Math.floor(Math.random() * numSamples));

}

// split a long string into multiple lines based on a limit of number characters
function splitStringByNumberOfCharacters(string, nChar, insertChars)
{
  let words = string.split(' ');
  let newString = '';
  let curLineCharCount = 0;
  for (let i = 0, wcnt = words.length; i < wcnt; i++) {
    let iWord = words[i];
    let liWord = iWord.length;

    if (curLineCharCount + liWord < nChar){
      curLineCharCount = curLineCharCount + liWord;
      newString = newString + ' ' + iWord;
    }
    else {
      newString = newString + insertChars;
      curLineCharCount = liWord;
      newString = newString + ' ' + iWord;

    }
  }
  return newString;
}

function splitEssay(string, nChar, lineSplitChar = '\n')
{
  let lines = string.split('\n');
  nLines = lines.length;
  let newString = '';

  for (let i = 0; i < nLines; i++)
  {
    let curLine = lines[i];

    let splitLine = splitStringByNumberOfCharacters(curLine, nChar, lineSplitChar);

    newString = newString + lineSplitChar + splitLine;
  }

  return newString;
}