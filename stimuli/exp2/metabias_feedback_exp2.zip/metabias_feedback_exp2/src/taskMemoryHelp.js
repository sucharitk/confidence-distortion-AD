import InstructionsPanel from "./instructionsPanel.js";

import eventsCenter from './eventsCenter.js';
import { saveStartTimeData } from "./db/saveData.js";

// initialise the constants

const priorEstimateTrials = 100;

// duration of task events in ms
const preStimInterval = [400, 500]; // random value in this interval
const stimulusDuration = 1500; // duration of stimuli for memory encoding
const postStimInterval = 1000; // interval between encoding and recall

const feedbackInterval = 2500; // total duration of feedback
const feedbackFaceAfter = 200; // onset of initial feedback message with face within the feedback interval
const feedbackMsgAfter = 500; // onset of the subsequent message after the face

var startConf = .5; // starting value of confidence to display 
const postFeedbackInterval = 600;

const chosenOptionSizeIncrease = 1.6;
// const fruitScale = [.083, .07, .077, .055, .065, .06, .07, .055, .062, .083, .065, .06, .077]; // sizes of the fruit images are variable, so each needs its own scaling value
const scaleFruitScale = .85;
const fruitScale = [scaleFruitScale*.083, scaleFruitScale*.07, scaleFruitScale*.077,
    scaleFruitScale*.055, scaleFruitScale*.065, scaleFruitScale*.06, scaleFruitScale*.07,
    scaleFruitScale*.055, scaleFruitScale*.062, scaleFruitScale*.083, scaleFruitScale*.065,
    scaleFruitScale*.06, scaleFruitScale*.077]; // sizes of the fruit images are variable, so each needs its own scaling value
const numStimuli = fruitScale.length; // number of fruits
const numStimulusLevels = numStimuli; // number of stimullus levels

const stimLevels = Array.from({length: numStimulusLevels}, (_, i) => i + 1);
// const startLevel = Math.round(.7 * stimLevels.length); // start the task at the mid point of levels (.5)

const practTrialDifficulties = [2, 3, 4, 2, 3];
const offsetShadow = {x: .75, y: 1};

const curTaskNum = 1;

var curBlockFeedback;

var berries;

var fruits = {};
var randFruits;
var cursors;
var fbPosImage;
var fbPosImageShadow;
var fbNegImage;
var fbNegImageShadow;

var timeFromStimOnset;
var timeFromConfOnset = 0;
var confRespTime = 0;


// starting trial number
var curTrialNum ;
var preStimulusWaitDur;

var taskPhase;
var trialPhase;
var prevTrialPhase;
var correct;
var stimulus;

var incdec; // whether to increment or decrement on the curent trial and by how much

var text_resp;
var text_conf;
var textFeedback;
var textFeedbackMessage;
var textConfMarkers = {};
var ynDialog;
var titleText;
var mainText;
var fullscreenButton;

var confSlider = {};
var clickResponse;

var speSlider;
var clickConfidence;
var currentConfidence;
var discreteConfidence;
var currentInput;
var fruitChoices;
var fruitOptions = {};

var gameHeight;
var gameWidth;
var auditDialogTitle;

var stimulusTimedEvent;


export default class TaskMemoryHelp extends Phaser.Scene
{
    constructor (){
        super({
            key: 'memoryTaskHelp'
        });
    }

    preload (){
        this.load.scenePlugin({
            key: 'rexuiplugin',
            url: './src/phaser/rexuiplugin.min.js',
            sceneKey: 'rexUI'
        });  

        this.load.spritesheet('fullscreen', './assets/fullscreen.png', {frameWidth: 64, frameHeight: 64})
        this.load.image('tree','./assets/tree_2.png', { frameWidth: 500, frameHeight: 500 })
        this.load.image('bush1','./assets/bush_4.png', { frameWidth: 500, frameHeight: 500 })
        this.load.image('bush2','./assets/bush_9.png', { frameWidth: 500, frameHeight: 500 })
        this.load.image('bg', './assets/clouds.png');
        this.load.spritesheet('tiles', './assets/fantasy-tiles.png', { frameWidth: 64, frameHeight: 64 });

        this.load.image('fruit0', './assets/raspberry.png');
        this.load.image('fruit1', './assets/strawberry.png');
        this.load.image('fruit2', './assets/red-cherry.png');
        this.load.image('fruit3', './assets/red-apple.png');
        this.load.image('fruit4', './assets/red-grape.png');
        this.load.image('fruit5', './assets/banana.png');
        this.load.image('fruit6', './assets/star-fruit.png');
        this.load.image('fruit7', './assets/orange.png');
        this.load.image('fruit8', './assets/peach.png');
        this.load.image('fruit9', './assets/black-berry-light.png');
        this.load.image('fruit10', './assets/plum.png');
        this.load.image('fruit11', './assets/lemon.png');
        this.load.image('fruit12', './assets/black-cherry.png');
        this.load.image('tickMark', './assets/2611.png');

        this.load.image('fbPos', './assets/1f600.png');
        this.load.image('fbNeg', './assets/1f615.png');

        // plugin for randomising the position of the stimuli on every trial
        this.load.plugin(
            'rexrandomplaceplugin', 
            './src/phaser/rexrandomplaceplugin.min.js', 
            true);
    }

    create (){
        // initialisations
        saveStartTimeData(subjID, expName, (window.timeStampOrder++)+'_memoryTaskHelp');

        // background image
        this.add.image(400, 0, 'bg').setOrigin(0.5, 0.02);
        // tree
        this.add.image(40, 310, 'tree').setOrigin(0.4, 0.5).setScale(1.2);
        // bushes
        this.add.image(430, 360, 'bush2').setOrigin(0.1, 0.5).setScale(1.2);
        this.add.image(300, 235, 'bush1').setOrigin(0.4, 0.5).setScale(1.6);

        // tiles at the bottom
        for (let i = 0; i < 13; i++)
        {
            this.add.image(64 * i, 580, 'tiles', 1).setOrigin(0);
        }

        gameHeight = this.sys.game.config.height;
        gameWidth = this.sys.game.config.width;
    
        this.createTaskItems();

        gameHeight = this.sys.game.config.height;
        gameWidth = this.sys.game.config.width;
        auditDialogTitle = 'You have been chosen for an audit';

        fbPosImageShadow = this.add.image(380 + offsetShadow.x, 390 + offsetShadow.y,'fbPos');
        fbPosImage = this.add.image(380,390,'fbPos');
        fbPosImageShadow.tint = 0x000000;
        fbNegImageShadow = this.add.image(380 + offsetShadow.x,390 + offsetShadow.y,'fbNeg');
        fbNegImage = this.add.image(380,390,'fbNeg');
        fbNegImageShadow.tint = 0x000000;
        fbPosImage.setScale(1.4);
        fbNegImage.setScale(1.4);
        fbPosImageShadow.setScale(1.4);
        fbNegImageShadow.setScale(1.4);
        fbPosImage.setVisible(false);
        fbNegImage.setVisible(false);
        fbPosImageShadow.setVisible(false);
        fbNegImageShadow.setVisible(false);

        // define cursor keys
        cursors = this.input.keyboard.createCursorKeys();

        // create a blank group for the collective berry stimuli
        berries = this.add.group();
        // set stimui to invisible initially
        Phaser.Actions.SetVisible(berries.getChildren(),0);

        curTrialNum = 0;

        taskPhase = 'instructions';

        trialPhase = 'opening';
        // trialPhase = 'spe';

        prevTrialPhase = '';
    }

    update ()
    {
        switch (taskPhase)
        {
            case 'instructions':
                this.showInstructions();
                break;

            case 'task':
                this.doTask();
                break;

            case 'endblock':
                this.nextScene();
                break;
        }

    }
    
    showInstructions(){

        // show instructions

        switch (trialPhase)
        {

            case 'opening':
                trialPhase = 'wait';
                this.openingInstructions();
                break;

            case 'anotherTrial':
                trialPhase = 'wait';

                mainText = (" The fruits can appear at different\n"+
                            " locations within the centre bush, \n"+
                            " so make sure to attend within that\n"+
                            " region.\n\n"+
                            " 'Proceed' to see another example...\n"
                            );
           
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                1,  titleText, mainText, "Proceed");

                eventsCenter.once('page1complete', function () {

                    taskPhase = 'task';
                    prevTrialPhase = 'anotherTrial';
                    trialPhase = 'trialInit';
        
                    incdec = 2;
        
                }, this);

                break;

            case 'harderTrial':
                trialPhase = 'wait';

                mainText = (" Memorising just two items might be\n"+
                            " easy. \n\n"+
                            " But sometimes there will be more number\n"+
                            " of fruits spread out.\n\n"+
                            " Click 'Proceed' to see...\n"
                            );
           
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                1,  titleText, mainText, "Proceed");

                eventsCenter.once('page1complete', function () {

                    taskPhase = 'task';
                    prevTrialPhase = 'harderTrial';
                    trialPhase = 'trialInit';
        
                    incdec = 6;
        
                }, this);

                break;

            case 'showResponse':
                trialPhase = 'wait';

                titleText = 'Response Buttons';
                mainText = (" After viewing the fruits, you will be provided\n" +
                            " two fruit options, one which was present among \n"+
                            " recently shown fruits to be memorised and one \n"+
                            " that was not in present. Your task is to choose \n"+
                            " the fruit that WAS present. \n\n"+
                            ' You can select your response by pressing the \n'+
                            ' left (<-) or the right (->) arrow key on  \n'+
                            ' your keyboard.\n\n'+
                            " At this stage, if you accidentally press the \n"+
                            " wrong key, you can change your response by \n"+
                            " pressing the other key.\n\n"+
                            " As earlier, if your performance on this task\n"+
                            " is among the top 20% of the participants,\n"+
                            " you will receive a £1 bonus.\n"    
                );
           
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                1,  titleText, mainText, "Proceed");

                eventsCenter.once('page1complete', function () {

                    taskPhase = 'task';
                    prevTrialPhase = 'showResponse';
                    trialPhase = 'trialInit';
        
                    incdec = 5;
        
                }, this);

                break;

                
            case 'confidence':
                trialPhase = 'wait';

                titleText = 'Confidence';
                mainText = (" In addition to your choice of which fruit was in\n"+
                            " the box, you will also be asked to report how\n"+
                            " confident you were in your chosen response. \n\n"+
                            " The amount of confidence you have in your response\n"+
                            " will allow Fruitvillians to assess how much to\n"+ 
                            " rely on your chosen option when they are packing \n"+
                            " for shipment.\n\n"+
                            " You will report your confidence on a range of \n"+
                            " 0% to 100% using a slider where \n"+
                            " 0% = 'no confidence' and \n"+
                            " 100% = 'maximum confidence.\n\n"+
                            " Click 'Proceed' to try.\n"          
                );
            
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                1,  titleText, mainText, "Proceed");

                eventsCenter.once('page1complete', function () {

                    taskPhase = 'task';
                    prevTrialPhase = 'confidence';
                    trialPhase = 'trialInit';
        
                    incdec = 5;
        
                }, this);

                break;        
                
            case 'priorPerformanceEstimate':
                trialPhase = 'wait';

                titleText = 'Your estimated performance';
                mainText = (" We will also ask you to estimate how well\n"+
                            " you think you are performing this task\n"+
                            " of identifying the correct fruit.\n\n"+
                            " In fact, even before you begin, we would now \n"+
                            " like you to guess how well you think you\n"+
                            " would perform if you are shown, for example,\n"+
                            " a 100 trials of this task.\n\n"+
                            " After you click 'Proceed', you will be shown a \n"+
                            " a slider. Please drag it and select a value \n"+
                            " between 0 and 100 as a guess of how many out \n"+
                            " of a 100 trials you might be able to answer\n"+
                            " correctly when you do the task.\n\n"+
                            " Click 'Proceed' to provide the estimate...\n"          
                );
            
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                1,  titleText, mainText, "Proceed");

                eventsCenter.once('page1complete', function () {

                    taskPhase = 'task';
                    prevTrialPhase = 'priorPerformanceEstimate';
                    trialPhase = 'priorPerformanceEstimate';
        
                }, this);

                clickConfidence = false;

                break;        

            case 'feedback':
                trialPhase = 'wait';
                titleText = "Audit";
                mainText = (" Getting back to the task. In order to test how \n"+
                            " trustworthy your fruit choices are, Fruitville \n"+
                            " will occasionally hire an auditor to evaluate \n"+
                            " whether your response on a trial was correct\n"+
                            " or incorrect. \n\n"+ 
                            " On these few trials, after you record your\n"+
                            " response, the auditor will let you know \n"+
                            " whether you were correct or incorrect on that \n"+
                            " trial.\n\n"+
                            " 'Proceed' to try a few trials with all the\n"+
                            " steps including the audit."          
                );
            
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                1,  titleText, mainText, "Proceed");

                eventsCenter.once('page1complete', function () {

                    taskPhase = 'task';
                    prevTrialPhase = 'feedback';
                    trialPhase = 'trialInit';
        
                    incdec = 3;
                }, this);

                break;

            case 'spe':
                trialPhase = 'wait';

                titleText = "How well did you think you do?";

                mainText = (" As mentioned earlier, after completing a \n"+
                            " sequence of trials you will be asked to \n"+
                            " estimate number of trials in that sequence\n"+
                            " that you think you answered correctly on.\n\n"+
                            " For example, we just showed you 5 sample \n"+
                            " trials. How many of these 5 trials do you \n"+
                            " think you answered correctly?\n\n"+
                            " 'Proceed' to report..."          
                );
            
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                1,  titleText, mainText, "Proceed");

                eventsCenter.once('page1complete', function () {

                    speSlider.setValue(0);
                    clickConfidence = false;
                    taskPhase = 'task';
                    prevTrialPhase = 'spe';
                    trialPhase = 'spe';
        
                }, this);


                break;
                
        }
    }

    openingInstructions()
    {
        titleText = "The 'Fruit Box' task ";
        mainText = (" Some Fruitvillians receive boxes of fruits\n"+
                    " from the farmers and pack them for shipments.\n\n" +
                    " However, with the large variety of fruits \n" + 
                    " that they have to deal with, they are not\n"+
                    " always able to remember, which fruits were \n"+
                    " present in the incoming boxes. \n\n"+
                    " Can you help them by remembering and correctly \n"+
                    " identifying the fruits that have just arrived?\n"
                    );
   
        this.instructionsPanel = new InstructionsPanel(this, 
        gameWidth/2, gameHeight/2,
        1,  titleText, mainText, "Next page");

        eventsCenter.once('page1complete', function () {
        mainText = (' In what follows, you will be shown the fruit\n'+
                    " contents of the recently arrived fruit boxes \n"+
                    " over many 'trials'. \n\n"+
                    " You will then be asked to choose between \n"+
                    " two fruit options: one of which was part of\n"+
                    " the fruit box and one that was not.\n\n"+
                    " Your task is to correctly identify the fruit\n"+
                    " from that box.\n\n"+
                    " Click 'Proceed' to see an example where you \n"+
                    " are required to memorise 2 different fruits.\n"
            );

            this.instructionsPanel = new InstructionsPanel(this, 
            gameWidth/2, gameHeight/2,
            2, titleText, mainText, 'Proceed');

        }, this);

        eventsCenter.once('page2complete', function () {

            taskPhase = 'task';
            prevTrialPhase = 'opening';
            trialPhase = 'trialInit';

            incdec = 2;
         
        }, this);        
    }
            
    doTask(){
            switch (trialPhase)
            {
                // different phases within a trial

                case 'trialInit':
                    // at the beginning of a new trial 

                    stimulus = Math.floor(2 * Math.random()); // 0 or 1

                    if (!(fruitOptions[0]==undefined)){
                        fruitOptions[0].setVisible(false);
                        fruitOptions[1].setVisible(false);
    
                    }

                    text_resp.setVisible(false);

                    berries.clear();
                    // add reds

                    // get a random array of fruits and add 1 more for the other option of 2AFC with set-size incdec
                    randFruits = randSample(sequence(numStimuli), incdec + 1);

                    fruitChoices = randFruits.slice(-2); // get the last 2 fruits as the 2 options
                    randFruits.splice(-1); // remove the last option from the stimuli to be presented

                    if (stimulus){
                        // if true put the new fruit on the right otherwise on the left (randomise the location of the correct option)
                        temp = fruitChoices[1];
                        fruitChoices[1] = fruitChoices[0];
                        fruitChoices[0] = temp;
                    }

                    fruitOptions[0] = fruits[fruitChoices[0]];
                    fruitOptions[1] = fruits[fruitChoices[1]];
                    fruitOptions[0].setPosition(300,410)
                    fruitOptions[1].setPosition(460,410)

                    for ( i = 0; i < incdec; i++){
                        berries.createMultiple({
                                key: 'fruit'+randFruits[i],
                                setScale: {x: fruitScale[randFruits[i]], y: fruitScale[randFruits[i]]},
                                frameQuantity: 1 // more red for stim=0
                            });
                    }
                   
                    // start clock for the trial
                    stimulusTimedEvent = window.performance.now();

                    // Phaser.Actions.RandomRectangle(diamonds.getChildren(), ellipse);
                    this.plugins.get('rexrandomplaceplugin').randomPlace(berries.getChildren(),
                        {
                            radius: 30,
                            area: new Phaser.Geom.Rectangle(250, 310, 250, 220),
                        });
                    Phaser.Actions.SetVisible(berries.getChildren(),0);

                    preStimulusWaitDur = preStimInterval[0] + 
                        Math.random() * (preStimInterval[1] - preStimInterval[0]);

                    confRespTime = 0;

                    textFeedbackMessage.setVisible(false);

                    text_resp.x = 240;
                    text_resp.y = 180;
                    text_resp.setScale = 1.25;
                    text_resp.text = " Press an arrow key\n to record confidence\n and continue";        

                    startConf = Math.random()/5 + 0.4;

                    trialPhase = 'preStimulus';

                    break;                        
                
                case 'preStimulus':

                    timeFromStimOnset = window.performance.now() - stimulusTimedEvent;
                    if (timeFromStimOnset > preStimulusWaitDur){
                        trialPhase = 'dispStimulus';
                    } 
                    // ELSE: do nothing 
                 
                    break;


                case 'dispStimulus':

                    timeFromStimOnset = window.performance.now() - 
                    (stimulusTimedEvent + preStimulusWaitDur);

                    if (timeFromStimOnset < stimulusDuration){
                        // display visual stimulus here

                        // from now until stimulusTimedEvent display the stimulus
                        Phaser.Actions.SetVisible(berries.getChildren(),1);


                    }   else {
                        // stop showing the stimuli
                        Phaser.Actions.SetVisible(berries.getChildren(),0);

                        // text_resp.setVisible(true);
                        trialPhase = 'postStimulus';

                    }

                    break;


                case 'postStimulus':

                    timeFromStimOnset = window.performance.now() - 
                        (stimulusTimedEvent + preStimulusWaitDur + stimulusDuration);

                    if (timeFromStimOnset > postStimInterval)
                    {
                        switch (prevTrialPhase)
                        {
                            case 'opening':
                                taskPhase = 'instructions';
                                trialPhase = 'anotherTrial';
                                break;

                            case 'anotherTrial':
                                taskPhase = 'instructions';
                                trialPhase = 'harderTrial';
                                break;
                            
                            case 'harderTrial':
                                taskPhase = 'instructions';
                                trialPhase = 'showResponse';
                                break;

                            case 'showResponse':
                            case 'confidence':
                            case 'feedback':
                                trialPhase = 'acceptResp';
                                fruitOptions[0].x = 299; fruitOptions[0].y = 400;
                                fruitOptions[1].x = 477; fruitOptions[1].y = 400;
                                fruitOptions[0].setScale(fruitScale[fruitChoices[0]]);
                                fruitOptions[1].setScale(fruitScale[fruitChoices[1]]);
                                fruitOptions[0].setVisible(true);
                                fruitOptions[1].setVisible(true);
                                clickResponse = 0;
                        }

                    }

                    break;                    

                case 'acceptResp':

                    switch (prevTrialPhase)
                    {
                        case 'showResponse':
                            // when showing instructions about choosing the response response
                            if (!clickResponse){
                                // first time in this trialPhase
                                text_resp.text = 
                                "Press the left (<-) or\nright (->) arrow key to\nchoose the fruit\nthat was just present";
                            }
                            else if (clickResponse==1) {
                                // second time in this trialPhase
                                text_resp.text = 
                                "Now try choosing the\nother option with\nthe opposite arrow";
                            }
                            else if (clickResponse==2){
                                // third time here, go back to the instructions
                                text_resp.text = "Press the left or right\narrow key again to continue";

                            }
                            else {
                                taskPhase = 'instructions';
                                trialPhase = 'confidence';
                            }
                            text_resp.x = 230;
                            text_resp.y = 200;
                            break;

                        case 'confidence':
                        case 'feedback':
                            // when accepting response
                            if (!clickResponse){
                                text_resp.x = 230;
                                text_resp.y = 200;    
                                text_resp.text = 
                                "Press the left (<-) or\nright (->) arrow key to\nchoose the fruit\nthat was just present";
                            }
                            else if (clickResponse==1) {
                                text_resp.x = 170;
                                text_resp.y = 150;
                                text_resp.text = "Now drag/click the middle fruit icon\nup or down to select your confidence\n(or change your response and \nthen select confidence)";

                                fruitOptions[currentInput].setScale(fruitScale[fruitChoices[currentInput]]*chosenOptionSizeIncrease);
                                fruitOptions[1-currentInput].setScale(fruitScale[fruitChoices[1-currentInput]]);
                                confSlider[fruitChoices[1-currentInput]].setVisible(false);
                        
                                confSlider[fruitChoices[currentInput]].setValue(startConf);
                                clickConfidence = false;
                                confSlider[fruitChoices[currentInput]].setVisible(true);

                                trialPhase = 'acceptConf';
                            }
                            break;
                    }

                    text_resp.setVisible(true);

                    if (Phaser.Input.Keyboard.JustDown(cursors.left)){
                        currentInput = 0;
                        clickResponse++;
                        fruitOptions[0].setScale(fruitScale[fruitChoices[0]]*chosenOptionSizeIncrease);
                        fruitOptions[1].setScale(fruitScale[fruitChoices[1]]);
                    
                    }
                    else if (Phaser.Input.Keyboard.JustDown(cursors.right)){
                        currentInput = 1;
                        clickResponse++;
                        fruitOptions[1].setScale(fruitScale[fruitChoices[1]]*chosenOptionSizeIncrease);
                        fruitOptions[0].setScale(fruitScale[fruitChoices[0]]);
                        // this.respAccepted(currentInput);

                    } 
                    
                    break; 


                case 'acceptConf':

                    if (clickConfidence){
                        // accept the confidence slider value only when the confidence 
                        // slider has been clicked on once

                        currentConfidence = currentInput ? Math.round((1-confSlider[fruitChoices[1]].value)*100) : 
                        Math.round((1-confSlider[fruitChoices[0]].value)*100)

                        text_conf.x = 410;
                        text_conf.y = 495 + (1-currentConfidence)*2.2;

                        discreteConfidence = discretiseConfidence(
                                [currentConfidence/100],
                                numConfLevels);
                        this.children.bringToTop(text_conf);
                        text_conf.text = (currentConfidence) + "% confidence";
                        text_conf.setVisible(true);
                        for (let i=0; i<window.numConfLevels; i++){
                            textConfMarkers[i].setVisible(true);
                        }
                        
                        text_resp.x = 215;
                        text_resp.y = 190;
                        text_resp.text = "Press an arrow key to record\nconfidence when done";        

                        if (Phaser.Input.Keyboard.JustDown(cursors.up) ||
                        Phaser.Input.Keyboard.JustDown(cursors.down) ||
                        Phaser.Input.Keyboard.JustDown(cursors.left) ||
                        Phaser.Input.Keyboard.JustDown(cursors.right)){
                            // record confidence and move to the next phase of the trial

                            text_resp.setVisible(false);        
                            fruitOptions[0].setVisible(false);
                            fruitOptions[1].setVisible(false);                            
                            confSlider[fruitChoices[0]].setVisible(false);
                            confSlider[fruitChoices[1]].setVisible(false);
                            this.children.bringToTop(text_conf);
                            text_conf.setVisible(false);
                            for (let i=0; i<window.numConfLevels; i++){
                                textConfMarkers[i].setVisible(false);
                                this.children.bringToTop(textConfMarkers[i]);
                            }
    
                            switch(prevTrialPhase){
                                case 'confidence':
                                    taskPhase = 'instructions';
                                    trialPhase = 'priorPerformanceEstimate';
                                    break;

                                case 'feedback':
                                    trialPhase = 'feedbackDialog';
                            }                            
                        }
                    }
                    else{
                        // if confidence slider has not yet been clicked and if participant 
                        // wants to still change their mind about the response
                        // let them
                        if (currentInput && Phaser.Input.Keyboard.JustDown(cursors.left)){
                            currentInput = 0;
                            this.respAccepted(currentInput);
                        }
                        else if (!currentInput && Phaser.Input.Keyboard.JustDown(cursors.right)){
                            currentInput = 1;
                            this.respAccepted(currentInput);
                        } 
                    }

                    break;

                case 'priorPerformanceEstimate':
                    text_resp.text = "Drag the slider (blue tick) to\nchoose how many trials you expect\nto be correct on out of a 100\n\nThen press an arrow key to proceed";
                    text_resp.x = 150;
                    text_resp.y = 250;

                    currentConfidence = (speSlider.value);

                    discreteConfidence = discretiseConfidence(
                            [currentConfidence],
                            priorEstimateTrials+1);

                    text_conf.text = 'I am likely to be correct on\n' + (discreteConfidence-1) + '/' + priorEstimateTrials + ' of such trials';
                    text_conf.x = 190;
                    text_conf.y = 460;
                    text_conf.setVisible(true);

                    speSlider.setVisible(true);
                    text_resp.setVisible(true);
                    if (clickConfidence && 
                        (Phaser.Input.Keyboard.JustDown(cursors.up) ||
                    Phaser.Input.Keyboard.JustDown(cursors.down) ||
                    Phaser.Input.Keyboard.JustDown(cursors.left) ||
                    Phaser.Input.Keyboard.JustDown(cursors.right))){
                        if (window.spe0[curTaskNum]<0){
                            // record the spe0 only the first time they are running practice (if the re-run it they would have received feedback, which confound the estimates)
                            window.spe0[curTaskNum] = currentConfidence;
                        }
                        text_resp.setVisible(false);
                        text_conf.setVisible(false);
                        speSlider.setVisible(false);
                        taskPhase = 'instructions';
                        trialPhase = 'feedback';
                    }

                    break;
       

                case 'feedbackDialog' :
                        
                    this.showFeedbackDialog();

                    trialPhase = 'waitForDialogResponse';

                    break;

                case 'waitForDialogResponse':

                    eventsCenter.once('page10complete', function () {
                        // record the time at which confidence response is given
                        confRespTime = window.performance.now();
                        trialPhase = 'feedback';
                        }, this);

                    break;


                case 'feedback' :
                    
                    timeFromConfOnset = window.performance.now() - 
                    confRespTime;

                    if (timeFromConfOnset < feedbackInterval){
                        correct = !(stimulus ^ currentInput);
                        if (correct){
                            // feedback for correct

                            if (timeFromConfOnset > feedbackFaceAfter){
                                textFeedback.x = 315;
                                textFeedback.setColor('#0b0');
                                textFeedback.text = "Correct";
                                fbPosImageShadow.setVisible(true);
                                fbPosImage.setVisible(true);
                                
                                textFeedback.setVisible(true);
                            }
                        }
                        else{
                            // feedback for incorrect
                            if (timeFromConfOnset > feedbackFaceAfter){
                                textFeedback.x = 298;
                                textFeedback.setColor('#f00');
                                textFeedback.text = "Incorrect";
                                fbNegImageShadow.setVisible(true);
                                fbNegImage.setVisible(true);
                                
                                textFeedback.setVisible(true);
                            }
                        }
                    }
                    else{
                        timeFromConfOnset = window.performance.now();

                        textFeedback.setVisible(false);
                        textFeedbackMessage.setVisible(false);
                        fbPosImage.setVisible(false);
                        fbPosImageShadow.setVisible(false);
                        fbNegImage.setVisible(false);
                        fbNegImageShadow.setVisible(false);
                        
                        text_resp.x = 250;
                        text_resp.y = 360;
                        text_resp.setScale = 1.25;
                        text_resp.text = " Press an arrow key\n to continue";

                        trialPhase = 'postFeedbackInterval';
                    }
                    break;
                    

                case 'postFeedbackInterval':

                    text_resp.setVisible(true);

                    if (Phaser.Input.Keyboard.JustDown(cursors.up) ||
                    Phaser.Input.Keyboard.JustDown(cursors.down) ||
                    Phaser.Input.Keyboard.JustDown(cursors.left) ||
                    Phaser.Input.Keyboard.JustDown(cursors.right))
                    {
                        text_resp.setVisible(false);

                        trialPhase = 'postTrial';
                    }

                    break;

                case 'postTrial':

                    curTrialNum++;

                    if (curTrialNum == window.numLearningTrials){
                        taskPhase = 'instructions';
                        trialPhase = 'spe';
                    }
                    else {
                        trialPhase = 'trialInit';
                        incdec = practTrialDifficulties[curTrialNum];
                    }
                    break;


                case 'spe':
                    text_resp.text = "Drag the slider to choose\nthe number of correct trials.\nThen press an arrow key when done";
                    text_resp.x = 180;
                    text_resp.y = 280;

                    currentConfidence = (speSlider.value);

                    discreteConfidence = discretiseConfidence(
                            [currentConfidence],
                            window.numLearningTrials+1);

                    text_conf.text = (discreteConfidence-1) + '/' + window.numLearningTrials + ' correct';
                    text_conf.x = 320;
                    text_conf.y = 390;
                    text_conf.setVisible(true);

                    speSlider.setVisible(true);
                    text_resp.setVisible(true);
                    if (clickConfidence && 
                        (Phaser.Input.Keyboard.JustDown(cursors.up) ||
                    Phaser.Input.Keyboard.JustDown(cursors.down) ||
                    Phaser.Input.Keyboard.JustDown(cursors.left) ||
                    Phaser.Input.Keyboard.JustDown(cursors.right))){
                        text_resp.setVisible(false);
                        text_conf.setVisible(false);
                        speSlider.setVisible(false);
                        trialPhase = 'understood';
                    }
                    break;                    

                case 'understood':

                    ynDialog = yesnoDialog(this, 'Repeat instructions?', 
                    " Those are all the instructions for this game.\n\n"+
                    " Would you like to see the instructions again?\n\n"+
                    " Click 'Yes' to repeat the instructions. \n\n"+
                    " Else, if you have understood the instructions\n"+
                    " completely, click 'No' to proceed.",
                    {x:400, y: 300}, 
                    function(index){
                        if (index){
                            window.fruitvilleStage = 5;
                        }
                        ynDialog.scaleDownDestroy(50);
                        taskPhase = 'endblock';
                    },
                    ["Yes: show instructions again", "No: proceed"]);
            
                    taskPhase = 'wait';

                    break;
            }
    }

    
    respAccepted(respNum){
        fruitOptions[respNum].setScale(fruitScale[fruitChoices[respNum]]*chosenOptionSizeIncrease);
        fruitOptions[1-respNum].setScale(fruitScale[fruitChoices[1-respNum]]);

        confSlider[fruitChoices[1-respNum]].setVisible(false);
        confSlider[fruitChoices[respNum]].setValue(startConf);
        clickConfidence = false;
        confSlider[fruitChoices[respNum]].setVisible(true);
    }


    showFeedbackDialog(){
        var mainTxt = ( " The auditor of Fruitville is here\n"+
                        " to evaluate your response. \n\n"+
                        " Check how you performed..."
                        );
        var buttonTxt = "Check response";
        var pageNo = 10;
        this.instructionsPanel = new InstructionsPanel(this, 
        gameWidth/2, gameHeight/2,
        pageNo, auditDialogTitle, mainTxt, buttonTxt);

    }


    nextScene() {
        if (window.fruitvilleStage == 5){
            // if participants have understood the instructions
            console.log('window.fruitvilleStage '+window.fruitvilleStage)
            this.scene.start('fruitville');
        }
        else{
            // otherwise restart this help page
            this.scene.restart();
        }
    }

    createTaskItems(){
        for (let i = 0; i < numStimuli; i++){
            fruits[i] = this.add.image(i*15,400,'fruit'+i).setScale(fruitScale[i]);
            fruits[i].setVisible(false);

            // make a confidence slider for each of the fruits
            confSlider[i] = this.rexUI.add.slider({
                x: 380,
                y: 400,
                width: 20,
                height: 250,
                orientation: 'v',
                track: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[0]),
                indicator: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[1]),
                thumb: this.add.image(300,170,'fruit'+i).setScale(fruitScale[i]*.85),
                input: 'click', // 'drag'|'click'
                valuechangeCallback: function (value) {
                    // confidence = 1-value; // subtract from 1 because sliders are inverted
                    clickConfidence = true;
                }}).layout();
            confSlider[i].setVisible(false);
        }

        speSlider = this.rexUI.add.slider({
            x: 380,
            y: 440,
            width: 250,
            height: 20,
            orientation: 'x',
            track: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[1]),
            indicator: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[2]),
            thumb: this.add.image(300,170,'tickMark').setScale(.35),
            input: 'click', // 'drag'|'click'
            valuechangeCallback: function (value) {
                // confidence[curTrialNum] = 1-value; // subtract from 1 because sliders are inverted
                clickConfidence = true;
            }}).layout();
        speSlider.setVisible(false);        

        text_resp = this.add.text(250,300,"Press an arrow key\n(up/down/left/right)\nto begin...",{
            align:'center', color: '#fff', strokeThickness: 3, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        text_resp.scale = 1.35;
        text_resp.setVisible(false);

        text_conf = this.add.text(300,200,"",{
            align:'center', color: '#fff', strokeThickness: 3, 
            stroke: '#00f',
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        text_conf.scale = 1.3;
        text_conf.setVisible(false);

        textFeedbackMessage = this.add.text(220,450,"Additional feedback message",{
            align:'center', color: '#fff', strokeThickness: 3, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        textFeedbackMessage.setVisible(false);
        textFeedbackMessage.setScale(1.4);

        textFeedback = this.add.text(320,300,"Correct/Incorrect",{
            align:'center', color: '#090', strokeThickness: 3, 
            stroke: '#000', fontSize: 20,
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        textFeedback.setVisible(false);
        textFeedback.setScale(1.5);

        fullscreenButton = addFullscreenButton(this);

        for (let i=0; i<window.numConfLevels; i++){
            textConfMarkers[i] = this.add.text(285, 280+i*54.5,
                window.confidenceMarkers[window.numConfLevels-i-1],{
                align:'right', color: '#fff', strokeThickness: 3, 
                stroke: '#000', fontSize: 20,
                shadow: {offsetX: .5, offsetY: .5, stroke: true}
            });
            textConfMarkers[i].setVisible(false);
            this.children.bringToTop(textConfMarkers[i]);
        }
    }    

}


